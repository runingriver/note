package com.qunar;

import com.qunar.mybatis.service.GenerateService;

/**
 * Created by renqun.yuan on 2016/4/4.
 */
public class TestGenerateServiceCode {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306";
        String userName = "root";
        String password = "111";
        GenerateService generateService = new GenerateService(url, userName, password);
        String dbName = "badmin";
        String[] tables = {"sys_role","sys_user"};
        String filePath = "/home/hzz/gitrepo/mybatis-generator";
        generateService.generateCode(dbName, tables, filePath);
    }
}
