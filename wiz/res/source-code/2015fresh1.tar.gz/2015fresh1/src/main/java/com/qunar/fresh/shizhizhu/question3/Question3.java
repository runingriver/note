package com.qunar.fresh.shizhizhu.question3;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.CharMatcher;
import com.google.common.base.Charsets;
import com.google.common.base.Optional;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.io.Files;
import com.google.common.io.LineProcessor;
import com.qunar.fresh.shizhizhu.exam1.IOUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-13
 */
public class Question3 {
    private static final Logger LOGGER = LoggerFactory.getLogger(Question3.class);
    private static final String HOTEL_PRICE_FILE_NAME = "/hotelPrice.txt";
    private static final String DATE_TEMPLATE = "yyyy-MM-dd";
    private static final String MERGE_HOTEL_PRICE_FILE_NAME = "mergeHotelPrice.txt";
    public static final String HOTEL_PRICE_TEMPLATE = "%s~%s %s";

    public static void main(String[] args) {
        try {
            List<HotelPrice> hotelPriceList = loadHotelPrice(HOTEL_PRICE_FILE_NAME);
            TreeMap<Date, Integer> hotelPriceMap = transform(hotelPriceList);
            List<HotelPrice> mergeHotelPriceList = merge(hotelPriceMap);
            outputMergeHotelPrice(MERGE_HOTEL_PRICE_FILE_NAME, mergeHotelPriceList);
        } catch (IOException e) {
            LOGGER.error("merge hotel price occur error", e);
        }
    }

    private static List<HotelPrice> loadHotelPrice(String hotelPriceFileName) throws IOException {
        File hotelPriceFile = new File(Question3.class.getResource(hotelPriceFileName).getFile());
        return Files.readLines(hotelPriceFile, Charsets.UTF_8, new LineProcessor<List<HotelPrice>>() {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_TEMPLATE);
            private List<HotelPrice> hotelPriceList = Lists.newArrayList();
            private Splitter hotelPriceSplitter = Splitter.on(CharMatcher.anyOf("~ "));

            @Override
            public boolean processLine(String line) throws IOException {
                Optional<HotelPrice> hotelPrice;
                hotelPrice = parseHotelPriceLine(line);
                if (hotelPrice.isPresent()) {
                    hotelPriceList.add(hotelPrice.get());
                }
                return true;
            }

            @Override
            public List<HotelPrice> getResult() {
                return hotelPriceList;
            }

            private Optional<HotelPrice> parseHotelPriceLine(String line) {
                List<String> elementList = hotelPriceSplitter.splitToList(line);
                if (elementList.size() == 3) {
                    try {
                        Date startDate = simpleDateFormat.parse(elementList.get(0));
                        Date endDate = simpleDateFormat.parse(elementList.get(1));
                        return Optional.of(new HotelPrice(startDate, endDate, NumberUtils.toInt(elementList.get(2))));
                    } catch (ParseException e) {
                        LOGGER.error("parse hotel price line error, line={}", line, e);
                    }
                } else {
                    LOGGER.error("parse hotel price line error, line={}", line);
                }
                return Optional.absent();
            }
        });
    }

    private static TreeMap<Date, Integer> transform(List<HotelPrice> hotelPriceList) {
        TreeMap<Date, Integer> hotelPriceTreeMap = Maps.newTreeMap();
        for (HotelPrice hotelPrice : hotelPriceList) {
            Date startDate = hotelPrice.getStartDate();
            Date endDate = hotelPrice.getEndDate();
            if (startDate.after(endDate)) {
                LOGGER.error("this is an error hotelPrice:startDate after endDate, hotelPrice={}", hotelPrice);
                continue;
            }
            while (!startDate.after(endDate)) {
                hotelPriceTreeMap.put(startDate, hotelPrice.getPrice());
                startDate = DateUtils.addDays(startDate, 1);
            }
        }
        return hotelPriceTreeMap;
    }

    private static List<HotelPrice> merge(TreeMap<Date, Integer> hotelPriceMap) {
        List<HotelPrice> hotelPriceList = Lists.newArrayList();
        Map.Entry<Date, Integer> startEntry = null;
        Map.Entry<Date, Integer> lastEntry = null;
        for (Map.Entry<Date, Integer> entry : hotelPriceMap.entrySet()) {
            if (startEntry == null && lastEntry == null) {
                startEntry = entry;
                lastEntry = entry;
                continue;
            }
            if (canMerge(lastEntry, entry)) {
                lastEntry = entry;
            } else {
                hotelPriceList.add(new HotelPrice(startEntry.getKey(), lastEntry.getKey(), startEntry.getValue()));
                startEntry = entry;
                lastEntry = entry;
            }
        }
        hotelPriceList.add(new HotelPrice(startEntry.getKey(), lastEntry.getKey(), startEntry.getValue()));
        return hotelPriceList;
    }

    private static boolean canMerge(Map.Entry<Date, Integer> lastEntry, Map.Entry<Date, Integer> entry) {
        return DateUtils.isSameDay(DateUtils.addDays(lastEntry.getKey(), 1), entry.getKey())
                && lastEntry.getValue().equals(entry.getValue());
    }

    private static void outputMergeHotelPrice(String mergeHotelPriceFileName, List<HotelPrice> mergeHotelPriceList)
            throws IOException {
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_TEMPLATE);
        IOUtils.writeLines(mergeHotelPriceFileName, mergeHotelPriceList,
                new com.qunar.fresh.shizhizhu.exam1.Function<HotelPrice, String>() {
                    @Override
                    public String apply(HotelPrice hotelPrice) {
                        return String.format(HOTEL_PRICE_TEMPLATE, simpleDateFormat.format(hotelPrice.getStartDate()),
                                simpleDateFormat.format(hotelPrice.getEndDate()), hotelPrice.getPrice());
                    }
                });
    }
}
