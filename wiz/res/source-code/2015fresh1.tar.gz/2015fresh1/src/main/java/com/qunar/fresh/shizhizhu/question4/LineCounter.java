package com.qunar.fresh.shizhizhu.question4;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public interface LineCounter extends Reportable {
    public boolean count(String line);

    public String getType();
}
