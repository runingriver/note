package com.qunar.fresh.shizhizhu.question2;

import java.util.LinkedHashMap;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-11
 */
public class NatureOrderConfigurer implements Configurer {
    private List<String> natureOrderConfigList;

    public NatureOrderConfigurer(LinkedHashMap<Integer, String> configMap) {
        natureOrderConfigList = Lists.newArrayList(configMap.values());
    }

    @Override
    public String getValue(Integer index) {
        return natureOrderConfigList.get(index);
    }
}
