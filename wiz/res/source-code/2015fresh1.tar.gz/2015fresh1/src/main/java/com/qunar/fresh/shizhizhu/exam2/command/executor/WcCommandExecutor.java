package com.qunar.fresh.shizhizhu.exam2.command.executor;

import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;

import com.google.common.base.Preconditions;
import com.google.common.collect.Iterators;
import com.qunar.fresh.shizhizhu.exam2.command.Command;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-19
 */
public class WcCommandExecutor extends AbstractFileSourceCommandExecutor {
    @Override
    protected Iterator<String> doExecute(Command command, Iterator<String> pipeSource) {
        Preconditions.checkArgument(command.getArgumentList().size() > 0, "wc must have argument");
        Preconditions
                .checkArgument(StringUtils.equals(command.getArgumentList().get(0), "-l"), "argument must name -l");
        return Iterators.singletonIterator(String.valueOf(Iterators.size(pipeSource)));
    }
}
