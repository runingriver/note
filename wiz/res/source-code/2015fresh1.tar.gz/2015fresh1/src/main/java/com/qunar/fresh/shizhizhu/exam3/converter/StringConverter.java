package com.qunar.fresh.shizhizhu.exam3.converter;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class StringConverter extends AbstractStringConverter<String> {
    @Override
    public String doForward(String input) {
        return input;
    }

}
