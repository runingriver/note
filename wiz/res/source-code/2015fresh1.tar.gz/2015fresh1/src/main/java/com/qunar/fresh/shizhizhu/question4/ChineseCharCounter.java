package com.qunar.fresh.shizhizhu.question4;

import java.util.regex.Pattern;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public class ChineseCharCounter extends AbstractCharCounter {
    private Pattern chinesePattern = Pattern.compile("[\u4E00-\u9FA5]");

    @Override
    public boolean apply(Character character) {
        return chinesePattern.matcher(String.valueOf(character)).find();
    }

    @Override
    public String getType() {
        return "汉字";
    }

    @Override
    public boolean isDetailVisible() {
        return false;
    }
}
