package com.qunar.fresh.shizhizhu.question1;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Charsets;
import com.google.common.collect.Maps;
import com.google.common.io.Files;
import com.google.common.io.LineProcessor;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-9
 */
public class Question1 {

    private static final Logger LOGGER = LoggerFactory.getLogger(Question1.class);
    private static final String CODE_FILE_NAME = "/StringUtils.java";
    private static final String COUNT_OUTPUT_FILE_NAME = "/validLineCount.txt";

    public static void main(String[] args) {
        try {
            final File codeFile = new File(Question1.class.getResource(CODE_FILE_NAME).getFile());
            Map<LineState, Integer> lineStateCountMap = analyzeJavaFile(codeFile);
            File countFile = new File(Question1.class.getResource("/").getFile() + COUNT_OUTPUT_FILE_NAME);
            Files.write(String.valueOf(lineStateCountMap.get(LineState.VALID)), countFile, Charsets.UTF_8);
        } catch (IOException e) {
            LOGGER.error("count code file valid line occur error", e);
        }
    }

    private static Map<LineState, Integer> analyzeJavaFile(File codeFile) throws IOException {
        return Files.readLines(codeFile, Charsets.UTF_8, new LineProcessor<Map<LineState, Integer>>() {
            private Map<LineState, Integer> countMap = Maps.newHashMap();
            private LineState currentLineState;

            @Override
            public boolean processLine(String line) throws IOException {
                currentLineState = recognize(line, currentLineState);
                Integer count = countMap.get(currentLineState);
                countMap.put(currentLineState, count == null ? 1 : count + 1);
                return true;
            }

            @Override
            public Map<LineState, Integer> getResult() {
                return this.countMap;
            }
        });
    }

    private static LineState recognize(String line, LineState currentLineState) {
        if (currentLineState != null && currentLineState.isKeepCount()) {
            return currentLineState.withKeepCount(currentLineState.shouldKeepCount(line));
        }
        for (LineState lineState : LineState.values()) {
            if (lineState.match(line)) {
                return lineState.withKeepCount(lineState.shouldKeepCount(line));
            }
        }
        return null;
    }
}
