package com.qunar.fresh.shizhizhu.exam2.command;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-23
 */
public class CommandExecuteException extends RuntimeException {

    public CommandExecuteException(String message) {
        super(message);
    }

    public CommandExecuteException(Throwable throwable) {
        super(throwable);
    }

    public CommandExecuteException(String message, Throwable throwable) {
        super(message, throwable);
    }

}
