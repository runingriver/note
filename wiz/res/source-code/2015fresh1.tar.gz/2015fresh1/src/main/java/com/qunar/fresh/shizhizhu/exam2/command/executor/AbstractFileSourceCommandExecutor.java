package com.qunar.fresh.shizhizhu.exam2.command.executor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import org.apache.commons.io.LineIterator;

import com.google.common.base.Preconditions;
import com.qunar.fresh.shizhizhu.exam2.CloseableIterator;
import com.qunar.fresh.shizhizhu.exam2.CloseableIteratorAdaptor;
import com.qunar.fresh.shizhizhu.exam2.CloseableLineIterator;
import com.qunar.fresh.shizhizhu.exam2.command.Command;
import com.qunar.fresh.shizhizhu.exam2.command.CommandExecuteException;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-23
 */
public abstract class AbstractFileSourceCommandExecutor implements CommandExecutor {

    @Override
    public CloseableIterator<String> execute(Command command) {
        Preconditions.checkNotNull(command, "command can not be null");
        Preconditions.checkNotNull(command.getTarget(), "target can not be null");
        CloseableIterator<String> pipeSource = getSource(command.getTarget());
        return pipeExecute(command, pipeSource);
    }

    @Override
    public CloseableIterator<String> pipeExecute(Command command, CloseableIterator<String> pipeSource) {
        Preconditions.checkNotNull(command, "command can not be null");
        pipeSource = pipeSource == null ? getSource(command.getTarget()) : pipeSource;
        return new CloseableIteratorAdaptor<String>(pipeSource, doExecute(command, pipeSource));
    }

    protected abstract Iterator<String> doExecute(Command command, Iterator<String> pipeSource);

    private CloseableIterator<String> getSource(String target) {
        File file = new File(target);
        try {
            return new CloseableLineIterator(new LineIterator(new BufferedReader(new FileReader(file))));
        } catch (IOException e) {
            throw new CommandExecuteException(e);
        }
    }
}
