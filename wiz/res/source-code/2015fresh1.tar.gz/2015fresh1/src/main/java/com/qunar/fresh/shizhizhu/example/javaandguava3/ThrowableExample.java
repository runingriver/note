package com.qunar.fresh.shizhizhu.example.javaandguava3;

import java.io.IOException;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-24
 */
public class ThrowableExample {
    // Exception in thread "main" java.lang.OutOfMemoryError: Java heap space
    public static void main(String[] args) {
        testOutOfMemory();
        testStackOverFlow();
    }

    private static void testStackOverFlow() {
        testStackOverFlow();
    }

    private static void testOutOfMemory() {
        int[] ints = new int[5000000];
    }

    private abstract static class Foo {
        public abstract boolean foo() throws IOException;
    }

    public class FooImpl1 extends Foo {
        @Override
        public boolean foo() throws IOException {
            // public boolean foo() throws IOException, ParseException { // can not throw ParseException
            return false;
        }
    }

    public class FooImpl2 extends Foo {
        @Override
        public boolean foo() throws IOException {
            throw new RuntimeException(); // can throw RuntimeException
        }
    }

    public static int testFinally() {
        int i = 0;
        try {
            return i;
        } finally {
            i = 2;
        }

    }

    public static Cat testFinally2() {
        Cat cat = new Cat(1);
        try {
            return cat;
        } finally {
            cat.setAge(2);
        }

    }

    private static class Cat {
        private int age;

        public Cat(int age) {
            this.age = age;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }
    }
}
