package com.qunar.fresh.shizhizhu.example.javaandguava3;

import java.io.*;
import java.net.URL;
import java.util.List;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.google.common.io.Resources;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-25
 */
public class IOExample {
    public static void main(String[] args) throws IOException {
        testFile(IOExample.class.getResource("/logback.xml").getFile());
        testFileWithGuava(IOExample.class.getResource("/logback.xml").getFile());
        testUrl("http://www.qunar.com");
        testUrlWithGuava("http://www.qunar.com");
    }

    private static void testFile(String fileName) throws FileNotFoundException {
        InputStream inputStream = new FileInputStream(new File(fileName));
        // read from inputStream
    }

    private static void testFileWithGuava(String fileName) throws IOException {
        List<String> lineList = Files.readLines(new File(fileName), Charsets.UTF_8);
    }

    private static void testUrl(String location) throws IOException {
        URL url = new URL(location);
        // InputStream inputStream = url.openStream();
        // url.openConnection().getInputStream();
        // url.openConnection().getOutputStream();
    }

    private static void testUrlWithGuava(String location) throws IOException {
        List<String> lineList = Resources.readLines(new URL(location), Charsets.UTF_8);
        // Resources.getResource("/logback.xml").getFile();
    }

}
