package com.qunar.fresh.shizhizhu.exam1;

import java.io.IOException;

/**
 * 只做示例使用
 * 
 * @see com.google.common.io.LineProcessor
 *
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-10-31
 */
public interface LineProcessor<T> {

    boolean processLine(String line) throws IOException;

    T getResult();
}
