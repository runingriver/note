package com.qunar.fresh.shizhizhu.question2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.CharMatcher;
import com.google.common.base.Charsets;
import com.google.common.base.Splitter;
import com.google.common.collect.Maps;
import com.google.common.io.LineProcessor;
import com.google.common.io.Resources;
import com.qunar.fresh.shizhizhu.exam1.IOUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-11
 */
public class Question2 {
    private static final Logger LOGGER = LoggerFactory.getLogger(Question2.class);
    private static final String SDXL_CONFIG_TXT_URL = "https://owncloud.corp.qunar.com/index.php/s/2pvS0d2Zs5onsF2/download";
    private static final String UNREVERT_SDXL_TXT_URL = "https://owncloud.corp.qunar.com/index.php/s/2mElvSWUJgppSBx/download";
    private static final String REVERT_SDXL_TXT_URL = "sdxl.txt";
    private static final String FUNCTION_PATTERN = "\\$(\\w+)\\((\\d+)\\)";

    public static void main(String[] args) {
        try {
            LinkedHashMap<Integer, String> configMap = fetchProperty(SDXL_CONFIG_TXT_URL);
            Map<FunctionType, Configurer> configurerMap = initConfigurerMap(configMap);
            revert(UNREVERT_SDXL_TXT_URL, REVERT_SDXL_TXT_URL, configurerMap);
        } catch (IOException e) {
            LOGGER.error("revert shendiaoxialv txt occur error", e);
        }
    }

    private static LinkedHashMap<Integer, String> fetchProperty(String sdxlConfigTxtUrl) throws IOException {
        return Resources.readLines(new URL(sdxlConfigTxtUrl), Charsets.UTF_8,
                new LineProcessor<LinkedHashMap<Integer, String>>() {
                    private LinkedHashMap<Integer, String> configMap = Maps.newLinkedHashMap();
                    private Splitter splitter = Splitter.on(CharMatcher.BREAKING_WHITESPACE).trimResults();

                    @Override
                    public boolean processLine(String line) throws IOException {
                        List<String> entryList = splitter.splitToList(line);
                        if (entryList.size() != 2) {
                            LOGGER.error("parse a config line error, line={}", line);
                        } else {
                            configMap.put(NumberUtils.toInt(entryList.get(0)), entryList.get(1));
                        }
                        return true;
                    }

                    @Override
                    public LinkedHashMap<Integer, String> getResult() {
                        return configMap;
                    }
                });
    }

    private static Map<FunctionType, Configurer> initConfigurerMap(LinkedHashMap<Integer, String> configMap) {
        Map<FunctionType, Configurer> configurerMap = Maps.newHashMap();
        configurerMap.put(FunctionType.NATURE_ORDER, new NatureOrderConfigurer(configMap));
        configurerMap.put(FunctionType.INDEX_ORDER, new IndexOrderConfigurer(configMap));
        configurerMap.put(FunctionType.CHAR_ORDER, new CharOrderConfigurer(configMap));
        configurerMap.put(FunctionType.CHAR_ORDER_DESC, new CharOrderDescConfigurer(configMap));
        return configurerMap;
    }

    private static void revert(String unrevertSdxlTxtUrl, String revertSdxlTxtUrl,
            final Map<FunctionType, Configurer> configurerMap) throws IOException {
        final BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(Question2.class.getResource("/")
                .getFile() + revertSdxlTxtUrl));
        final Pattern functionPattern = Pattern.compile(FUNCTION_PATTERN);
        try {
            Resources.readLines(new URL(unrevertSdxlTxtUrl), Charsets.UTF_8, new LineProcessor<Boolean>() {

                @Override
                public boolean processLine(String line) throws IOException {
                    bufferedWriter.write(replaceFunctionExpression(functionPattern, line, configurerMap));
                    bufferedWriter.newLine();
                    return true;
                }

                @Override
                public Boolean getResult() {
                    return true;
                }
            });
        } finally {
            IOUtils.closeIgnoreException(bufferedWriter);
        }
    }

    public static String replaceFunctionExpression(Pattern functionPattern, String line,
            Map<FunctionType, Configurer> configurerMap) {
        Matcher matcher = functionPattern.matcher(line);
        while (matcher.find()) {
            String functionExpression = matcher.group();
            String function = matcher.group(1);
            int index = NumberUtils.toInt(matcher.group(2), -1);
            line = StringUtils.replace(line, functionExpression, configurerMap.get(FunctionType.nameOf(function))
                    .getValue(index));
        }
        return line;
    }

}
