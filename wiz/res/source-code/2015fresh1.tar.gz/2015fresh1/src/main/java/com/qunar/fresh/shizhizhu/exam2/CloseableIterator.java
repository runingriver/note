package com.qunar.fresh.shizhizhu.exam2;

import java.io.Closeable;
import java.util.Iterator;

/**
 * Created with IntelliJ IDEA. User: yuqi Date: 14-5-13 Time: 上午1:04
 */
public interface CloseableIterator<T> extends Iterator<T>, Closeable {

}
