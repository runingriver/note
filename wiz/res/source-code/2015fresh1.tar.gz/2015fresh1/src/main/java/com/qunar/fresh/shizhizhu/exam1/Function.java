package com.qunar.fresh.shizhizhu.exam1;

/**
 * 只做示例使用
 * 
 * @see com.google.common.base.Function
 *
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-10-31
 */
public interface Function<F, T> {
    T apply(F input);
}
