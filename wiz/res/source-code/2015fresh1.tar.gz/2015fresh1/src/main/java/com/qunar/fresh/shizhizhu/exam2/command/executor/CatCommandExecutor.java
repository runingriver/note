package com.qunar.fresh.shizhizhu.exam2.command.executor;

import java.util.Iterator;

import com.qunar.fresh.shizhizhu.exam2.command.Command;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-19
 */
public class CatCommandExecutor extends AbstractFileSourceCommandExecutor {

    @Override
    protected Iterator<String> doExecute(Command command, Iterator<String> pipeSource) {
        return pipeSource;
    }
}
