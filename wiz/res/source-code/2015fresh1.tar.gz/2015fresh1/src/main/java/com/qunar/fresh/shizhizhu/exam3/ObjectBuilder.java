package com.qunar.fresh.shizhizhu.exam3;

import java.io.InputStream;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-27
 */
public interface ObjectBuilder {
    public <T> T build(InputStream configSource);
}
