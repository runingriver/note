package com.qunar.fresh.shizhizhu.exam2.command;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-19
 */
public enum CommandType {
    CAT, GREP, WC;
}
