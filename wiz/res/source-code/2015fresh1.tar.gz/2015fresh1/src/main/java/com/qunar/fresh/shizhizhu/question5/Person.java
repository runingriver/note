package com.qunar.fresh.shizhizhu.question5;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-26
 */
public class Person {
    private String name;
    private int age;
    private String gender;
    private String hometown;

    public Person(String name, int age, String gender, String hometown) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.hometown = hometown;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }
}
