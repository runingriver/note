package com.qunar.fresh.shizhizhu.question2;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-11
 */
public interface Configurer {
    public String getValue(Integer index);
}
