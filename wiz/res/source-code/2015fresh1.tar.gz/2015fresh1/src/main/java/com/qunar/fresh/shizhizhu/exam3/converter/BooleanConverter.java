package com.qunar.fresh.shizhizhu.exam3.converter;

import org.apache.commons.lang3.BooleanUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class BooleanConverter extends AbstractStringConverter<Boolean> {
    @Override
    public Boolean doForward(String input) {
        return BooleanUtils.toBoolean(input);
    }
}
