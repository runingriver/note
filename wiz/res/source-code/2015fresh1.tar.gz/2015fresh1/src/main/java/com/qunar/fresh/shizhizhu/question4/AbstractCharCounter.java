package com.qunar.fresh.shizhizhu.question4;

import java.util.Map;

import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public abstract class AbstractCharCounter implements Predicate<Character>, CharCounter {
    protected Map<Character, Integer> characterMap = Maps.newTreeMap();

    @Override
    public boolean count(char character) {
        if (!apply(character)) {
            return false;
        } else {
            Integer count = characterMap.get(character);
            if (count == null) {
                count = 1;
            } else {
                count++;
            }
            characterMap.put(character, count);
            return true;
        }
    }

    @Override
    public Map<String, Integer> getSummary() {
        int count = 0;
        for (Integer integer : characterMap.values()) {
            count += integer;
        }
        return ImmutableMap.of(getType(), count);
    }

    @Override
    public Map<String, Integer> getDetail() {
        Map<String, Integer> result = Maps.newLinkedHashMap();
        for (Map.Entry<Character, Integer> entry : characterMap.entrySet()) {
            result.put(getType() + entry.getKey(), entry.getValue());
        }
        return result;
    }
}
