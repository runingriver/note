package com.qunar.fresh.shizhizhu.question4;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Charsets;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.io.Closer;
import com.google.common.io.Files;
import com.qunar.fresh.shizhizhu.exam1.IOUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public class Question4 {
    private static final Logger LOGGER = LoggerFactory.getLogger(Question4.class);
    private static final String COUNT_INFO_FILE_NAME = "characterType.txt";
    private static final String ELEMENT_SEPARATOR = ":";

    public static void main(String[] args) {
        Preconditions.checkArgument(args.length > 0, "please init the folder location in args");
        List<File> fileList = searchFile(new File(args[0]));
        try {
            List<Reportable> countList = countCharacterType(fileList);
            outputCountInfo(COUNT_INFO_FILE_NAME, countList);
        } catch (IOException e) {
            LOGGER.error("count character type occur error", e);
        }
    }

    private static List<File> searchFile(File entranceFile) {
        List<File> fileLis = Lists.newArrayList();
        LinkedList<File> fileQueue = Lists.newLinkedList(Lists.newArrayList(entranceFile));
        while (!fileQueue.isEmpty()) {
            File file = fileQueue.poll();
            if (file.isDirectory()) {
                fileQueue.addAll(Lists.newArrayList(file.listFiles()));
            } else {
                fileLis.add(file);
            }
        }
        return fileLis;
    }

    private static List<Reportable> countCharacterType(List<File> fileList) throws IOException {
        ReportableLineProcessor reportableLineProcessor = new ReportableLineProcessor();
        for (File file : fileList) {
            Files.readLines(file, Charsets.UTF_8, reportableLineProcessor);
        }
        return reportableLineProcessor.getResult();
    }

    private static void outputCountInfo(String countInfoFileName, List<Reportable> countList) throws IOException {
        Closer closer = Closer.create();
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter((new File(Question4.class
                    .getResource("/").getFile() + countInfoFileName))));
            closer.register(bufferedWriter);
            for (Reportable reportable : countList) {
                for (Map.Entry<String, Integer> entry : reportable.getSummary().entrySet()) {
                    bufferedWriter.write(entry.getKey() + ELEMENT_SEPARATOR + entry.getValue() + "个"
                            + IOUtils.LINE_SEPARATOR);
                }
            }
            bufferedWriter.newLine();
            for (Reportable reportable : countList) {
                if (reportable.isDetailVisible()) {
                    for (Map.Entry<String, Integer> entry : reportable.getDetail().entrySet()) {
                        bufferedWriter.write(entry.getKey() + ELEMENT_SEPARATOR + entry.getValue() + "个"
                                + IOUtils.LINE_SEPARATOR);
                    }
                    bufferedWriter.newLine();
                }
            }
        } finally {
            closer.close();
        }
    }

}
