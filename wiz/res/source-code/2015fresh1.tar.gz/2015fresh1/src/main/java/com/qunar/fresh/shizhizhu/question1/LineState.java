package com.qunar.fresh.shizhizhu.question1;

import org.apache.commons.lang3.StringUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-9
 */
public enum LineState {

    EMPTY {
        @Override
        public boolean match(String line) {
            return StringUtils.isBlank(line.trim());
        }
    },
    SINGLE_LINE_COMMENT {
        @Override
        public boolean match(String line) {
            return StringUtils.startsWith(line.trim(), SINGLE_LINE_COMMENT_START_STRING);
        }
    },
    MULTI_LINE_COMMENT {
        @Override
        public boolean match(String line) {
            return StringUtils.startsWith(line.trim(), MULTI_LINE_COMMENT_START_STRING);
        }

        @Override
        public boolean shouldKeepCount(String line) {
            return !StringUtils.endsWith(line, MULTI_LINE_COMMENT_ENDSTRING);
        }
    },
    VALID {
        @Override
        public boolean match(String line) {
            return !EMPTY.match(line) && !SINGLE_LINE_COMMENT.match(line) && !MULTI_LINE_COMMENT.match(line);
        }
    };

    public static final String SINGLE_LINE_COMMENT_START_STRING = "//";
    public static final String MULTI_LINE_COMMENT_START_STRING = "/*";
    public static final String MULTI_LINE_COMMENT_ENDSTRING = "*/";

    public abstract boolean match(String line);

    public boolean shouldKeepCount(String line) {
        return false;
    }

    private boolean keepCount;

    public boolean isKeepCount() {
        return this.keepCount;
    }

    public void setKeepCount(boolean keepCount) {
        this.keepCount = keepCount;
    }

    public LineState withKeepCount(boolean keepCount) {
        this.setKeepCount(keepCount);
        return this;
    }
}
