package com.qunar.fresh.shizhizhu.question4;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public class BlankCharCount extends AbstractCharCounter {
    @Override
    public boolean apply(Character character) {
        return Character.isWhitespace(character);
    }

    @Override
    public String getType() {
        return "空格";
    }

    @Override
    public boolean isDetailVisible() {
        return false;
    }
}
