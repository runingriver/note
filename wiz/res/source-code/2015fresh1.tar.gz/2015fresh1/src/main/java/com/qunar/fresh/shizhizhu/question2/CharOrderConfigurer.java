package com.qunar.fresh.shizhizhu.question2;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-11
 */
public class CharOrderConfigurer implements Configurer {
    private List<String> charOrderConfigList;

    public CharOrderConfigurer(LinkedHashMap<Integer, String> configMap) {
        charOrderConfigList = Lists.newArrayList(configMap.values());
        Collections.sort(charOrderConfigList);
    }

    @Override
    public String getValue(Integer index) {
        return charOrderConfigList.get(index);
    }
}
