package com.qunar.fresh.shizhizhu.exam2.command.executor;

import com.qunar.fresh.shizhizhu.exam2.CloseableIterator;
import com.qunar.fresh.shizhizhu.exam2.command.Command;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-19
 */
public interface CommandExecutor {
    CloseableIterator<String> execute(Command command);

    CloseableIterator<String> pipeExecute(Command command, CloseableIterator<String> pipeSource);
}