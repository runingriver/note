package com.qunar.fresh.shizhizhu.exam2;

import java.io.IOException;

import org.apache.commons.io.LineIterator;

/**
 * Created with IntelliJ IDEA. User: yuqi Date: 14-5-13 Time: 上午1:04
 */
public class CloseableLineIterator implements CloseableIterator<String> {

    private LineIterator lineIterator;

    public CloseableLineIterator(LineIterator lineIterator) {
        this.lineIterator = lineIterator;
    }

    @Override
    public void close() throws IOException {
        this.lineIterator.close();
    }

    @Override
    public boolean hasNext() {
        return this.lineIterator.hasNext();
    }

    @Override
    public String next() {
        return this.lineIterator.next();
    }

    @Override
    public void remove() {
        this.lineIterator.remove();
    }
}
