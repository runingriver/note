package com.qunar.fresh.shizhizhu.exam1;

import java.io.*;

import org.apache.commons.lang3.StringUtils;

import com.google.common.base.Preconditions;

/**
 * 只做示例使用
 * 
 * @see com.google.common.io.Files
 *
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-10-31
 */
public class IOUtils {

    /**
     * @see com.google.common.base.StandardSystemProperty#LINE_SEPARATOR;
     */
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");

    /**
     * @see com.google.common.base.Charsets#UTF_8
     */
    public static final String DEFAULT_CHARSET = "UTF-8";

    /**
     * @see org.apache.commons.io.IOUtils#closeQuietly(java.io.Closeable closeable)
     * @param closeable
     */
    public static void closeIgnoreException(Closeable... closeable) {
        for (Closeable c : closeable) {
            if (c != null) {
                try {
                    c.close();
                } catch (IOException e) {
                    // can not do anything
                }
            }
        }
    }

    public static <T> T readLines(String fileName, LineProcessor<T> lineProcessor) throws IOException {
        return readLines(fileName, lineProcessor, DEFAULT_CHARSET);
    }

    public static <T> T readLines(String fileName, LineProcessor<T> lineProcessor, String charset) throws IOException {
        Preconditions.checkArgument(StringUtils.isNotBlank(fileName));
        Preconditions.checkNotNull(lineProcessor);
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(IOUtils.class.getResourceAsStream(fileName),
                    charset));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                if (!lineProcessor.processLine(line)) {
                    break;
                }
            }
        } finally {
            IOUtils.closeIgnoreException(bufferedReader);
        }
        return lineProcessor.getResult();
    }

    public static void writeLines(String fileName, Iterable<String> lines) throws IOException {
        writeLines(fileName, lines, new Function<String, String>() {
            @Override
            public String apply(String line) {
                return line;
            }
        }, DEFAULT_CHARSET);
    }

    public static <F> void writeLines(String fileName, Iterable<F> lines, Function<F, String> function)
            throws IOException {
        writeLines(fileName, lines, function, DEFAULT_CHARSET);
    }

    public static <F> void writeLines(String fileName, Iterable<F> lines, Function<F, String> function, String charset)
            throws IOException {
        Preconditions.checkArgument(StringUtils.isNotBlank(fileName));
        Preconditions.checkNotNull(lines);
        BufferedWriter bufferedWriter = null;
        try {
            File file = new File(IOUtils.class.getResource("/").getFile() + fileName);
            bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), charset));
            for (F line : lines) {
                bufferedWriter.write(function.apply(line) + LINE_SEPARATOR);
            }
        } finally {
            IOUtils.closeIgnoreException(bufferedWriter);
        }
    }
}
