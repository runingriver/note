package com.qunar.fresh.shizhizhu.question4;

import java.util.Map;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public interface Reportable {
    public Map<String, Integer> getSummary();

    public Map<String, Integer> getDetail();

    public boolean isDetailVisible();
}
