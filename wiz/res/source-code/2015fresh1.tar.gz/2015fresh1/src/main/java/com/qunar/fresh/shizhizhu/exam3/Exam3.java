package com.qunar.fresh.shizhizhu.exam3;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Charsets;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Collections2;
import com.google.common.collect.Maps;
import com.google.common.io.Closer;
import com.google.common.io.Files;
import com.google.common.io.Resources;
import com.qunar.fresh.shizhizhu.exam3.utils.BeanUtils;
import com.qunar.fresh.shizhizhu.exam3.utils.PreconditionUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-23
 */
public class Exam3 {
    private static final Logger LOGGER = LoggerFactory.getLogger(Exam3.class);
    private static final String CONFIG_LOCATION = Resources.getResource("object.properties").getPath();
    private static final String XML_TEMPLATE_LOCATION = Resources.getResource("object.xml").getPath();
    private static final String FIELD_OUTPUT_LOCATION = Exam3.class.getResource("/").getFile() + "object.txt";
    public static final Joiner FIELD_JOINER = Joiner.on(":");
    public static final String FIELD_EXPRESSION = "\\$\\{(\\w+)\\}";
    private static ObjectBuilder objectBuilder = new XmlObjectBuilder();

    public static void main(String[] args) {
        try {
            Map<String, String> fieldValueMap = loadFieldValues(CONFIG_LOCATION);
            String xmlContent = Files.asCharSource(new File(XML_TEMPLATE_LOCATION), Charsets.UTF_8).read();
            String filledXmlContent = fillXmlContent(xmlContent, fieldValueMap);
            Object o = objectBuilder.build(new ByteArrayInputStream(filledXmlContent.getBytes()));
            outputFieldValue(FIELD_OUTPUT_LOCATION, o);
        } catch (IOException e) {
            LOGGER.error("fill object field value has error, ", e);
        } catch (IllegalAccessException e) {
            LOGGER.error("fill object field value has error, ", e);
        }
    }

    private static <T> void outputFieldValue(String fieldOutputLocation, T target) throws IOException,
            IllegalAccessException {
        PreconditionUtils.checkNotNull(fieldOutputLocation, target);
        Map<String, String> fieldMap = BeanUtils.getAllFieldValue(target);
        Collection<String> fieldPairList = Collections2.transform(fieldMap.entrySet(),
                new Function<Map.Entry<String, String>, String>() {
                    @Override
                    public String apply(Map.Entry<String, String> input) {
                        return FIELD_JOINER.join(input.getKey(), input.getValue());
                    }
                });
        Files.asCharSink(new File(fieldOutputLocation), Charsets.UTF_8).writeLines(fieldPairList);
    }

    public static String fillXmlContent(String xmlContent, Map<String, String> fieldValueMap) {
        PreconditionUtils.checkNotNull(xmlContent, fieldValueMap);
        Pattern pattern = Pattern.compile(FIELD_EXPRESSION);
        Matcher matcher = pattern.matcher(xmlContent);
        while (matcher.find()) {
            xmlContent = StringUtils.replace(xmlContent, matcher.group(), fieldValueMap.get(matcher.group(1)));
        }
        return xmlContent;
    }

    public static Map<String, String> loadFieldValues(String fieldValueLocation) throws IOException {
        PreconditionUtils.checkArgument(StringUtils.isNotBlank(fieldValueLocation));
        Properties properties = new Properties();
        Closer closer = Closer.create();
        try {
            BufferedReader fieldValueReader = closer.register(Files.asCharSource(new File(fieldValueLocation),
                    Charsets.UTF_8).openBufferedStream());
            properties.load(fieldValueReader);
        } finally {
            closer.close();
        }
        return Maps.fromProperties(properties);
    }
}
