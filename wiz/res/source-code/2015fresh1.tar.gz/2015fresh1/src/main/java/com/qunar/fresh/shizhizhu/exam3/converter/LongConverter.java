package com.qunar.fresh.shizhizhu.exam3.converter;

import org.apache.commons.lang3.math.NumberUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class LongConverter extends AbstractStringConverter<Long> {
    @Override
    public Long doForward(String input) {
        return NumberUtils.toLong(input);
    }

}
