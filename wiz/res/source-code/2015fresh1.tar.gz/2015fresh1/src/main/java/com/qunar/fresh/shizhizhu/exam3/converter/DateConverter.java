package com.qunar.fresh.shizhizhu.exam3.converter;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class DateConverter extends AbstractStringConverter<Date> {
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern(DATE_FORMAT);

    @Override
    public Date doForward(String input) {
        return dateTimeFormatter.parseDateTime(input).toDate();
    }

    @Override
    public String doBackward(Date date) {
        return new DateTime(date).toString(DATE_FORMAT);
    }
}
