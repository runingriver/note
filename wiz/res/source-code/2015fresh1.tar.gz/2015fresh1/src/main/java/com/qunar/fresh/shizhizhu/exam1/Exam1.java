package com.qunar.fresh.shizhizhu.exam1;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.google.common.collect.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-10-31
 */
public class Exam1 {

    private static final Logger LOGGER = LoggerFactory.getLogger(Exam1.class);
    private static final String UNORDER_MESSAGE_FILE_NAME = "/unorderedmsg.txt";
    private static final String ORDER_MESSAGE_FILE_NAME = "/orderedmsg.txt";
    private static final String MESSAGE_COUNT_FILE_NAME = "/count.txt";
    private static final String MESSAGE_ELEMENT_SEPARATOR = "    ";
    private static final String DATE_TEMPLATE = "yyyy-MM-dd HH:mm:ss";
    private static Comparator<Message> messageComparator = new Comparator<Message>() {
        @Override
        public int compare(Message m1, Message m2) {
            if (m1 == null && m2 == null) {
                return 0;
            }
            if (m1 == null) {
                return 1;
            }
            if (m2 == null) {
                return -1;
            }
            long time1 = m1.getSendTime().getTime();
            long time2 = m2.getSendTime().getTime();
            return time1 == time2 ? m1.getAuthor().compareTo(m2.getAuthor()) : time1 > time2 ? 1 : -1;
        }
    };

    public static void main(String[] args) throws IOException, ParseException {
        List<Message> messageList = loadMessage(UNORDER_MESSAGE_FILE_NAME);
        Collections.sort(messageList, messageComparator);
        writeMessage(ORDER_MESSAGE_FILE_NAME, messageList);
        Map<String, Integer> messageCount = countMessage(messageList);
        writeMessageCount(MESSAGE_COUNT_FILE_NAME, messageCount);
    }

    // can do it in lazy way
    private static List<Message> loadMessage(String fileName) throws IOException, ParseException {
        return IOUtils.readLines(fileName, new LineProcessor<List<Message>>() {
            private List<Message> messageList = new ArrayList<Message>();

            @Override
            public boolean processLine(String line) throws IOException {
                Message message = parseMessage(line);
                if (message != null) {
                    messageList.add(message);
                }
                return true;
            }

            @Override
            public List<Message> getResult() {
                return messageList;
            }
        });
    }

    private static Message parseMessage(String line) {
        String[] elements = line.split(MESSAGE_ELEMENT_SEPARATOR);
        if (elements.length == 3) {
            SimpleDateFormat format = new SimpleDateFormat(DATE_TEMPLATE);
            try {
                return new Message(elements[0], format.parse(elements[1]), elements[2]);
            } catch (ParseException e) {
                LOGGER.error("parse a date fail, line={}", line, e);
            }
        } else {
            LOGGER.error("message line format error, line={}", line);
        }
        return null;
    }

    private static void writeMessage(String fileName, List<Message> messageList) throws IOException {
        final SimpleDateFormat format = new SimpleDateFormat(DATE_TEMPLATE);
        Iterable<String> messageStrings = transform(messageList, new Function<Message, String>() {
            @Override
            public String apply(Message message) {
                return message.getAuthor() + MESSAGE_ELEMENT_SEPARATOR + format.format(message.getSendTime())
                        + MESSAGE_ELEMENT_SEPARATOR + message.getContent();
            }
        });
        IOUtils.writeLines(fileName, messageStrings);
    }

    private static Map<String, Integer> countMessage(final List<Message> messageList) {

        Map<String, Integer> countMap = new HashMap<String, Integer>();
        for (Message message : messageList) {
            Integer count = countMap.get(message.getAuthor());
            if (count == null) {
                countMap.put(message.getAuthor(), 1);
            } else {
                countMap.put(message.getAuthor(), count + 1);
            }
        }
        return countMap;

///////////////  use guava Multiset
//        Multiset<String> counter = HashMultiset.create();
//        counter.addAll(Lists.transform(messageList, new com.google.common.base.Function<Message, String>() {
//            @Override
//            public String apply(Message input) {
//                return input.getAuthor();
//            }
//        }));

    }

    private static void writeMessageCount(String fileName, Map<String, Integer> messageCount) throws IOException {
        Iterable<String> countStrings = transform(messageCount.entrySet(),
                new Function<Map.Entry<String, Integer>, String>() {
                    @Override
                    public String apply(Map.Entry<String, Integer> input) {
                        return input.getKey() + MESSAGE_ELEMENT_SEPARATOR + input.getValue();
                    }
                });
        IOUtils.writeLines(fileName, countStrings);
    }


    /**
     * @see com.google.common.collect.Iterables#transform(Iterable, com.google.common.base.Function)
     */
    private static <F, T> Iterable<T> transform(final Iterable<F> from, final Function<? super F, ? extends T> function) {

        List<T> to = new ArrayList<T>();
        for (F f : from) {
            to.add(function.apply(f));
        }
        return to;


///////////////  can do it in lazy way
//        return new Iterable<T>() {
//            @Override
//            public Iterator<T> iterator() {
//                final Iterator<F> iterator = from.iterator();
//                return new Iterator<T>() {
//                    @Override
//                    public boolean hasNext() {
//                        return iterator.hasNext();
//                    }
//
//                    @Override
//                    public T next() {
//                        return function.apply(iterator.next());
//                    }
//
//                    @Override
//                    public void remove() {
//                        iterator.remove();
//                    }
//                };
//            }
//        };
    }

}
