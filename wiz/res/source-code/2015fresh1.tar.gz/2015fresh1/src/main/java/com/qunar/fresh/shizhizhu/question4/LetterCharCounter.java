package com.qunar.fresh.shizhizhu.question4;

import org.apache.commons.lang3.CharUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public class LetterCharCounter extends AbstractCharCounter {

    public LetterCharCounter() {
        for (int i = 'a'; i <= 'z'; i++) {
            characterMap.put((char) i, 0);
        }
        for (int i = 'A'; i <= 'Z'; i++) {
            characterMap.put((char) i, 0);
        }
    }

    @Override
    public boolean apply(Character character) {
        return CharUtils.isAsciiAlpha(character);
    }

    @Override
    public String getType() {
        return "字母";
    }

    @Override
    public boolean isDetailVisible() {
        return true;
    }
}
