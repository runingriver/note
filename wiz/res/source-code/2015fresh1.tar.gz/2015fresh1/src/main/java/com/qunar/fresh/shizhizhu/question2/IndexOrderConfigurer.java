package com.qunar.fresh.shizhizhu.question2;

import java.util.Map;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-11
 */
public class IndexOrderConfigurer implements Configurer {
    private Map<Integer, String> indexOrderConfigMap;

    public IndexOrderConfigurer(Map<Integer, String> indexOrderConfigMap) {
        this.indexOrderConfigMap = indexOrderConfigMap;
    }

    @Override
    public String getValue(Integer index) {
        return indexOrderConfigMap.get(index);
    }
}
