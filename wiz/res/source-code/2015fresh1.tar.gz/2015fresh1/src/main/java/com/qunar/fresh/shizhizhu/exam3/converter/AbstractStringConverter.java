package com.qunar.fresh.shizhizhu.exam3.converter;

import com.google.common.base.Converter;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public abstract class AbstractStringConverter<T> extends Converter<String, T> {

    @Override
    public abstract T doForward(String input);

    @Override
    public String doBackward(T t) {
        return String.valueOf(t);
    }

}
