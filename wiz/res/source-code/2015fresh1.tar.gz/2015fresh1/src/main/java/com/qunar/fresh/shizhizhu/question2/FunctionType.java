package com.qunar.fresh.shizhizhu.question2;

import org.apache.commons.lang3.StringUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-11
 */
public enum FunctionType {
    NATURE_ORDER("natureOrder"), INDEX_ORDER("indexOrder"), CHAR_ORDER("charOrder"), CHAR_ORDER_DESC("charOrderDESC");

    FunctionType(String name) {
        this.name = name;
    }

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static FunctionType nameOf(String name) {
        for (FunctionType functionType : FunctionType.values()) {
            if (StringUtils.equals(functionType.getName(), name)) {
                return functionType;
            }
        }
        return null;
    }
}
