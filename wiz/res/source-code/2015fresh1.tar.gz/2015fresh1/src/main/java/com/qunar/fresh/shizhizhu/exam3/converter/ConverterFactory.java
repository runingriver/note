package com.qunar.fresh.shizhizhu.exam3.converter;

import java.util.Date;
import java.util.Map;

import com.google.common.collect.Maps;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class ConverterFactory {

    private static Map<String, AbstractStringConverter> convertMap = Maps.newHashMap();

    static {
        initFunctionMap();
    }

    private static void initFunctionMap() {
        convertMap.put(Boolean.class.getName(), new BooleanConverter());
        convertMap.put(Byte.class.getName(), new ByteConverter());
        convertMap.put(Character.class.getName(), new CharConverter());
        convertMap.put(Date.class.getName(), new DateConverter());
        convertMap.put(Double.class.getName(), new DoubleConverter());
        convertMap.put(Float.class.getName(), new FloatConverter());
        convertMap.put(Integer.class.getName(), new IntegerConverter());
        convertMap.put(Long.class.getName(), new LongConverter());
        convertMap.put(Short.class.getName(), new ShortConverter());
        convertMap.put(String.class.getName(), new StringConverter());
        convertMap.put("boolean", new BooleanConverter());
        convertMap.put("byte", new ByteConverter());
        convertMap.put("char", new CharConverter());
        convertMap.put("double", new DoubleConverter());
        convertMap.put("float", new FloatConverter());
        convertMap.put("int", new IntegerConverter());
        convertMap.put("long", new LongConverter());
        convertMap.put("short", new ShortConverter());
    }

    public static <T> AbstractStringConverter<T> get(String className) {
        AbstractStringConverter convert = convertMap.get(className);
        if (convert == null) {
            convert = convertMap.get(String.class.getName());
        }
        return convert;
    }
}
