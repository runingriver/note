package com.qunar.fresh.shizhizhu.question4;

import java.io.IOException;
import java.util.List;

import com.google.common.collect.Lists;
import com.google.common.io.LineProcessor;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public class ReportableLineProcessor implements LineProcessor<List<Reportable>> {
    private List<Reportable> reportableList = Lists.newArrayList();
    private List<LineCounter> lineCounterList = Lists.newArrayList();
    private List<CharCounter> charCounterList = Lists.newArrayList();

    public ReportableLineProcessor() {
        lineCounterList.add(new LineNumberCounter());
        charCounterList.add(new NumberCharCounter());
        charCounterList.add(new LetterCharCounter());
        charCounterList.add(new ChineseCharCounter());
        charCounterList.add(new BlankCharCount());
        reportableList.addAll(charCounterList);
        reportableList.addAll(lineCounterList);
    }

    @Override
    public boolean processLine(String line) throws IOException {
        for (LineCounter lineCounter : lineCounterList) {
            if (lineCounter.count(line)) {
                break;
            }
        }
        for (char character : line.toCharArray()) {
            for (CharCounter charCounter : charCounterList) {
                if (charCounter.count(character)) {
                    break;
                }
            }
        }
        return true;
    }

    @Override
    public List<Reportable> getResult() {
        return reportableList;
    }
}
