package com.qunar.fresh.shizhizhu.exam3.converter;

import org.apache.commons.lang3.math.NumberUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class IntegerConverter extends AbstractStringConverter<Integer> {
    @Override
    public Integer doForward(String input) {
        return NumberUtils.toInt(input);
    }

}
