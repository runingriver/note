package com.qunar.fresh.shizhizhu.exam3;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class BuildObjectException extends RuntimeException {
    public BuildObjectException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
