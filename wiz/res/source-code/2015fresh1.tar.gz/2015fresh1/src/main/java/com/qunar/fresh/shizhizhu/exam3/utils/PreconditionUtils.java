package com.qunar.fresh.shizhizhu.exam3.utils;

import java.util.List;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-29
 */
public class PreconditionUtils {
    public static <T> List<T> checkNotNull(T... conditions) {
        for (T condition : conditions) {
            Preconditions.checkNotNull(condition);
        }
        return Lists.newArrayList(conditions);
    }

    public static void checkArgument(boolean... expressions) {
        for (boolean expression : expressions) {
            Preconditions.checkArgument(expression);
        }
    }
}
