package com.qunar.fresh.shizhizhu.exam3.converter;

import org.apache.commons.lang3.CharUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class CharConverter extends AbstractStringConverter<Character> {
    @Override
    public Character doForward(String input) {
        return CharUtils.toChar(input);
    }
}
