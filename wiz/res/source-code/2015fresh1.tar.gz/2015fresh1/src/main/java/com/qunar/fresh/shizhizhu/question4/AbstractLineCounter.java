package com.qunar.fresh.shizhizhu.question4;

import java.util.Collections;
import java.util.Map;

import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public abstract class AbstractLineCounter implements Predicate<String>, LineCounter {
    protected int count = 0;

    @Override
    public boolean count(String line) {
        if (!apply(line)) {
            return false;
        } else {
            count++;
            return true;
        }
    }

    @Override
    public Map<String, Integer> getSummary() {
        return ImmutableMap.of(getType(), count);
    }

    @Override
    public Map<String, Integer> getDetail() {
        return Collections.emptyMap();
    }

}
