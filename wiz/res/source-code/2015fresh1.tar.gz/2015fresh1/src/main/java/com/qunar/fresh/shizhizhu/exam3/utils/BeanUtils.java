package com.qunar.fresh.shizhizhu.exam3.utils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.qunar.fresh.shizhizhu.exam3.converter.ConverterFactory;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-28
 */
public class BeanUtils {

    public static <T> void setFieldValue(Field field, String value, T target) throws IllegalAccessException {
        PreconditionUtils.checkNotNull(field, value, target);
        field.setAccessible(true);
        field.set(target, ConverterFactory.get(field.getType().getName()).doForward(value));
    }

    public static <T> String getFieldValue(Field field, T target) throws IllegalAccessException {
        PreconditionUtils.checkNotNull(field, target);
        field.setAccessible(true);
        return ConverterFactory.get(field.getType().getName()).doBackward(field.get(target));
    }

    public static <T> Map<String, String> getAllFieldValue(T target) throws IllegalAccessException {
        PreconditionUtils.checkNotNull(target);
        List<Field> fieldList = Lists.newArrayList(target.getClass().getDeclaredFields());
        Map<String, String> fieldMap = Maps.newHashMap();
        for (Field field : fieldList) {
            fieldMap.put(field.getName(), getFieldValue(field, target));
        }
        return fieldMap;
    }
}
