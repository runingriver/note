package com.qunar.fresh.shizhizhu.question2;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-11
 */
public class CharOrderDescConfigurer implements Configurer {
    private List<String> charOrderDescConfigList;

    public CharOrderDescConfigurer(LinkedHashMap<Integer, String> configMap) {
        charOrderDescConfigList = Lists.newArrayList(configMap.values());
        Collections.sort(charOrderDescConfigList, new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                return s2.compareTo(s1);
            }
        });
    }

    @Override
    public String getValue(Integer index) {
        return charOrderDescConfigList.get(index);
    }
}
