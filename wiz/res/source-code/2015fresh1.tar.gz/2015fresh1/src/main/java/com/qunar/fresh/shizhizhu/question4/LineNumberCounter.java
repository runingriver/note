package com.qunar.fresh.shizhizhu.question4;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public class LineNumberCounter extends AbstractLineCounter {
    @Override
    public boolean apply(String line) {
        return true;
    }

    @Override
    public String getType() {
        return "行数";
    }

    @Override
    public boolean isDetailVisible() {
        return false;
    }
}
