package com.qunar.fresh.shizhizhu.exam3;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.qunar.fresh.shizhizhu.exam3.utils.BeanUtils;
import com.qunar.fresh.shizhizhu.exam3.utils.PreconditionUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-27
 */
public class XmlObjectBuilder implements ObjectBuilder {

    @Override
    public <T> T build(InputStream configSource) {
        PreconditionUtils.checkNotNull(configSource);
        try {
            Map<String, String> propertyMap = parseXmlTemplate(configSource);
            Class<T> clazz = (Class<T>) Class.forName(propertyMap.get("class"));
            T instance = clazz.newInstance();
            return initFieldValue(propertyMap, clazz, instance);
        } catch (Exception e) {
            throw new BuildObjectException("this is an error during build the object from xml file", e);
        }
    }

    private <T> T initFieldValue(Map<String, String> propertyMap, Class<T> clazz, T instance)
            throws IllegalAccessException {
        List<Field> fieldList = Lists.newArrayList(clazz.getDeclaredFields());
        for (Field field : fieldList) {
            if (StringUtils.isNotEmpty(propertyMap.get(field.getName()))) {
                BeanUtils.setFieldValue(field, propertyMap.get(field.getName()), instance);
            }
        }
        return instance;
    }

    // TODO make it to a parser
    private Map<String, String> parseXmlTemplate(InputStream configSource) throws DocumentException {
        SAXReader saxReader = new SAXReader();
        Document document = saxReader.read(configSource);
        Element root = document.getRootElement();
        ImmutableMap.Builder<String, String> builder = ImmutableMap.builder();
        builder.put("class", root.attribute("class").getValue());
        List<Element> childList = root.elements();
        for (Element children : childList) {
            builder.put(children.attribute("name").getValue(), children.element("value").getStringValue());
        }
        return builder.build();
    }

}
