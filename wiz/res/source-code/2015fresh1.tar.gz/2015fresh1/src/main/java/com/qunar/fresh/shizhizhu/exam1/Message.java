package com.qunar.fresh.shizhizhu.exam1;

import java.util.Date;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-10-31
 */
public class Message {
    private String author;
    private Date sendTime;
    private String content;

    public Message(String author, Date sendTime, String content) {
        this.author = author;
        this.sendTime = sendTime;
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
