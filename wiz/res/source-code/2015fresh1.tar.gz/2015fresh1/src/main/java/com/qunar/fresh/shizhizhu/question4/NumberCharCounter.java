package com.qunar.fresh.shizhizhu.question4;

import org.apache.commons.lang3.CharUtils;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public class NumberCharCounter extends AbstractCharCounter {

    public NumberCharCounter() {
        for (int i = '0'; i <= '9'; i++) {
            characterMap.put((char) i, 0);
        }
    }

    @Override
    public boolean apply(Character character) {
        return CharUtils.isAsciiNumeric(character);
    }

    @Override
    public String getType() {
        return "数字";
    }

    @Override
    public boolean isDetailVisible() {
        return true;
    }
}
