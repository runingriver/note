package com.qunar.fresh.shizhizhu.question4;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-16
 */
public interface CharCounter extends Reportable {
    public boolean count(char character);

    public String getType();
}
