package com.qunar.fresh.shizhizhu.question5;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.*;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Range;
import com.google.common.io.Files;
import com.google.common.io.LineProcessor;
import com.google.common.io.Resources;
import com.google.common.primitives.Ints;

/**
 * @author shizhi.zhu
 * @email shizhi.zhu@qunar.com
 * @date 14-11-26
 */
public class Question5 {

    private static final Logger LOGGER = LoggerFactory.getLogger(Question5.class);
    private static final String FILTER_URL = "http://training.corp.qunar.com?age=13,45&gender=F&hometown=Tokyo&name=N";
    private static final String PEOPLE_FILE_LOCATION = Resources.getResource("people.txt").getFile();
    private static final String FILTER_PEOPLE_FILE_LOCATION = Question5.class.getResource("/").getFile() + "result.txt";

    public static void main(String[] args) {
        Map<String, String> conditionMap = Splitter.on("&").withKeyValueSeparator("=")
                .split(StringUtils.substringAfter(FILTER_URL, "?"));
        try {
            List<Person> personList = loadPerson(PEOPLE_FILE_LOCATION);
            Predicate<Person> personPredicate = initPersonPredicate(conditionMap);
            Collection<Person> filterPersonList = Collections2.filter(personList, personPredicate);
            outputFilterPerson(FILTER_PEOPLE_FILE_LOCATION, filterPersonList);
        } catch (IOException e) {
            LOGGER.error("filter people data fail, ", e);
        }
    }

    private static void outputFilterPerson(String filterPeopleFileLocation, Collection<Person> filterPersonList)
            throws IOException {
        Files.asCharSink(new File(filterPeopleFileLocation), Charsets.UTF_8).writeLines(
                Collections2.transform(filterPersonList, new Function<Person, String>() {
                    @Override
                    public String apply(Person person) {
                        return Joiner.on("|").join(person.getName(), person.getAge(), person.getGender(),
                                person.getHometown());
                    }
                }));
    }

    private static Predicate<Person> initPersonPredicate(final Map<String, String> conditionMap) {
        Predicate<Person> genderPredicate = new Predicate<Person>() {
            @Override
            public boolean apply(Person person) {
                return StringUtils.equals(conditionMap.get("gender"), person.getGender());
            }
        };
        Predicate<Person> hometownPredicate = new Predicate<Person>() {
            @Override
            public boolean apply(Person person) {
                return StringUtils.equals(conditionMap.get("hometown"), person.getHometown());
            }
        };
        Predicate<Person> namePredicate = new Predicate<Person>() {
            @Override
            public boolean apply(Person person) {
                return person.getName().contains(conditionMap.get("name"));
            }
        };
        Predicate<Person> agePredicate = new Predicate<Person>() {
            private List<String> ageList = Splitter.on(",").splitToList(conditionMap.get("age"));
            private Range<Integer> ageRange = Range
                    .closed(Ints.tryParse(ageList.get(0)), Ints.tryParse(ageList.get(1)));

            @Override
            public boolean apply(Person person) {
                return ageRange.contains(person.getAge());
            }
        };
        return Predicates.and(genderPredicate, hometownPredicate, namePredicate, agePredicate);
    }

    private static List<Person> loadPerson(String peopleFileLocation) throws IOException {
        return Files.readLines(new File(peopleFileLocation), Charsets.UTF_8, new LineProcessor<List<Person>>() {
            public List<Person> personList = Lists.newArrayList();
            private Splitter personElementSplitter = Splitter.on(",");

            @Override
            public boolean processLine(String line) throws IOException {
                List<String> personElementList = personElementSplitter.splitToList(line);
                personList.add(new Person(personElementList.get(0), Ints.tryParse(personElementList.get(1)),
                        personElementList.get(2), personElementList.get(3)));
                return true;
            }

            @Override
            public List<Person> getResult() {
                return personList;
            }
        });
    }
}
