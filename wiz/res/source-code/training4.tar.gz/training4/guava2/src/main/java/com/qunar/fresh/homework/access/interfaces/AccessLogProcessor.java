package com.qunar.fresh.homework.access.interfaces;

import com.google.common.base.Splitter;
import com.google.common.collect.*;
import com.qunar.fresh.homework.access.po.AccessLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * 对象处理器,将Access对象从文件中读取并封装起来
 * 这里做具体的业务逻辑
 */
public class AccessLogProcessor implements Processor{
    public static final Logger log = LoggerFactory.getLogger(AccessLogProcessor.class);
    private Map<AccessLog, Integer> accessLogMap;
    private Map<String, Integer> accessLogURLMap;

    public static final class AccessLogProcessorSingleton {
        private static final AccessLogProcessor INSTANCE = new AccessLogProcessor();
    }

    public static AccessLogProcessor getInstance() {
        return AccessLogProcessorSingleton.INSTANCE;
    }

    public Object process(Object o) {
        FileProcessor fileProcessor = FileProcessor.getInstance();
        fileProcessor.process(o);
        accessLogMap = fileProcessor.getCountMap();
        accessLogURLMap = fileProcessor.getURLMap();
        //log.debug("accessLogMap size:{};accessLogMap size:{}",map.size(),accessLogMap.size());
        if (accessLogMap != null && accessLogMap !=null) {
            return true;
        }
        return false;
    }

    public Long getTotalRequest() {
        return FileProcessor.getTotalLine();
    }

    public Long getPostRequest() {
        return FileProcessor.getTotalPost();
    }

    public Long getGetRequest() {
        return FileProcessor.getTotalGet();
    }

    public Multimap<String, String> getClassfyURL() {
        Multimap<String, String> classfyURLMap = ArrayListMultimap.create();

        List<Map.Entry<String, Integer>> list
                = new ArrayList<Map.Entry<String, Integer>>(accessLogURLMap.entrySet());
        List<String> urlList;
        for (Map.Entry<String, Integer> entry : list) {
            urlList = Splitter.on('/')
                    .trimResults()
                    .omitEmptyStrings()
                    .splitToList(entry.getKey());
            classfyURLMap.put(urlList.get(0), entry.getKey());
        }

        return classfyURLMap;
    }

    /**
     * 堆排序，输出Topk
     * @return  输出的tok，k-HTTP接口，v-请求数量
     */
    public Map<String,Integer> getTopk(int k) {
        if (accessLogMap == null) {
            return null;
        }
        List<Map.Entry<String, Integer>> list
                = new ArrayList<Map.Entry<String, Integer>>(accessLogURLMap.entrySet());
        getTopKByHeapsort(list,k);

        //取到topk，然后封装，返回
        int count = list.size() < k ? list.size() : k;
        Map<String, Integer> topK = Maps.newHashMap();
        for (int i=0;i<k;i++) {
            topK.put(list.get(i).getKey(),list.get(i).getValue());
        }
        return topK;
    }

    /**
     * 在list集合中创建小根堆，list集合中前k个元素即为结果
     *
     * @param list 待排序集合
     * @param k    取最大的k个元素
     */
    private static void getTopKByHeapsort(List<Map.Entry<String, Integer>> list, int k) {
        if (list == null || list.size() < k) {
            return;
        }
        //先将前k个元素建成小根堆
        buildMinHeap(list, k);
        int count = list.size();
        for (int i = k; i < count; i++) {
            if (list.get(0).getValue() < list.get(i).getValue()) {
                Collections.swap(list, 0, i);
                //小根堆的再平衡
                minHeapShift(list, 0, k);
            }
        }
    }

    /**
     * 在原数组中将前k个元素建成一个最小堆，以0开始。
     *
     * @param list 要排序的集合
     * @param k    前k个元素
     */
    private static void buildMinHeap(List<Map.Entry<String, Integer>> list, int k) {
        for (int i = k / 2 - 1; i >= 0; i--) {
            minHeapShift(list, i, k);
        }
    }

    /**
     * 调整堆节点，该方法只调整指定的index节点,没有考虑值相等按照字符排序
     *
     * @param list  要排序的集合
     * @param index 要调整的节点
     * @param k     堆的大小
     */
    private static void minHeapShift(List<Map.Entry<String, Integer>> list, int index, int k) {
        int i, j;
        boolean finished = false;
        Map.Entry<String, Integer> temp = list.get(index);
        i = index;
        j = i * 2 + 1;
        while (j < k && !finished) {
            if ((j + 1) < k && list.get(j).getValue() > list.get(j + 1).getValue()) {
                j++;
            }
            if (temp.getValue() <= list.get(j).getValue()) {
                finished = true;
            } else {
                list.set(i, list.get(j));
                i = j;
                j = 2 * i+1;
            }
        }
        list.set(i, temp);
    }
}
