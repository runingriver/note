package com.qunar.fresh.homework.access.po;

import com.google.common.base.MoreObjects;
import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import java.util.List;

/**
 * URL对象，描述URL相同的转换这一类对象
 * 空间时间考虑：将URL相同的视为统一对象，请求参数和方法可以不同
 */
public class AccessLog {
    private List<String> method;
    private String url;
    private List<String> parameter;
    public static final int PARMETER_LENGTH = 1000;    //List的初始化参数

    public AccessLog(Builder builder) {
        this.method = builder.method;
        this.parameter = builder.parameter;
        this.url = builder.url;
    }

    public List<String> getMethod() {
        return method;
    }

    public List<String> getParameter() {
        return parameter;
    }

    public String getUrl() {
        return url;
    }


    @Override
    public boolean equals(Object obj) {
        if (null == obj) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AccessLog)) {
            return false;
        }
        AccessLog accessLog = (AccessLog) obj;
        //只要url相同我们就认为两个对象相等
        if (!this.url.equals(accessLog.getUrl())) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).addValue(method)
                .addValue(' ').addValue(url).addValue('?')
                .addValue(parameter).toString();
    }

    @Override
    public int hashCode() {
        //我希望只要url相等，hashcode就相同
        int result = url != null ? url.hashCode() : 0;
        return result;
    }


    public static final class Builder {
        private List<String> method;
        private List<String> parameter;
        private String url;

        public Builder method(String method) {
            Preconditions.checkNotNull(method, "HTTP method may not null");
            if (this.method == null) {
                this.method = Lists.newArrayListWithCapacity(PARMETER_LENGTH);
            }
            this.method.add(method);
            return this;
        }

        public Builder url(String url) {
            Preconditions.checkNotNull(url, "HTTP URL could not be null.");
            this.url = url;
            return this;
        }

        //method和parameter应该是一一对应的关系
        public Builder parameter(String parameter) {
            if (this.parameter == null) {
                this.parameter = Lists.newArrayListWithCapacity(PARMETER_LENGTH);
            }
            if (Strings.isNullOrEmpty(parameter)) {
                this.parameter.add("");
            } else {
                this.parameter.add(parameter);
            }
            return this;
        }

        public AccessLog builder() {
            return new AccessLog(this);
        }
    }

    public static Builder newBuilder() {
        return new Builder();
    }
}
