package com.qunar.fresh.homework.access.interfaces;

/**
 * 日志处理器，将文件内容解析出来，然后封装成对象
 *
 */
public interface Processor {
    Object process(Object o);
}
