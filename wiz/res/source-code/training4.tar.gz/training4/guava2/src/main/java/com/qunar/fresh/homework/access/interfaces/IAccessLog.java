package com.qunar.fresh.homework.access.interfaces;

import com.google.common.collect.Multimap;

import java.util.Map;

/**
 * 定义获取日志相关统计信息的统一接口.
 */
public interface IAccessLog {
    //enum REQUEST{PSOT, GET};
    /**
     * 获取请求总量
     */
    Long getTotalRequest();

    /**
     * 获取请求最频繁的k个HTTP接口,及其相应的请求数量
     * @param k 请求最频繁的k个HTTP接口
     * @return  K-接口名，V-请求总量
     */
    Map<String, Integer> getTopKVisited(int k);

    /**
     * 获取Post请求总量
     */
    Long countPostRequest();

    /**
     * 获取get请求总量
     */
    Long countGetRequest();

    /**
     * URI 格式均为 /AAA/BBB 或者 /AAA/BBB/CCC 格式，按 AAA 分类，输出各个类别下 URI
     */
    Multimap<String, String> classifyURL();
}
