package com.qunar.fresh.homework.access.interfaces;

import com.google.common.base.Preconditions;
import com.google.common.collect.Multimap;
import com.qunar.fresh.homework.access.po.AccessLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 日志操作接口实现类，把事情丢给AccessLogProcess去做
 */
public class AccessLogImpl implements IAccessLog {
    public static final Logger log = LoggerFactory.getLogger(AccessLogImpl.class);

    public static final class AccessLogImplSingleton {
        private static final AccessLogImpl INSTANCE = new AccessLogImpl();
    }

    public static AccessLogImpl getInstance(String path) {
        //参数检查放到FileProcess中
        init(path);
        return AccessLogImplSingleton.INSTANCE;
    }

    private static void init(String path) {
        Boolean initSuccessed = (Boolean) AccessLogProcessor.getInstance().process(path);
        if (!initSuccessed) {
            log.error("load file to read as object failed");
        }
    }

    //处理器处理相关事情
    public Long getTotalRequest() {
        return AccessLogProcessor.getInstance().getTotalRequest();
    }

    public Map<String, Integer> getTopKVisited(int k) {
        Preconditions.checkArgument(k>0,"check the parameter of k,it must be positive");
        return AccessLogProcessor.getInstance().getTopk(k);
    }

    public Long countPostRequest() {
        return AccessLogProcessor.getInstance().getPostRequest();
    }

    public Long countGetRequest() {
        return AccessLogProcessor.getInstance().getGetRequest();
    }

    public Multimap<String, String> classifyURL() {
        return AccessLogProcessor.getInstance().getClassfyURL();
    }
}
