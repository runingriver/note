package com.qunar.fresh.homework.lru;

import com.google.common.base.MoreObjects;
import com.google.common.base.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

/**
 * 实现LRU缓存算法
 */
public abstract class LRUCached<K, V> implements ICache<K, V> {

    public static final Logger log = LoggerFactory.getLogger(LRUCached.class);
    private final LinkedHashMap<K, V> cachedMap;

    private int maxSize;    //总大小
    private int usedSize;   //已经使用的大小
    private int putCount;   //主动写入缓存次数
    private int createCount;    //K-V创建次数
    private int removeCount;    //移除次数
    private int hitCount;   //命中次数
    private int missCount;  //未命中次数

    public LRUCached(int maxSize) {
        Preconditions.checkArgument(maxSize > 0, "the maxSize should be positive");

        this.maxSize = maxSize;
        this.cachedMap = new LinkedHashMap<K, V>(maxSize * 4 / 3, .075f, true);
    }

    public final V get(K key)  throws ExecutionException{
        Preconditions.checkArgument(key != null, "the key is null.");
        V mapValue;
        synchronized (this) {
            mapValue = cachedMap.get(key);
            if (null == mapValue) {
                missCount++;
            } else {
                hitCount++;
                return mapValue;
            }
        }

        //没有命中,尝试写入返回
        V createdValue = create(key);
        createCount++;
        if (null == createdValue) {
            return null;
        }

        putNewEntry(key, createdValue);

        return createdValue;
    }

    public abstract V create(K key);

    public final void put(K key, V value) throws ExecutionException{
        Preconditions.checkArgument(key != null && value != null, "key and value must not none.");
        putNewEntry(key, value);
    }

    private void putNewEntry(K key, V value) {
        synchronized (this) {
            checkedAndRemove();
            // 重新存入
            cachedMap.put(key, value);
            putCount++;
            usedSize++;
        }
    }

    /**
     * 检查队列是否满，满-删除最久未使用。
     */
    private void checkedAndRemove(){
        K key;
        synchronized (this) {
            // 判读是否达到最大内存
            if (usedSize < maxSize || cachedMap.isEmpty()) {
                return;
            }
        }

        // 移除头部元素，即不经常使用元素
        Map.Entry<K, V> headerElement = cachedMap.entrySet().iterator().next();
        key = headerElement.getKey();
        cachedMap.remove(key);

        usedSize--;
        removeCount++;
    }


    /**
     * 移除缓存中的k-v
     * @param key 要移除的key
     * @return null-没找到，value-key对应的value
     */
    public final V remove(K key) {
        Preconditions.checkArgument(key != null, "the key must not be null.");
        V previous;
        synchronized (this) {
            previous = cachedMap.remove(key);
        }
        return previous;
    }


    /**
     * 移除所有缓存
     */
    public final void removeAll() {
        for (Map.Entry<K, V> entry : cachedMap.entrySet()) {
            remove(entry.getKey());
        }
    }

    @Override
    public synchronized final String toString() {
        int accesses = hitCount + missCount;
        int hitPercent = accesses != 0 ? (100 * hitCount / accesses) : 0;
        return MoreObjects.toStringHelper(this).add("maxSize", maxSize)
                .add("used count",usedSize).add("put count",putCount)
                .add("create count", createCount).add("remove count", removeCount)
                .add("hit count", hitCount).add("miss count", missCount)
                .add("hit percent", hitPercent).addValue("%").toString();
    }

}
