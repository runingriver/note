package com.qunar.fresh.homework.access.main;

import com.google.common.collect.Multimap;
import com.qunar.fresh.homework.access.interfaces.AccessLogImpl;
import com.qunar.fresh.homework.access.interfaces.IAccessLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 根据接口，获取相关信息，并输出到日志中
 */
public class AccessEntry {
    public static final Logger log = LoggerFactory.getLogger(AccessEntry.class);
    public static final String LOG_FILE_NAME = "access.log";
    public static final String LOG_PATH = AccessLogImpl.class.getClassLoader().getResource(LOG_FILE_NAME).getPath();

    public static void main(String[] args) {

        /* 日志保存在根目录的log目录下 */
        IAccessLog accessLog = AccessLogImpl.getInstance(LOG_PATH);
        
        //获取请求总量
        Long total = accessLog.getTotalRequest();
        log.info("the total request is:{}", total);

        //统计POST和GET请求量
        Long postcount = accessLog.countPostRequest();
        log.info("the total Get request is:{}", postcount);
        Long getcount = accessLog.countGetRequest();
        log.info("the total Post request is:{}", getcount);


        //获取请求最频繁的10个HTTP接口
        Map<String, Integer> top10Visited = accessLog.getTopKVisited(10);
        outputTopKVisited(top10Visited);

        //分类统计URL
        Multimap<String, String> urlClassified = accessLog.classifyURL();
        outputClassfiedURL(urlClassified);
    }


    public static void outputTopKVisited(Map<String, Integer> top10Visited) {
        log.info("------------------------------------------------------------------------");
        log.info("the top 10 HTTP interface is:");
        for (Map.Entry<String, Integer> entry : top10Visited.entrySet()) {
            log.info("Interface:{},Number:{}",entry.getKey(), entry.getValue());
        }
    }

    public static void outputClassfiedURL(Multimap<String, String> urlClassified) {
        log.info("------------------------------------------------------------------------");
        log.info("the classified result is:");
        for (String key : urlClassified.keySet()) {
            log.info("the {} URL classes:",key);
            for (String value : urlClassified.get(key)) {
                log.info("--{}:{}",key,value);
            }
        }
    }
}
