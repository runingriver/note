package com.qunar.fresh.homework.access.interfaces;

import com.google.common.base.Charsets;
import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.google.common.io.Files;
import com.google.common.io.LineProcessor;
import com.qunar.fresh.homework.access.po.AccessLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.Map;

/**
 * 各种请求量都在这里获取，将URL和对应访问次数封装成map
 *  这里额外加入了K-对象，V-访问次数的Map，将完整的信息保存起来，
 *  将接口相同的视为同一对象，访问方法和参数用List保存，节约大量字符串的空间。
 */
public class FileProcessor implements Processor {
    public static final Logger log = LoggerFactory.getLogger(FileProcessor.class);
    private static Long totalLine = 0L;
    private static Long totalGet = 0L;
    private static Long totalPost = 0L;
    private Map<AccessLog, Integer> accessLogCountMap = Maps.newHashMap();
    private Map<String, Integer> accessLogURLMap = Maps.newHashMap();

    public static final class FileProcessorSingleton {
        private static final FileProcessor INSTANCE = new FileProcessor();
    }

    public static FileProcessor getInstance() {
        return FileProcessor.FileProcessorSingleton.INSTANCE;
    }

    public Map<AccessLog, Integer> getCountMap() {
        return accessLogCountMap;
    }

    public Map<String, Integer> getURLMap() {
        return accessLogURLMap;
    }

    public static Long getTotalGet() {
        return totalGet;
    }

    public static Long getTotalLine() {
        return totalLine;
    }

    public static Long getTotalPost() {
        return totalPost;
    }

    /**
     * 文件处理器，将数据从文件中读取到Map中
     * @param o
     * @return
     */
    public Object process(Object o){
        String path = (String) o;
        File file = new File(path);
        if (!file.exists() || file.isDirectory()) {
            log.info("please check you file path.");
            return null;
        }
        try {
            return Files.readLines(file, Charsets.UTF_8, new LineProcessor<Boolean>() {

                public boolean processLine(String line) throws IOException {
                    String stringLine = line.trim().toLowerCase();
                    if (!Strings.isNullOrEmpty(stringLine)) {
                        totalLine++;
                        AccessLog accessLog = readToObject(stringLine);
                        addAccessLogToMap(accessLog);
                        addURLToURLMap(accessLog);
                    }
                    return true;
                }

                public Boolean getResult() {
                    return true;
                }
            });
        } catch (IOException e) {
            log.error("IOException{}",e.getCause());
            return null;
        }
    }

    /**
     * 将读到的字符串封装成对象
     * @param line  读到的String line
     * @return  AccessLog对象
     */
    public AccessLog readToObject(String line) {
        int spaceIndex = line.indexOf(' ');
        String method = line.substring(0,spaceIndex );
        String url;
        String parameter;
        if (line.contains("?")) {
            int dotIndex = line.indexOf('?');
            url = line.substring(spaceIndex + 1, dotIndex);
            parameter = line.substring(dotIndex + 1);
        } else {
            url = line.substring(spaceIndex + 1);
            parameter = "";
        }
        //统计get和post总量
        if (method.equals("get")) {
            totalGet++;
        } else {
            totalPost++;
        }

        return AccessLog.newBuilder().method(method).parameter(parameter).url(url).builder();
    }

    /**
     * 将日志对象和访问次数，方法，参数保存起来，作可扩展考虑
     * @param accessLog 日志对象
     */
    public void addAccessLogToMap(AccessLog accessLog) {
        Preconditions.checkNotNull(accessLog, "accessLog is null when add to map.");
        if (accessLogCountMap.containsKey(accessLog)) {
            accessLogCountMap.put(accessLog, accessLogCountMap.get(accessLog) + 1);
        } else {
            accessLogCountMap.put(accessLog, 1);
        }
    }

    /**
     * 将URL和对应请求数量保存起来，方便更快速的分类和获取Topk
     * @param accessLog 日志对象
     */
    public void addURLToURLMap(AccessLog accessLog) {
        Preconditions.checkNotNull(accessLog, "accessLog is null when add to map.");
        if (accessLogURLMap.containsKey(accessLog.getUrl())) {
            accessLogURLMap.put(accessLog.getUrl(), accessLogURLMap.get(accessLog.getUrl()) + 1);
        } else {
            accessLogURLMap.put(accessLog.getUrl(), 1);
        }
        //log.debug("key:{};value:{}",accessLog.getUrl(),accessLogURLMap.get(accessLog.getUrl()));
    }

}
