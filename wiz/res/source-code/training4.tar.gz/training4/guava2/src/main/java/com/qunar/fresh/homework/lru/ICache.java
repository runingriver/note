package com.qunar.fresh.homework.lru;

import java.util.concurrent.ExecutionException;

/**
 * LRU最近最少使用缓存算法，接口
 */
public interface ICache<K,V> {

    /**
     * 从缓存中获取指定K的Value
     * @param key  要查找的key
     * @return  null-外部函数创建元素不成功
     */
    V get(K key) throws ExecutionException;

    /**
     * 将指定元素put到缓存中
     * @param key   元素key
     * @param value key对应的值
     */
    void put(K key,V value) throws ExecutionException;

    /**
     * 从缓存中移除一个元素
     * @param key   要移除的元素key
     * @return  返回移除元素的值,null-没找到
     */
    V remove(K key);

    /**
     * 移除所有缓存
     */
    public void removeAll();

}
