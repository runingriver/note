package com.qunar.fresh.homework.lru;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ExecutionException;

public class TestCacheExample {
    public static final Logger log = LoggerFactory.getLogger(TestCacheExample.class);
    public static void main(String[] args) {

        int max = 10;
        ICache<String, Integer> cache = new LRUCached<String, Integer>(max) {
            @Override
            public Integer create(String key) {
                return getFormOutside(key);
            }
        };

        try {
            cache.put("1", 123);
            cache.put("2", 123);
            cache.put("3", 123);
            cache.put("4", 123);
            cache.put("5", 123);
            cache.put("6", 123);
            cache.put("7", 123);
            cache.put("8", 123);

            Integer a = cache.get("5");
            Integer b = cache.get("9");
            Integer c = cache.get("10");
            Integer d = cache.get("11");
            Integer e = cache.get("1");
            log.info(cache.toString());
        } catch (ExecutionException e) {
            log.error("error,{}",e.getCause(),e);
        }
    }


    private static Integer getFormOutside(String key) {
        return 10;
    }


}
