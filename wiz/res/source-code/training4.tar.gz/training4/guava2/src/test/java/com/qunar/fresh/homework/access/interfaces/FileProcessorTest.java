package com.qunar.fresh.homework.access.interfaces; 

import com.qunar.fresh.homework.access.po.AccessLog;
import org.apache.commons.logging.Log;
import org.junit.Test;
import org.junit.Before; 
import org.junit.After;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileProcessorTest {
    public static final Logger log = LoggerFactory.getLogger(FileProcessorTest.class);
    FileProcessor fp;

@Before
public void before() throws Exception {
    fp = FileProcessor.getInstance();
} 

@After
public void after() throws Exception { 
} 


@Test
public void testGetInstance() throws Exception { 

} 


@Test
public void testProcess() throws Exception { 

} 


@Test
public void testReadToObject() throws Exception {
    AccessLog accessLog = fp.readToObject("GET /location/getOneAuthCity.htm?arg1=var1&arg2=var2");
    log.info(accessLog.toString());

} 


} 
