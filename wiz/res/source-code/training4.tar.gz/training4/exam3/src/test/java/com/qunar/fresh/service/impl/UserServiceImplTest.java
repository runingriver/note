package com.qunar.fresh.service.impl;

import com.qunar.fresh.service.UserService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/spring/mvc-service.xml"
        , "classpath:/spring/spring-mybatis.xml"})
public class UserServiceImplTest {

    @Resource
    UserService userService;

    @Test
    public void verifyUser() throws Exception {
        String rst = userService.verifyUser("san.zhang", "123456");
        String rst2 = userService.verifyUser("123", "123");

        Assert.assertEquals("success", rst);
        Assert.assertEquals("success", rst2);
    }

}