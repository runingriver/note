package com.qunar.fresh.service.impl;

import com.google.common.collect.Lists;
import com.qunar.fresh.model.FileDiff;
import com.qunar.fresh.service.FileDiffService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(value = {"classpath:/spring/spring-mybatis.xml", "classpath:/spring/mvc-service.xml"})
public class FileDiffServiceImplTest {

    public static final Logger log = LoggerFactory.getLogger(FileDiffServiceImplTest.class);

    @Resource
    FileDiffService fileDiffService;

    @Before
    public void setUp() throws Exception {
        fileDiffService = new FileDiffServiceImpl();
    }

    @Test
    public void insertFileDiffService() throws Exception {
        List<String> source = Lists.newArrayList("a1=x", "a2=y", "a3=z");
        List<String> target = Lists.newArrayList("a1=x", "a3=x", "a4=n");

        List<String> diff = FileDiffServiceImpl.compareFileDifference(source, target);

        log.debug(diff.toString());
    }

    @Test
    public void queryFileDiffByPageServiceTest() throws Exception {
        if (fileDiffService == null) {
            log.info("======注入失败");
        }
//        List<FileDiff> diffList = fileDiffService.queryFileDiffByPageService(0, 2);
//        log.info("size:{}", diffList.size());
//        for (FileDiff diff : diffList) {
//            log.debug("=====FileDiff:{}", diff.toString());
//        }

    }

}