package com.qunar.fresh.service;


import com.qunar.fresh.model.User;

public interface UserService {
    String verifyUser(User user);

    String verifyUser(String userName, String password);
}
