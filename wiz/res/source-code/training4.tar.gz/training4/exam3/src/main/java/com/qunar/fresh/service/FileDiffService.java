package com.qunar.fresh.service;


import com.qunar.fresh.model.FileDiff;

import java.util.List;

public interface FileDiffService {

    List<FileDiff> queryAllFileDiffService();

    int queryTotalFileDiffCountService();

    List<FileDiff> queryFileDiffByPageService(int start, int size);

    int insertFileDiffService(List<String> source,String sourceName,List<String> target,String targetNmae);

    int deleteFileDiffByIdService(int id);
}
