package com.qunar.fresh.web;

import com.qunar.fresh.model.User;
import com.qunar.fresh.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class UserController {
    public static final Logger log = LoggerFactory.getLogger(UserController.class);

    @Resource
    UserService userService;

    @RequestMapping(value = "/user/login", method = RequestMethod.GET)
    public String requestAdd() {
        return "/user/login";
    }

    @RequestMapping(value = "/user/verify", method = RequestMethod.POST)
    public String add(@ModelAttribute("user") @Validated User user
            , BindingResult bindingResult, Model model, HttpSession session) throws Exception {

        //初始参数合法检查
        if (bindingResult.hasErrors()) {
            List<ObjectError> allErrors = bindingResult.getAllErrors();
            log.debug("error size:{}", allErrors.size());
            String errorMsg = allErrors.get(allErrors.size() - 1).getDefaultMessage().toString();
            model.addAttribute("inputError", errorMsg);
            return "/errors/error";
        }

        String result = userService.verifyUser(user);

        /*获取结果提示用户错误信息！*/
        Assert.isTrue(result.equals("success"), result);

        session.setAttribute("userName",user.getUserName());

        return "redirect:/file/list";
    }

}
