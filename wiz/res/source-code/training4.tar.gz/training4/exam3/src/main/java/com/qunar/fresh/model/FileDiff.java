package com.qunar.fresh.model;


import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.validation.constraints.NotNull;
import java.util.Date;

public class FileDiff {
    private int id;
    @NotNull(message = "源文件的文件名不能为空")
    private String sourceName;

    @NotNull(message = "目标文件的文件名不能为空")
    private String targetName;

    @NotNull(message = "源文件的文件内容不能为空")
    private String sourceContent;

    @NotNull(message = "目标文件的文件内容不能为空")
    private String targetContent;

    private String diff;
    private Date diffTime;
    private int status;

    public Date getDiffTime() {
        return diffTime;
    }

    public void setDiffTime(Date diffTime) {
        this.diffTime = diffTime;
    }

    public String getDiff() {
        return diff;
    }

    public void setDiff(String diff) {
        this.diff = diff;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSourceContent() {
        return sourceContent;
    }

    public void setSourceContent(String sourceContent) {
        this.sourceContent = sourceContent;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getTargetContent() {
        return targetContent;
    }

    public void setTargetContent(String targetContent) {
        this.targetContent = targetContent;
    }

    public String getTargetName() {
        return targetName;
    }

    public void setTargetName(String targetName) {
        this.targetName = targetName;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
