package com.qunar.fresh.service.impl;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.qunar.fresh.dao.FileDiffDao;
import com.qunar.fresh.model.FileDiff;
import com.qunar.fresh.service.FileDiffService;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service
public class FileDiffServiceImpl implements FileDiffService {
    public static final Logger log = LoggerFactory.getLogger(FileDiffServiceImpl.class);

    @Resource
    FileDiffDao fileDiffDao;

    @Override
    public List<FileDiff> queryAllFileDiffService() {
        List<FileDiff> diffList = fileDiffDao.selectAllFileDiff();
        //返回结果为null，返回一个0长度的对象
        return diffList==null?Lists.<FileDiff>newArrayList():diffList;
    }

    @Override
    public int queryTotalFileDiffCountService() {
        return fileDiffDao.selectTotalFileDiffCount();
    }

    @Override
    public List<FileDiff> queryFileDiffByPageService(int start, int size) {
        //滤掉非法输入
        start = start < 0 ? 0 : start;
        size = size < 1 ? 1 : size;
        List<FileDiff> diffListPage = fileDiffDao.selectFileDiffByPage(new RowBounds(start, size));
        return diffListPage==null?Lists.<FileDiff>newArrayList():diffListPage;
    }

    @Override
    public int insertFileDiffService(List<String> source,String sourceName,List<String> target,String targetName) {
        FileDiff fileDiff = new FileDiff();
        fileDiff.setSourceName(sourceName);
        fileDiff.setTargetName(targetName);
        fileDiff.setSourceContent(htmlLineSeparator(source));
        fileDiff.setTargetContent(htmlLineSeparator(target));
        fileDiff.setDiff(htmlLineSeparator(compareFileDifference(source,target)));
        fileDiff.setDiffTime(new Date());
        fileDiff.setStatus(1);

        int rst = fileDiffDao.insertFileDiff(fileDiff);

        return rst;
    }

    @Override
    public int deleteFileDiffByIdService(int id) {
        return fileDiffDao.deleteFileDiffById(id);
    }

    private static String htmlLineSeparator(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String s : list) {
            sb.append(s).append("<br/>");
        }
        return sb.toString();
    }

    public static List<String> compareFileDifference(List<String> source, List<String> target) {
        //保存文件名，文件内容
        Map<String, String> sourceContent = parseFileContent(source);
        Map<String, String> targetContent = parseFileContent(target);

        List<String> diff = compareContent(sourceContent, targetContent);


        return diff;
    }

    public static List<String> compareContent(Map<String, String> sourceContent, Map<String, String> targetContent) {
        List<String> diff = Lists.newArrayList();
        String targetValue = null;
        String sourceValue = null;
        StringBuilder diffrence = null;

        Iterator iterator = sourceContent.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            String key = (String) entry.getKey();
            sourceValue = (String) entry.getValue();
            targetValue = targetContent.get(key);

            diffrence = new StringBuilder();
            if (Strings.isNullOrEmpty(targetValue)) {
                //目标中不存在，源中存在
                diffrence.append("源存在，目标不存在=> -")
                        .append(key).append("=").append(sourceValue);

                diff.add(diffrence.toString());
                iterator.remove();
                continue;
            }

            //源和目标不相同相同
            if (!sourceValue.equals(targetValue)) {
                diffrence.append("源和目标存在,但不同 => -")
                        .append(key).append("=").append(sourceValue)
                        .append("; +")
                        .append(key).append("=").append(targetValue);

                diff.add(diffrence.toString());
            }
            targetContent.remove(key);
            iterator.remove();
        }


        iterator = targetContent.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            String key = (String) entry.getKey();
            String value = (String) entry.getValue();
            diffrence = new StringBuilder();
            diffrence.append("源不存在，目标存在=> +").append(key).append("=");
            diffrence.append(value);

            diff.add(diffrence.toString());
            iterator.remove();
        }

        log.info("sourceContent size:{} == 0", sourceContent.size());
        log.info("targetContent size:{} == 0", targetContent.size());

        return diff;
    }


    public static Map<String, String>  parseFileContent(List<String> source) {
        final Map<String, String> content = new HashMap<String,String>();
        for (String line : source) {
            String stringLine = line.trim();
            if (Strings.isNullOrEmpty(stringLine)) {
                continue;
            }
            String key = stringLine.substring(0, stringLine.indexOf('='));
            String value = stringLine.substring(stringLine.indexOf('=')+1);
            content.put(key, value);
        }
        return content;
    }

}
