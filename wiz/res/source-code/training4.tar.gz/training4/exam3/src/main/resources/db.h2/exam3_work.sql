DROP TABLE IF EXISTS file_diff;
CREATE TABLE file_diff (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
  source_name VARCHAR(30) NOT NULL DEFAULT '' COMMENT '源文件名',
  target_name VARCHAR(30) NOT NULL DEFAULT '' COMMENT '目标文件名',
  source_content VARCHAR(256) NOT NULL DEFAULT '' COMMENT '源文件内容',
  target_content VARCHAR(256) NOT NULL DEFAULT '' COMMENT '目标文件内容',
  diff VARCHAR(256) NOT NULL DEFAULT '' COMMENT '源文件与目标文件差异',
  diff_time TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '对比时间',
  status INT NOT NULL DEFAULT 1 COMMENT '是否删除:0-已删除,1-未删除',
  PRIMARY KEY (id)
);

ALTER TABLE file_diff
  ADD UNIQUE INDEX uniq_source_target(source_name, target_name);

INSERT INTO FILE_DIFF(source_name,target_name,source_content,target_content,diff,diff_time,status) VALUES
('qwe','ewq','ww=2<br/>w=3','ee=1<br/>w=4'
,'源存在，目标不存在=> -a2=y<br/>1源和目标存在,但不同 => -a3=z; +a3=x<br/>源不存在，目标存在=> +a4=n','2016-08-18 22:24:20',1),
('123','321','q=2<br/>w=3','a=1<br/>w=4'
,'源存在，目标不存在=> -a2=y<br/>2源和目标存在,但不同 => -a3=z; +a3=x<br/>源不存在，目标存在=> +a4=n','1999-08-18 22:24:20',1),
('dsa','asd','ee=2<br/>w=3','ee=1<br/>w=4'
,'源存在，目标不存在=> -a2=y<br/>3源和目标存在,但不同 => -a3=z; +a3=x<br/>源不存在，目标存在=> +a4=n','1889-08-18 22:24:20',1),
('zxc','cxz','ee=2<br/>w=3','ww=1<br/>w=4'
,'源存在，目标不存在=> -a2=y<br/>4源和目标存在,但不同 => -a3=z; +a3=x<br/>源不存在，目标存在=> +a4=n','1888-08-18 22:24:20',1),
('rty','ytr','aa=2<br/>w=3','aa=1<br/>w=4'
,'源存在，目标不存在=> -a2=y<br/>5源和目标存在,但不同 => -a3=z; +a3=x<br/>源不存在，目标存在=> +a4=n','1888-08-17 22:24:20',1),
('hfg','fgh','qwe=2<br/>w=3','qwe=1<br/>w=4'
,'源存在，目标不存在=> -a2=y<br/>6源和目标存在,但不同 => -a3=z; +a3=x<br/>源不存在，目标存在=> +a4=n','1888-08-16 22:24:20',1);