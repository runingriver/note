package com.qunar.fresh.dao;


import com.qunar.fresh.model.FileDiff;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface FileDiffDao {

    /**
     * 查询所有数据
     */
    List<FileDiff> selectAllFileDiff();

    /**
     *  查询所有未删除的记录数量
     */
    int selectTotalFileDiffCount();

    /**
     *  分页查询
     */
    List<FileDiff> selectFileDiffByPage(RowBounds rowBound);

    /**
     * 插入一条数据
     */
    int insertFileDiff(FileDiff fileDiff);

    /**
     * 通过id删除
     */
    int deleteFileDiffById(@Param("id") int id);

}
