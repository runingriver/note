package com.qunar.fresh.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {
    public static final Logger log = LoggerFactory.getLogger(MainController.class);
    //处理所有未知的和静态资源的请求
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public String index() {
        return "redirect:/file/list";
    }

    @RequestMapping(value = "/*")
    public void wrongUri() throws Exception {
        throw new IllegalAccessException("请求页面未找到.");
    }
}