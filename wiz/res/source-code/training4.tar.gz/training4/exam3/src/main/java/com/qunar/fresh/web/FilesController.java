package com.qunar.fresh.web;

import com.google.common.base.Charsets;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.google.common.io.Files;
import com.qunar.fresh.model.FileDiff;
import com.qunar.fresh.service.FileDiffService;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.IllegalFormatException;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/file")
public class FilesController {
    public static final Logger log = LoggerFactory.getLogger(FilesController.class);

    @Resource
    FileDiffService fileDiffService;


    @RequestMapping(value = "/list")
    public ModelAndView filesList(HttpSession session) {
        int total = fileDiffService.queryTotalFileDiffCountService();
        log.info("=====总记录条数：{}", total);
        List<FileDiff> diffList = fileDiffService.queryFileDiffByPageService(0, 2);
        ModelAndView mv = new ModelAndView("/files/list");
        mv.addObject("diffList", diffList);
        int num = total % 2;
        mv.addObject("total", total / 2 + num);
        mv.addObject("current", 1);

        String userName = (String) session.getAttribute("userName");
        if (!Strings.isNullOrEmpty(userName)) {
            mv.addObject("userName", userName);
        }
        return mv;
    }

    @RequestMapping(value = "/page/{page}")
    public ModelAndView page(@PathVariable("page") int page, HttpSession session) {

        int total = fileDiffService.queryTotalFileDiffCountService();
        ModelAndView mv = new ModelAndView("/files/list");
        int num = total % 2 + total / 2;
        mv.addObject("total", num);
        mv.addObject("current", page);

        page = (page-1)*2;

        List<FileDiff> diffList = fileDiffService.queryFileDiffByPageService(page, 2);
        mv.addObject("diffList", diffList);

        String userName = (String) session.getAttribute("userName");
        if (!Strings.isNullOrEmpty(userName)) {
            mv.addObject("userName", userName);
        }
        return mv;
    }


    @RequestMapping(value = "/delete/id/{id}")
    public String delete(@PathVariable("id") int id,HttpSession session) throws IllegalAccessException {
        Assert.isTrue(id > 0, "传入id错误");
        if (session.getAttribute("userName") == null) {
            throw new IllegalAccessException("请登录.");
        }
        int rst = fileDiffService.deleteFileDiffByIdService(id);
        return rst == 1 ? "/files/success" : "/errors/error";
    }


    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public String uploadFile(@RequestParam("source") MultipartFile[] source, @RequestParam("target") MultipartFile[] target
            , HttpServletRequest request, HttpServletResponse response) throws Exception {
        String realPath = request.getSession().getServletContext().getRealPath("/res/upload");
        log.info("=====上传路径：{}", realPath);

        //保存文件名，文件内容
        Map<String, Object> sourceInfo = ScaneAndProcessFile(source, realPath);
        List<String> sourceContent = (List<String>) sourceInfo.get("content");
        String sourceFilename = (String) sourceInfo.get("fileName");

        Map<String, Object> targetInfo = ScaneAndProcessFile(target, realPath);
        List<String> targetContent = (List<String>) targetInfo.get("content");
        String targetFilename = (String) targetInfo.get("fileName");

        //对比差异，保存时间,写入数据库
        int rst = fileDiffService.insertFileDiffService(sourceContent, sourceFilename, targetContent, targetFilename);

        return rst == 1 ? "/files/success" : "/errors/error";
    }

    /**
     * 获取文件，将文件内容保存到BiMap中
     * 只对比两个文件
     */
    private Map<String, Object> ScaneAndProcessFile(MultipartFile[] files, String path) throws Exception {
        if (files.length != 1) {
            throw new UnsupportedOperationException("上传文件数量错误.");
        }
        Map<String, Object> result = Maps.newHashMap();
        long time = new Date().getTime();
        List<String> content = null;
        StringBuilder sb = new StringBuilder();
        for (MultipartFile file : files) {
            if (file.isEmpty()) {
                log.info("source failed.");
                throw new IllegalArgumentException("文件不存在");
            }
            String filename = sb.append(file.getOriginalFilename()).append("-")
                    .append(file.getName()).append("-").append(time).toString();
            result.put("fileName", filename);
            //将文件保存到本地
            File savedFile = new File(path, filename);
            try {
                //FileUtils.copyInputStreamToFile()会自动把用到的IO流关掉
                //也可用Spring提供的MultipartFile.transferTo(File dest)实现文件上传
                FileUtils.copyInputStreamToFile(file.getInputStream(), savedFile);
            } catch (IOException e) {
                log.error("文件上传失败", e);
                throw new IOException("文件上传失败");
            }

            //读取文件所有内容
            content = Files.readLines(savedFile, Charsets.UTF_8);
            //只有一个文件
            break;
        }
        if (content == null) {
            throw new IOException("读取文件失败");
        }
        result.put("content", content);
        return result;
    }

}
