package com.qunar.fresh.service.impl;

import com.google.common.base.Strings;
import com.qunar.fresh.model.User;
import com.qunar.fresh.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

@Service
public class UserServiceImpl implements UserService {
    public static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Resource
    Properties account;

    @Override
    public String verifyUser(User user) {
        return verifyUser(user.getUserName(), user.getPassword());
    }

    @Override
    public String verifyUser(String userName, String password) {
        log.info("=====用户名：{}；密码：{}",userName,password);

        if (Strings.isNullOrEmpty(account.getProperty(userName))) {
            return "用户名不存在,请重新输入!";
        }
        if (!account.getProperty(userName).equals(password)) {
            return "密码不正确，请重新输入!";
        }

        return "success";
    }
}
