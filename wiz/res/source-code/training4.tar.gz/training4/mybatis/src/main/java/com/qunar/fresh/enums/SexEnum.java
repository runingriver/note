package com.qunar.fresh.enums;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * 性别枚举
 * 一般int类型表示类型不直观
 * 而mybatis中没有枚举处理方法。
 */
public enum SexEnum {
    Man(1,"男"),Woman(2,"女"), Unknow(0, "未知");

    private int id;
    private String name;
    public static final Map<Integer, SexEnum> map = Maps.newHashMap();

    static {
        for (SexEnum sexEnum : values()) {
            map.put(sexEnum.getId(), sexEnum);
        }
    }

    SexEnum(int id, String name) {
        this.name = name;
        this.id = id;
    }

    public int code() {
        return this.getId();
    }

    public static SexEnum codeOf(int id) {
        return map.get(id);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
