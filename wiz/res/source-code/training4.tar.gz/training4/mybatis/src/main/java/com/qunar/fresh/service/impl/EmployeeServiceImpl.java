package com.qunar.fresh.service.impl;

import com.google.common.collect.Maps;
import com.qunar.fresh.dao.EmployeeDao;
import com.qunar.fresh.enums.SexEnum;
import com.qunar.fresh.model.Employee;
import com.qunar.fresh.service.EmployeeService;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Resource
    private EmployeeDao employeeDao;

    public int saveNewEmployeeService(Employee employee) {
        if (employee == null) {
            throw new IllegalArgumentException("参数非法.");
        }
        int result = employeeDao.saveNewEmployee(employee);
        return result;
    }

    public int batchSaveNewEmployeeService(List<Employee> employeeList) {
        if (org.springframework.util.CollectionUtils.isEmpty(employeeList)) {
            throw new IllegalArgumentException("参数非法.");
        }
        int result = employeeDao.batchSaveNewEmployee(employeeList);
        return result;
    }

    public Employee queryEmployeeInfoByIdService(int id) {
        if (id < 1) {
            throw new IllegalArgumentException("参数非法.");
        }
        Employee employee = employeeDao.queryEmployeeInfoById(id);
        return employee;
    }

    public List<Employee> queryEmployeeByConditionsService(String account, String workAddress, List<SexEnum> sexEnumList) {
        //三者不能全为空
        if (!StringUtils.isNoneBlank(account, workAddress)
                && (sexEnumList == null || sexEnumList.size()<1)) {
            throw new IllegalArgumentException("参数非法.");
        }
        Map<String, Object> params = Maps.newHashMap();
        params.put("account", account);
        params.put("workAddress", workAddress);
        params.put("sexList", sexEnumList);
        return employeeDao.queryEmployeeByConditions(params);
    }

    public int updatePhoneByAccountService(String account,String phone) {
        if (!StringUtils.isNoneBlank(account, phone)) {
            throw new IllegalArgumentException("参数非法.");
        }
        return employeeDao.updatePhoneByAccount(account, phone);
    }

    public int deleteLeavedEmployeeService() {
        return employeeDao.deleteLeavedEmployee();
    }

    public List<Employee> queryEmployeesByAddressForPageService(String workAddress, int start, int size) {
        if (StringUtils.isBlank(workAddress) || start < 0 || size < 0) {
            throw new IllegalArgumentException("参数非法.");
        }
        return employeeDao.queryEmployeesByAddressForPage(workAddress, new RowBounds(start, size));
    }
}
