package com.qunar.fresh.service;

import com.qunar.fresh.enums.SexEnum;
import com.qunar.fresh.model.Employee;

import java.util.List;

public interface EmployeeService {

    /**
     * 保存新入职的员工信息
     * @param employee
     * @return
     */
    int saveNewEmployeeService(Employee employee);

    /**
     * 批量插入新入职员工信息
     * @param employeeList 员工列表
     * @return 成功插入数量
     */
    int batchSaveNewEmployeeService(List<Employee> employeeList);

    /**
     * 通过Id搜索员工信息
     * @param id 主键id
     * @return 员工信息
     */
    Employee queryEmployeeInfoByIdService(int id);

    /**
     * 组合查询符合条件的员工信息
     * @param account 员工账号
     * @param workAddress 工作地址
     * @param sexEnumList 性别
     * @return list
     * 三者不能全为空
     */
    List<Employee> queryEmployeeByConditionsService(String account, String workAddress, List<SexEnum> sexEnumList);

    /**
     * 根据员工工号更新电话
     * @param account 工号
     * @param phone 电话
     * @return 影响的行数
     */
    int updatePhoneByAccountService(String account,String phone);

    /**
     * 删除所有已经离职员工
     * @return int
     * 逻辑删除
     */
    int deleteLeavedEmployeeService();

    /**
     * 分页查询
     * @param workAddress 工作地点
     * @param start 开始页
     * @param size 页大小
     * @return list
     */
    List<Employee> queryEmployeesByAddressForPageService(String workAddress,int start, int size);
}
