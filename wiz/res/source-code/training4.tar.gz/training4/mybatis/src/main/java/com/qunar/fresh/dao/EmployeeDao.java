package com.qunar.fresh.dao;


import com.qunar.fresh.model.Employee;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;
import java.util.Map;


public interface EmployeeDao {

    /**
     * 保存新入职的员工信息
     * @param employee 新入职员工信息
     * @return  插入是否成功，1-成功，0-失败
     */
    int saveNewEmployee(Employee employee);

    /**
     * 批量保存新入职员工信息
     * @param employeeList 新员工集合
     * @return  保存成功个数
     */
    int batchSaveNewEmployee(List<Employee> employeeList);

    /**
     * 通过员工编号(主键id)查询员工信息
     * @param id 主键id
     * @return 结果信息
     */
    Employee queryEmployeeInfoById(int id);

    /**
     * 组合条件查询
     * @param params 组合条件map
     * @return 结果信息集合
     */
    List<Employee> queryEmployeeByConditions(Map<String, Object> params);

    /**
     * 根据员工工号更新员工的电话
     * @param account 工号
     * @return 更新影响的数量
     *
     */
    int updatePhoneByAccount(@Param("account") String account, @Param("phone") String phone);

    /**
     * 删除已经离职的员工
     * @return 删除的员工数量
     */
    int deleteLeavedEmployee();

    /**
     * 通过工作地址，分页查询员工信息
     * @param workAddress 工作地点
     * @param rowBound 绑定的参数对象
     * @return 指定员工集合
     */
    List<Employee> queryEmployeesByAddressForPage(@Param("workAddress") String workAddress, RowBounds rowBound);
}
