/*
建表：员工信息表（id、员工工号、qtalkId(拼音)、中文姓名、电话号码、工作地点、性别、是否在职）
实现方法
1、保存新入职的员工信息
2、批量保存新入职的员工信息
3、通过[员工编号id] 查询员工信息
4、根据组合查询条件：工作地点、性别、员工工号、查询员工信息（动态sql的使用)
5、更新指定[员工工号]的[电话号码]
6、删除已经离职的员工
7、通过工作地点列表，分页查询员工信息
*/

#建立数据库
DROP DATABASE IF EXISTS mybatis_work;
CREATE DATABASE mybatis_work;
ALTER DATABASE mybatis_work
DEFAULT CHARACTER SET utf8mb4;
SHOW DATABASES;

#建立用户表
USE mybatis_work;
DROP TABLE IF EXISTS employee;
CREATE TABLE employee (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT '主键,员工编号',
  account      VARCHAR(20)  NOT NULL DEFAULT ''
  COMMENT '员工账号',
  qtalk_id     VARCHAR(20)  NOT NULL DEFAULT ''
  COMMENT 'qtalk的id，拼音',
  chinese_name         VARCHAR(30)  NOT NULL DEFAULT ''
  COMMENT '中文姓名',
  phone        VARCHAR(14)  NOT NULL DEFAULT ''
  COMMENT '电话',
  work_address VARCHAR(50)  NOT NULL DEFAULT ''
  COMMENT '工作地点',
  sex          TINYINT      NOT NULL DEFAULT 0
  COMMENT '性别:1-男，2-女，0-未知',
  in_service    TINYINT      NOT NULL DEFAULT 0
  COMMENT '是否在职：1-在职，0-离职',
  status       TINYINT      NOT NULL DEFAULT 1
  COMMENT '是否删除:0-已删除,1-未删除',
  PRIMARY KEY (id)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT '用户表';

#索引
ALTER TABLE mybatis_work.employee
  ADD UNIQUE INDEX uniq_account_phone(account, phone);

#插入测试数据
INSERT INTO mybatis_work.employee
(account, qtalk_id, chinese_name, phone, work_address, sex, in_service, status) VALUES
  ('111001', 'hello1.world1', '哈喽1', '12345678901', '1231', 1, 1, 1),
  ('111002', 'hello2.world2', '哈喽2', '13578786767', 'qwe2', 2, 1, 1),
  ('111003', 'hello3.world3', '哈喽3', '13567679789', 'qwe', 1, 0, 1),
  ('111004', 'hello4.world4', '哈喽4', '13543432323', 'qwe', 2, 0, 1),
  ('111005', 'hello5.world5', '哈喽5', '13512123434', 'qwe', 1, 1, 1);
