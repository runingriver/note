package com.qunar.fresh.service.impl;

import com.google.common.collect.Lists;
import com.qunar.fresh.dao.EmployeeDao;
import com.qunar.fresh.enums.SexEnum;
import com.qunar.fresh.model.Employee;
import com.qunar.fresh.service.EmployeeService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import java.util.List;
import java.util.Random;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring-mybatis.xml")
public class EmployeeServiceImplTest {

    public static final Logger log = LoggerFactory.getLogger(EmployeeServiceImplTest.class);

    @Resource
    EmployeeService employeeService;

    @Test
    public void saveNewEmployeeService() throws Exception {

        Employee employee = new Employee();
        employee.setAccount(getRandomString(6));
        employee.setQtalkId(getRandomString(10));
        employee.setChineseName("你好9");
        employee.setPhone("1231212787" + new Random().nextInt(9));
        employee.setWorkAddress("123");
        employee.setSexEnum(SexEnum.Man);
        employee.setInService(1);
        employee.setStatus(1);

        int rst = employeeService.saveNewEmployeeService(employee);

        Assert.assertEquals(1,rst);
    }

    //length表示生成字符串的长度
    public static String getRandomString(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    @Test
    public void batchSaveNewEmployeeService() throws Exception {
        int number = new Random().nextInt(50);
        List<Employee> employeeList = EmployeeServiceImplTest.getEmployeeList(10+number,15+number);
        int rst = employeeService.batchSaveNewEmployeeService(employeeList);
        Assert.assertEquals(5, rst);
    }

    private static List<Employee> getEmployeeList(int start,int end) {
        List<Employee> list = Lists.newArrayList();
        Employee employee = null;
        for (int i=start;i<end;i++) {
            employee = new Employee();
            employee.setAccount("11100" + i);
            employee.setQtalkId("hello.world" + i);
            employee.setChineseName("你好" + i);
            employee.setPhone("1231212" + i+new Random().nextInt(29));
            employee.setWorkAddress("zhongguancun");
            employee.setSexEnum(SexEnum.Man);
            employee.setInService(1);
            employee.setStatus(1);

            list.add(employee);
        }
        return list;
    }

    @Test
    public void queryEmployeeInfoByIdService() throws Exception {
        Employee employee = employeeService.queryEmployeeInfoByIdService(2);
        log.info(employee.toString());

        Assert.assertEquals(employee.getAccount(),"111002");
    }

    @Test
    public void queryEmployeeByConditionsService() throws Exception {
        List<Employee> employeeList = employeeService.queryEmployeeByConditionsService("", ""
                , Lists.newArrayList(SexEnum.Man, SexEnum.Woman));

        log.info("=====result size:{}======",employeeList.size());
        for (Employee e : employeeList) {
            log.info(e.toString());
        }
    }

    @Test
    public void updatePhoneByAccountService() throws Exception {
        int rst = employeeService.updatePhoneByAccountService("111001", "00000000000");
        Assert.assertEquals(1,rst);
    }

    @Test
    public void deleteLeavedEmployeeService() throws Exception {
        int rst = employeeService.deleteLeavedEmployeeService();
        Assert.assertEquals(2,rst);
    }

    @Test
    public void queryEmployeesByAddressForPageService() throws Exception {
        List<Employee> employeeList = employeeService.queryEmployeesByAddressForPageService("qwe", 1, 3);
        log.info("=====result size:{}======",employeeList.size());
        for (Employee e : employeeList) {
            log.info(e.toString());
        }
    }

}