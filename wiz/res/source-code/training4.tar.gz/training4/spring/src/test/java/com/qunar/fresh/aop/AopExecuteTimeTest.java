package com.qunar.fresh.aop;

import com.qunar.fresh.dao.UserDao;
import com.qunar.fresh.model.User;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/spring/aop.xml","classpath:db.h2/dataSource-h2.xml"})
public class AopExecuteTimeTest {
    public static final Logger log = LoggerFactory.getLogger(AopExecuteTimeTest.class);

    @Resource
    UserDao userDao;

    @Test
    public void AopExcuteTimeDaoMethodTest() throws Exception {
        log.debug("-----------------------------------------------");
        User user = userDao.queryById("111002");
        log.debug(user.toString());
        Assert.assertEquals("111002", userDao.queryById("111002").getUserId());
        log.debug("-----------------------------------------------");
    }
}