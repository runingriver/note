package com.qunar.fresh.common;

import com.qunar.fresh.web.convertor.DateConvertor;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.Date;

public class DateConvertorTest {
    public static final Logger log = LoggerFactory.getLogger(DateConvertorTest.class);

    @Test
    public void convert() throws Exception {
        DateConvertor convertor = new DateConvertor();

        Date date1 = convertor.convert("2016-09-12");
        log.debug(date1.toString());
        Date date2 = convertor.convert("2016/09/12");
        log.debug(date2.toString());

        Date date3 = convertor.convert("2016年09月12日");
        log.debug(date3.toString());

        Date date4 = convertor.convert("2016 09 12");
        log.debug(date4.toString());

        Assert.assertEquals("Mon Sep 12 00:00:00 CST 2016",date1.toString());
        Assert.assertEquals("Mon Sep 12 00:00:00 CST 2016",date2.toString());
        Assert.assertEquals("Mon Sep 12 00:00:00 CST 2016",date3.toString());
        Assert.assertEquals("Mon Sep 12 00:00:00 CST 2016",date4.toString());
    }

}