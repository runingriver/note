package com.qunar.fresh.web;

import com.google.common.collect.Lists;
import com.qunar.fresh.dao.UserDao;
import com.qunar.fresh.dao.impl.UserDaoImpl;
import com.qunar.fresh.model.User;
import com.qunar.fresh.service.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.result.ModelResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.annotation.Resource;
import java.util.List;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = {"classpath:spring/mvc-dispatcher.xml"})
public class UserControllerTest {
    public static final Logger log = LoggerFactory.getLogger(UserControllerTest.class);

    @Resource
    private UserController userController;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {
        this.mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }


    @Test
    public void detail() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/user/detail/userid/111001").accept(MediaType.ALL))
                .andDo(print()).andExpect(MockMvcResultMatchers.model().attributeExists("user"))
                .andExpect(status().isOk());
    }

    @Test
    public void delete() throws Exception {
        UserDao userDao = Mockito.mock(UserDaoImpl.class);
        Mockito.when(userDao.deleteUserByUserId("111001")).thenReturn(1);

        mockMvc.perform(MockMvcRequestBuilders.get("/user/detail/userid/111001").accept(MediaType.ALL))
                .andDo(print())
                .andExpect(status().isOk());

    }

}