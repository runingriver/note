package com.qunar.fresh.dao.impl;

import com.qunar.fresh.dao.UserDao;
import com.qunar.fresh.model.User;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:db.h2/dataSource-h2.xml")
public class UserDaoImplTest {
    public static final Logger log = LoggerFactory.getLogger(UserDaoImplTest.class);

    @Resource
    UserDao userDao;

    @Test
    public void queryById() throws Exception {
        User user = userDao.queryById("111002");
        log.debug(user.toString());
        Assert.assertEquals("111002", userDao.queryById("111002").getUserId());
    }

    @Test
    public void queryAllUser() throws Exception {
        List<User> list = userDao.queryAllUser();
        for (User user : list) {
            log.info("user = {}", user);
        }
    }

    @Test
    public void addUser() throws Exception {
        log.debug("------------------------------------------");
        User user = User.newBuilder()
                .userId("111011").userName("testname")
                .password("123").builder();
        Assert.assertEquals(1,userDao.addUser(user));
        log.debug("------------------------------------------");
    }

    @Test
    public void updateUserByUserId() throws Exception {
        User user = User.newBuilder()
                .userId("111001").userName("testname")
                .password("123").builder();

        Assert.assertEquals( 1,userDao.updateUserByUserId(user,"111001"));
    }

    @Test
    public void deleteUserByUserId() throws Exception {
        Assert.assertEquals( 1,userDao.deleteUserByUserId("111001"));
    }

    @Test
    public void queryByUserName() throws Exception {
        User user = userDao.queryByUserName("hzz1");
        log.debug(user.toString());
        Assert.assertEquals("hzz1", userDao.queryByUserName("hzz1").getUserName());
    }

    @Test
    public void deleteUserByUserName() throws Exception {
        Assert.assertEquals(1,userDao.deleteUserByUserName("hzz1"));
    }

    @Test
    public void queryCount() throws Exception {
        Assert.assertEquals(1,userDao.queryCount("111001"));
    }

}