package com.qunar.fresh.service.impl;

import com.qunar.fresh.dao.UserDao;
import com.qunar.fresh.dao.impl.UserDaoImpl;
import com.qunar.fresh.model.User;
import com.qunar.fresh.service.UserService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import static org.mockito.Mockito.mock;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:db.h2/dataSource-h2.xml")
public class UserServiceImplTest {

    public static final Logger log = LoggerFactory.getLogger(UserServiceImplTest.class);

    @Resource
    UserService userService;

    @Test
    public void addIncompleteUser() throws Exception {
        User user = User.newBuilder().userId("123")
                .userName("qwe")
                .password("123").builder();

        //mock掉addIncompleteUser中调用的Dao方法
        UserDao userDao = mock(UserDaoImpl.class);
        Mockito.when(userDao.addUser(user)).thenReturn(1);

        String result = userService.addIncompleteUser(user);

        Assert.assertEquals("success", result);
    }

    @Test
    public void updatePartlyData() throws Exception {
        User user = User.newBuilder().userId("123")
                .userName("qwe")
                .password("123").builder();

        UserDao userDao = mock(UserDaoImpl.class);

        Mockito.when(userDao.updatePartlyUserColumn(user)).thenReturn(1);

        String result = userService.updatePartlyData(user);

        Assert.assertEquals("success",result);
    }
}