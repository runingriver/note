package com.qunar.fresh.dao;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

public class DataSourceH2ByXmlTest {
    private static final Logger LOG = LoggerFactory
            .getLogger(DataSourceH2ByXmlTest.class);

    @Test
    public void testDataSource(){
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("db.h2/dataSource-h2.xml");
        DataSource dataSource = applicationContext.getBean("h2DataSource", DataSource.class);

        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        List<Map<String, Object>> list = jdbcTemplate.queryForList("select USER_ID,USER_NAME from USER_MANAGERMENT");
        for (Map<String, Object> user : list) {
            LOG.info("user = {}",user);
        }
    }
}
