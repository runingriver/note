package com.qunar.fresh.service.impl;


import com.qunar.fresh.dao.UserDao;
import com.qunar.fresh.model.User;
import com.qunar.fresh.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    UserDao userDao;

    @Override
    public String updatePartlyData(User user) {

        if (user.getAge() == null) {
            user.setAge(0);
        }
        if (user.getSex() == null) {
            user.setSex(1);
        }
        if (!StringUtils.isNotBlank(user.getRemark())) {
            user.setRemark("nothing remark.");
        }

        /*更新，最近修改时间，和web数据*/
        /*如果先查询，再修改不同，再写入，浪费I/O*/
        int rst = userDao.updatePartlyUserColumn(user);

        return rst == 1 ? "success" : "修改用户失败.";
    }

    @Override
    public String addIncompleteUser(User user) {

        if (userDao.queryCount(user.getUserId()) > 0) {
            return "账号名重复，请重写添加.";
        }

        /*Builder中设定了默认值,用户没有指定的值按默认填入*/
        /*用户第一次添加需要指定创建时间*/
        User addedUser = User.newBuilder().userId(user.getUserId())
                .userName(user.getUserName())
                .password(user.getPassword())
                .sex(user.getSex() != null ? user.getSex() : 1)
                .age(user.getAge() != null ? user.getAge() : 0)
                .remark(StringUtils.isNotBlank(user.getRemark()) ? user.getRemark() : "nothing remark.")
                .status(1)
                .createTime(new Date())
                .builder();

        System.out.println(user.getAge());

        int rst = userDao.addUser(addedUser);

        return rst == 1 ? "success" : "添加用户失败.";
    }

}
