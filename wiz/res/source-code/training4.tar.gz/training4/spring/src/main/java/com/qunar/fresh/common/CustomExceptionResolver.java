package com.qunar.fresh.common;

import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 自定义全局异常处理
 * 由于改异常的优先级低于SimpleMappingExceptionResolver
 * 而Simple×这个异常捕捉了所有的异常，所以达不到这里。
 * 如果，有特殊要求可以使用自定义异常（这里留作一个demo）
 */
public class CustomExceptionResolver implements HandlerExceptionResolver {

    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        /*ex.printStackTrace();*/
        CustomException customException = null;

        //向前台返回错误信息
        ModelAndView modelAndView = new ModelAndView();

        //如果抛出的是系统自定义的异常则直接转换
        if(ex instanceof CustomException) {
            customException = (CustomException) ex;
            modelAndView.addObject("message", customException.getMessage());
            modelAndView.setViewName("/errors/failed");
        }
        if (ex instanceof IllegalAccessException) {
            modelAndView.addObject("message", ex.getMessage());
            //可以选择其他页面
            modelAndView.setViewName("/errors/failed");
        } else {
            modelAndView.setViewName("/errors/404");
        }

        return modelAndView;
    }
}
