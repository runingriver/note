package com.qunar.fresh.web.convertor;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

import java.util.Date;
import java.util.IllegalFormatConversionException;

/**
 * Spring表单中时间的转换
 */
public class DateConvertor implements Converter<String ,Date> {
    public static final Logger log = LoggerFactory.getLogger(DateConvertor.class);
    @Override
    public Date convert(String source) {
        Preconditions.checkArgument(!Strings.isNullOrEmpty(source),"时间字符串为空");
        Date date = null;
        String format = getDateFormat(source);

        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern(format);
        try {
            date = dateTimeFormatter.parseDateTime(source.trim()).toDate();
        } catch (UnsupportedOperationException e) {
            log.error("不支持的转换格式",e);
            return null;
        } catch (IllegalArgumentException e) {
            log.error("时间转换参数不合法",e);
            throw new IllegalArgumentException("时间转换参数不合法");
        }
        return date;
    }

    private static String getDateFormat(String source) {
        String format = null;
        if (source.contains("-")) {
            format = "yyyy-MM-dd";
        } else if (source.contains("/")) {
            format = "yyyy/MM/dd";
        } else if (source.contains("年")
                && source.contains("月")
                && source.contains("日")) {
            format = "yyyy年MM月dd日";
        } else {
            format = "yyyy MM dd";
        }
        return format;
    }

}
