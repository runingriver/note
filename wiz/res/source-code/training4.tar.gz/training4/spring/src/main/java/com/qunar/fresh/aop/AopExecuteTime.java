package com.qunar.fresh.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * aop实现dao层方法的执行时间
 */
@Aspect
@Component
public class AopExecuteTime {
    public static final Logger log = LoggerFactory.getLogger(AopExecuteTime.class);

    @Pointcut("execution( * com.qunar.fresh.dao.*.*(..))")
    public void aspect(){}

    @Around("aspect()")
    public Object around(JoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();

        //多次使用，抽出来
        String methodName = joinPoint.getSignature().getName();
        try {
            log.debug("方法开始执行：{}",methodName);
            Object proceed = ((ProceedingJoinPoint) joinPoint).proceed();
            log.debug("方法执行完成：{}",methodName);
            long end = System.currentTimeMillis();
            log.info("方法：{} 执行时间是:{}ms!",methodName, (end - start));
            return proceed;
        } catch (Throwable e) {
            log.error("aop异常",e);
            long end = System.currentTimeMillis();
            log.info("方法：{} 执行时间是:{}ms!",methodName,(end - start));
            throw e;
        }
    }
}
