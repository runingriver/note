DROP TABLE IF EXISTS user_managerment;
CREATE TABLE user_managerment(
  id INT NOT NULL AUTO_INCREMENT COMMENT '主键',
  user_id VARCHAR(20) NOT NULL DEFAULT '' COMMENT '用户id',
  user_name VARCHAR(20) NOT NULL DEFAULT '' COMMENT '用户名',
  user_password VARCHAR(30) NOT NULL DEFAULT '' COMMENT '用户密码',
  sex INT NOT NULL DEFAULT 0 COMMENT '性别,1-男，2-女',
  age INT NOT NULL DEFAULT 0 COMMENT '年龄',
  remark VARCHAR(255) NOT NULL DEFAULT '' COMMENT '备注',
  status INT NOT NULL DEFAULT 1 COMMENT '用户状态：1.活跃，2.已删除',
  create_time TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '更新时间',
  latest_edit_time TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最后编辑时间',
  PRIMARY KEY (id)
);

INSERT INTO user_managerment(user_id, user_name,user_password
  , sex, age, remark,status, create_time, latest_edit_time) VALUES
('111001','hzz1',123,1,12,'hello world',1,'2016-08-03 10:12:12','2016-08-03 10:12:12'),
('111002','hzz2',123,1,12,'hello world',1,'2016-08-03 10:12:12','2016-08-03 10:12:12'),
('111003','hzz3',123,2,12,'hello world',2,'2016-08-03 10:12:12','2016-08-03 10:12:12'),
('111004','hzz4',123,2,12,'hello world',2,'2016-08-03 10:12:12','2016-08-03 10:12:12'),
('111005','hzz5',123,2,12,'hello world',2,'2016-08-03 10:12:12','2016-08-03 10:12:12'),
('111006','hzz6',123,2,12,'hello world',1,'2016-08-03 10:12:12','2016-08-03 10:12:12');
