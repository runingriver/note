package com.qunar.fresh.dao;

import com.qunar.fresh.model.User;

import java.util.List;
import java.util.Map;

public interface UserDao {
    /**
     *  通过用户id查找指定用户
     */
    User queryById(String userId);

    /**
     * 查询符合结果的数量
     */
    int queryCount(String userId);
    /**
     *  根据用户名查找指定用户
     */
    User queryByUserName(String userName);

    /**
     *  查找所有用户
     */
    List<User> queryAllUser();

    /**
     *  添加一个用户
     */
    int addUser(User user);

    /**
     *  更新用户
     */
    int updateUserByUserId(User user,String userId);

    int updateUser(User user);

    int updatePartlyUserColumn(User user);

    /**
     *  根据UserId删除用户
     */
    int deleteUserByUserId(String userId);

    int deleteUserByUserName(String userName);

}
