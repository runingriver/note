package com.qunar.fresh.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {
    public static final Logger log = LoggerFactory.getLogger(MainController.class);
    //处理所有未知的和静态资源的请求
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public String index() {
        return "redirect:/user/list";
    }

    @RequestMapping(value = "/*")
    public void wrongUri() throws Exception {
        throw new IllegalAccessException("请求页面未找到.");
    }

    //binding_date.do?date={date}接口实现
    @RequestMapping(value = "/binding_date.do")
    public @ResponseBody String convertDate(String date) throws Exception {
        Assert.isTrue(date != null,"传入时间参数为空.");
        log.debug(date.toString());

        return date.toString();
    }

}
