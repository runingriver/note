package com.qunar.fresh.model;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.qunar.fresh.web.validation.ValidGroup1;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 用户管理
 */
public class User implements Serializable {
    private static final long serialVersionUID = -1112634185059219823L;

    @Size(min = 3,max = 20,message = "用户账号长度不合法",groups = {ValidGroup1.class})
    private String userId;      //用户id

    @Size(min = 2,max = 20,message = "用户名长度不合法",groups = {ValidGroup1.class})
    private String userName;    //用户名

    @Size(min = 3,max = 30,message = "密码长度不合法",groups = {ValidGroup1.class})
    private String password;    //密码

    @Max(value = 2,groups = {ValidGroup1.class})
    @Min(value = 0,groups = {ValidGroup1.class})
    private Integer sex;        //性别

    @Max(value = 120,message = "年龄太大",groups = {ValidGroup1.class})
    @Min(value = 0,message = "年龄不能为负数",groups = {ValidGroup1.class})
    private Integer age;        //年龄

    private String remark;      //备注
    private Integer status;     //状态
    private Date createTime;    //创建时间
    private Date latestEditTime;//最后编辑时间

    private User() {}

    public User(Builder builder) {
        this.userId = builder.userId;
        this.userName = builder.userName;
        this.password = builder.password;
        this.sex = builder.sex;
        this.age = builder.age;
        this.remark = builder.remark;
        this.status = builder.status;
        this.createTime = builder.createTime;
        this.latestEditTime = builder.latestEditTime;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }



    public Date getLatestEditTime() {
        return latestEditTime;
    }

    public void setLatestEditTime(Date latestEditTime) {
        this.latestEditTime = latestEditTime;
    }



    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }



    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId.trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName.trim();
    }

    @Override
    public String toString() {
        return "User{" +
                "age=" + age +
                ", userId='" + userId + '\'' +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", sex=" + sex +
                ", remark='" + remark + '\'' +
                ", status=" + status +
                ", createTime=" + createTime +
                ", latestEditTime=" + latestEditTime +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;

        User user = (User) o;

        if (userId != user.userId) return false;
        if (password != null ? !password.equals(user.password) : user.password != null) return false;
        if (userName != null ? !userName.equals(user.userName) : user.userName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = userId.hashCode();
        result = 31 * result + (userName != null ? userName.hashCode() : 0);
        result = 31 * result + (password != null ? password.hashCode() : 0);
        return result;
    }

    public static final class Builder {
        private String userId;
        private String userName;
        private String password;

        private Integer sex = 1;
        private Integer age = 0;
        private String remark = "添加点呗~";
        private Integer status = 1;
        private Date createTime = null;
        private Date latestEditTime = new Date();

        public Builder userId(String userId) {
            Preconditions.checkArgument(!Strings.isNullOrEmpty(userId.trim()), "userId cannot be null");
            this.userId = userId.trim();
            return this;
        }

        public Builder userName(String userName) {
            Preconditions.checkArgument(!Strings.isNullOrEmpty(userName.trim()), "username cannot be null");
            this.userName = userName.trim();
            return this;
        }

        public Builder password(String password) {
            Preconditions.checkArgument(!Strings.isNullOrEmpty(password.trim()), "password cannot be null");
            this.password = password.trim();
            return this;
        }

        public Builder sex(Integer  sex) {
            this.sex = sex;
            return this;
        }

        public Builder age(Integer age) {
            this.age = age;
            return this;
        }

        public Builder remark(String remark) {
            this.remark = remark;
            return this;
        }

        public Builder status(Integer status) {
            this.status = status;
            return this;
        }

        public Builder createTime(Date createTime) {
            this.createTime = createTime;
            return this;
        }

        public Builder latestEditTime(Date latestEditTime) {
            this.latestEditTime = latestEditTime;
            return this;
        }

        public User builder() {
            return new User(this);
        }
    }

    public static Builder newBuilder() {
        return new Builder();
    }
}
