package com.qunar.fresh.web;

import com.google.common.base.Strings;
import com.qunar.fresh.common.CustomException;
import com.qunar.fresh.common.CustomExceptionResolver;
import com.qunar.fresh.dao.UserDao;
import com.qunar.fresh.model.User;
import com.qunar.fresh.service.UserService;
import com.qunar.fresh.web.validation.ValidGroup1;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.io.UnsupportedEncodingException;
import java.util.List;

@Controller
@RequestMapping(value = "/user")
public class UserController {
    public static final Logger log = LoggerFactory.getLogger(UserController.class);
    @Resource
    UserDao userDao;

    @Resource
    UserService userService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public String list(ModelMap modelMap) {
        List<User> userList = userDao.queryAllUser();
        modelMap.addAttribute("userList", userList);
        return "/user/list";
    }

    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String requestAdd() {
        return "/user/add";
    }

    @RequestMapping(value = "/add/insert", method = RequestMethod.POST)
    public String add(@ModelAttribute("user") @Validated(value = {ValidGroup1.class}) User user
            , BindingResult bindingResult, Model model) throws Exception {
        //初始参数合法检查
        if (!checkParameterValidation(bindingResult, model)) {
            return "/errors/error";
        }

        String result = userService.addIncompleteUser(user);

        /*获取结果提示用户错误信息！*/
        Assert.isTrue(result.equals("success"), result);

        return "redirect:/user/list";
    }

    @RequestMapping(value = "/detail/userid/{id}")
    public String detail(@PathVariable("id") String userId, ModelMap modelMap) {
        /*检查参数合法性*/
        Assert.hasText(userId, "请求的userid不能为空");

        User user = userDao.queryById(userId);
        Assert.isTrue(user != null,"获取用户失败.");

        modelMap.addAttribute("user", user);
        return "/user/detail";
    }

    @RequestMapping(value = "/modify/userid/{id}", method = RequestMethod.GET)
    public String requestModify(@PathVariable("id") String userId, ModelMap modelMap) {
        /*检查参数合法性*/
        Assert.hasText(userId, "请求的userid不能为空");
        User user = userDao.queryById(userId);
        modelMap.addAttribute("user", user);
        return "/user/modify";
    }

    @RequestMapping(value = "/modify/update", method = RequestMethod.POST)
    public String modify(@ModelAttribute("userUpdate") @Validated(value = {ValidGroup1.class}) User user
            , BindingResult bindingResult, Model model) throws Exception {
        Assert.isTrue(user != null, "修改用户信息失败.");

        if (!checkParameterValidation(bindingResult, model)) {
            return "/errors/error";
        }

        String result = userService.updatePartlyData(user);
         /*提示用户错误信息！*/
        Assert.isTrue(result.equals("success"), result);

        return "redirect:/user/list";
    }


    @RequestMapping(value = "/delete/userid/{id}")
    public String delete(@PathVariable("id") String userId) {
        Assert.isTrue(!Strings.isNullOrEmpty(userId), "请求参数不合法.");

        int result = userDao.deleteUserByUserId(userId);
        Assert.isTrue(result == 1, "删除失败.");

        return "redirect:/user/list";
    }

    @RequestMapping(value = "/**")
    public void noPages() throws Exception {
        throw new IllegalAccessException("请求页面未找到.");
    }


    /**
     * 检查参数异常
     */
    private boolean checkParameterValidation(BindingResult bindingResult, Model model) throws UnsupportedEncodingException {
        if (bindingResult.hasErrors()) {
            List<ObjectError> allErrors = bindingResult.getAllErrors();
            log.debug("error size:{}",allErrors.size());
            String errorMsg = allErrors.get(allErrors.size() - 1).getDefaultMessage().toString();
            model.addAttribute("inputError", errorMsg);
            return false;
        }
        return true;
    }

}
