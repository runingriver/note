package com.qunar.fresh.dao.impl;

import com.google.common.base.Preconditions;
import com.qunar.fresh.dao.UserDao;
import com.qunar.fresh.model.User;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Repository
public class UserDaoImpl implements UserDao {
    public static final Logger log = LoggerFactory.getLogger(UserDaoImpl.class);

    @Resource
    private JdbcTemplate jdbcTemplate;

    public static final String SELECT_USER =
            "SELECT USER_ID,USER_NAME,USER_PASSWORD,SEX,AGE,REMARK,STATUS,CREATE_TIME,LATEST_EDIT_TIME FROM USER_MANAGERMENT ";


    @Override
    public User queryById(String userId) {
        Preconditions.checkArgument(StringUtils.isNotBlank(userId), "userId不能为空.");
        String sql = SELECT_USER + " WHERE USER_ID=?";

        return this.jdbcTemplate.queryForObject(sql
                , new Object[]{userId}
                , new UserMapper());
    }

    @Override
    public int queryCount(String userId) {
        Preconditions.checkArgument(StringUtils.isNotBlank(userId), "userId不能为空.");
        String sql = "SELECT count(*) FROM USER_MANAGERMENT Where USER_ID=?";
        return this.jdbcTemplate.queryForObject(sql, Integer.class, userId);
    }

    private static final class UserMapper implements RowMapper<User> {
        @Override
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            User user = User.newBuilder().userId(rs.getString("USER_ID"))
                    .userName(rs.getString("USER_NAME"))
                    .password(rs.getString("USER_PASSWORD"))
                    .sex(rs.getInt("SEX")).age(rs.getInt("AGE"))
                    .remark(rs.getString("REMARK"))
                    .status(rs.getInt("STATUS"))
                    .createTime(rs.getTimestamp("CREATE_TIME"))
                    .latestEditTime(rs.getTimestamp("LATEST_EDIT_TIME"))
                    .builder();

            return user;
        }
    }

    @Override
    public List<User> queryAllUser() {
        String sql = SELECT_USER + " WHERE STATUS > 0";
        return jdbcTemplate.query(sql, new UserMapper());
    }

    @Override
    public User queryByUserName(String userName) {
        Preconditions.checkArgument(StringUtils.isNotBlank(userName), "userName不能为空.");
        String sql = SELECT_USER + "WHERE USER_NAME=?";

        return this.jdbcTemplate.queryForObject(sql
                , new Object[]{userName}
                , new UserMapper());
    }

    @Override
    public int addUser(User user) {
        Preconditions.checkNotNull(user);
        String sql = "INSERT INTO USER_MANAGERMENT " +
                "(USER_ID,USER_NAME,USER_PASSWORD,SEX,AGE" +
                ",REMARK,STATUS,CREATE_TIME,LATEST_EDIT_TIME) " +
                "VALUES (?,?,?,?,?,?,?,?,?)";


        //创建时间只有在add的时候会更新
        return jdbcTemplate.update(sql, user.getUserId(), user.getUserName()
                , user.getPassword(), user.getSex(), user.getAge()
                , user.getRemark(), user.getStatus(), new Date(), user.getLatestEditTime());

    }

    @Override
    public int updateUser(User user) {
        return updateUserByUserId(user, user.getUserId());
    }

    @Override
    public int updateUserByUserId(User user, String userId) {
        Preconditions.checkNotNull(user);
        Preconditions.checkArgument(user.getUserId().equals(userId), "传入的userId与user不一致.");

        /*更新不用更新：创建时间*/
        String sql = "UPDATE USER_MANAGERMENT SET " +
                "USER_ID=?,USER_NAME=?,SEX=?,AGE=?" +
                ",REMARK=?,STATUS=?,LATEST_EDIT_TIME=? WHERE USER_ID=?";

        return jdbcTemplate.update(sql, user.getUserId(), user.getUserName()
                , user.getSex(), user.getAge(), user.getRemark()
                , user.getStatus(), user.getLatestEditTime(), userId.trim());
    }

    @Override
    public int updatePartlyUserColumn(User user) {
        Preconditions.checkNotNull(user);
        String sql = "UPDATE USER_MANAGERMENT SET " +
                "USER_NAME=?,SEX=?,AGE=?,REMARK=? WHERE USER_ID=?";
        return jdbcTemplate.update(sql, user.getUserName()
                , user.getSex(), user.getAge(), user.getRemark(), user.getUserId());
    }

    @Override
    public int deleteUserByUserId(String userId) {
        Preconditions.checkArgument(StringUtils.isNotBlank(userId), "userId不能为空.");

        /*逻辑删除用户，还要更新删除的时间*/
        String sql = "UPDATE USER_MANAGERMENT SET STATUS=0,LATEST_EDIT_TIME=? WHERE USER_ID=?";
        return this.jdbcTemplate.update(sql, new Timestamp(System.currentTimeMillis()), userId.trim());
    }

    @Override
    public int deleteUserByUserName(String userName) {
        Preconditions.checkArgument(StringUtils.isNotBlank(userName), "userName不能为空.");

        /*逻辑删除用户，还要更新删除的时间*/
        String sql = "UPDATE USER_MANAGERMENT SET STATUS=0,LATEST_EDIT_TIME=? WHERE USER_NAME=?";
        return this.jdbcTemplate.update(sql, new Timestamp(System.currentTimeMillis()), userName.trim());
    }
}
