package com.qunar.fresh.service;

import com.qunar.fresh.model.User;

public interface UserService {
    /**
     * 添加用户信息不完整的用户
     * 也支持信息完整的添加行为
     */
    String addIncompleteUser(User user);

    String updatePartlyData(User user);

}
