package com.qunar.fresh.exam1.dao;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After;

import java.lang.reflect.Method;

public class SpeakDaoTest { 



@Test
public void testProcessChatLog() throws Exception { 
//TODO: Test goes here... 
} 



@Test
public void testGetPath() throws Exception {
    SpeakDao speakDao = new SpeakDao();

} 

} 
