package com.qunar.fresh.exam1.main;


import com.qunar.fresh.exam1.dao.SpeakDao;
import com.qunar.fresh.exam1.entity.Speak;
import com.qunar.fresh.exam1.service.fileservice.AbstractFileService;
import com.qunar.fresh.exam1.service.fileservice.SpeakTimesFileService;
import com.qunar.fresh.exam1.service.fileservice.SpeakFileService;
import com.qunar.fresh.exam1.service.sortservice.SpeakSortService;
import com.qunar.fresh.exam1.service.sortservice.SpeakTimesSortService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * 具体需求逻辑，文件名，输入输出，操作都可随需求更改而更改
 */
public class Exam1Entry {
    public static final Logger log = LoggerFactory.getLogger(Exam1Entry.class);
    private static final String OUTPUT_FILE_CHAT = "chat_sorted.txt";
    public static final String READ_FILE_CHAT = "chat.txt";
    private static final String OUTPUT_FILE_COUNT = "count.txt";


    public static void main(String[] args) {

        SpeakDao speakDao = new SpeakDao();
        //speakDao.processChatLog();

        String path = speakDao.getPath(READ_FILE_CHAT);

        //获取到所有的聊天内容
        AbstractFileService fileService;
        fileService = new SpeakFileService();
        List<String> content = fileService.readFormFile(path);
        //将内容读取成对象
        List<Speak> speaks = speakDao.objectPacking(content);
        //对象排序
        new SpeakSortService().sort(speaks);

        //输出到文件chat_sorted.txt
        if (!fileService.writeToFile(speaks, speakDao.getOutputPath(OUTPUT_FILE_CHAT))) {
            log.info("output char_soted.txt failed.");
        }
        //统计发言次数
        HashMap<String, Integer> speakTimes = speakDao.getSpeakTimes(speaks);
        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(speakTimes.entrySet());
        //排序
        new SpeakTimesSortService().sort(list);
        //输出到文件count.txt
        fileService = new SpeakTimesFileService();
        if (!fileService.writeToFile(list, speakDao.getOutputPath(OUTPUT_FILE_COUNT))) {
            log.info("output count.txt failed.");
        }

        log.info("finished exam1");

    }




}
