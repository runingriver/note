package com.qunar.fresh.exam1.entity;


import java.io.Serializable;
import java.util.Date;

/**
 * 实体类，描述一个人的一次讲话信息
 */
public class Speak implements Serializable{
    private Date spokeTime;     //发言时间
    private String jobNumber;      //发言人号码
    private String nickname;  //发言人用的昵称
    private String content;     //发言内容

    public Speak() {
        content = null;
    }


    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        if (this.content == null) {
            this.content = content;
        } else {
            this.content += System.getProperty("line.separator") + content;
        }
    }

    public Date getSpokeTime() {
        return spokeTime;
    }

    public void setSpokeTime(Date spokeTime) {
        this.spokeTime = spokeTime;
    }

    public String getJobNumber() {
        return jobNumber;
    }

    public void setJobNumber(String jobNumber) {
        this.jobNumber = jobNumber;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }


    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(spokeTime).append(' ');
        stringBuilder.append(this.nickname).append(' ');
        stringBuilder.append('(').append(this.jobNumber).append(')');
        return stringBuilder.toString();
    }
}
