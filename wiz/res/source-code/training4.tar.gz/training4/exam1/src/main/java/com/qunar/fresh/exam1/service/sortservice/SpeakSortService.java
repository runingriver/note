package com.qunar.fresh.exam1.service.sortservice;

import com.qunar.fresh.exam1.entity.Speak;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 根据发言的时间，昵称，排序
 */
public class SpeakSortService implements ISortService<Speak> {
    public void sort(List<Speak> list) {
        Collections.sort(list, new Comparator<Speak>() {
            public int compare(Speak o1, Speak o2) {
                if (o1.getSpokeTime().getTime() > o2.getSpokeTime().getTime()) {
                    return 1;
                } else if (o1.getSpokeTime().getTime() == o2.getSpokeTime().getTime()) {
                    return Long.valueOf(o1.getJobNumber()).compareTo(Long.valueOf(o2.getJobNumber()));
                } else {
                    return -1;
                }
            }
        });
    }
}
