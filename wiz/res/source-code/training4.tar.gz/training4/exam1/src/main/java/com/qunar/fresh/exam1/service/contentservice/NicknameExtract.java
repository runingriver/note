package com.qunar.fresh.exam1.service.contentservice;

/**
 * 从字符串中提取昵称
 */
public class NicknameExtract implements IContentExtractService<String> {
    public String getInfo(String line) {
        return line.substring(20, line.indexOf('('));
    }
}
