package com.qunar.fresh.exam1.service.fileservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 文件操作接口，定义文件操作方式
 */
public abstract class AbstractFileService<T> {
    protected static final Logger log = LoggerFactory.getLogger(AbstractFileService.class);

    /**
     * 将集合中的内容写入到指定路径
     */
    public abstract Boolean writeToFile(List<T> content, String path);

    /**
     * 从指定路径的文件中读取内容到List中
     * 都是读取到list中，此方法可重用
     */
    public  List<String> readFormFile(String path){
        File file = new File(path);
        if (!isFile(file)) {
            return null;
        }
        BufferedReader in = null;
        String buffer = null;
        List<String> content = new ArrayList<String>();
        try {
            in = new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8"));
            //遍历文件，获取相应信息
            while ((buffer = in.readLine()) != null) {
                if (buffer.trim() != null){
                    content.add(buffer);
                }
            }
        } catch (FileNotFoundException e) {
            log.error("file not found:" + e.getMessage());
        } catch (IOException e) {
            log.error("file read error:" + e.getMessage());
        } finally {
            try {if (in != null) in.close();}
            catch (IOException e) {log.warn("BufferedReader close failed");}
        }
        return content;
    }

    /**
     *  检查给定文件是否是文件，如果不存在就创建一个
     */
    public Boolean isFile(File file) {
        if (file.isDirectory()) {
            return false;
        }
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                log.error("cannot create a new file");
                return false;
            }
        }
        return true;
    }
}
