package com.qunar.fresh.exam1.service.contentservice;


/**
 * 从字符串中提取工号
 */
public class JobNumberExtract implements IContentExtractService<String> {
    public String getInfo(String line) {
        return line.substring(line.indexOf('(')+1, line.lastIndexOf(')'));
    }
}
