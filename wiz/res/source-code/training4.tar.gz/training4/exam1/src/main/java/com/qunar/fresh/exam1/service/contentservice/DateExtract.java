package com.qunar.fresh.exam1.service.contentservice;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.Date;

/**
 * 从字符串中抽取时间
 */
public class DateExtract implements IContentExtractService<Date> {
    public Date getInfo(String line) {
        //不用正则，时间长度固定，格式基本固定，直接截取
        String dateString = line.trim().substring(0, 19);
        Date date = new Date();
        String format = "yyyy-MM-dd HH:mm:ss";
        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern(format);

        return dateTimeFormatter.parseDateTime(dateString).toDate();
    }
}
