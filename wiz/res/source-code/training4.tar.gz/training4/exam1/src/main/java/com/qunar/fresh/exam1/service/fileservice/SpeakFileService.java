package com.qunar.fresh.exam1.service.fileservice;

import com.qunar.fresh.exam1.entity.Speak;
import org.joda.time.DateTime;

import java.io.*;
import java.util.List;

/**
 * 将对话（Speak）输入，输出到文件中
 */
public class SpeakFileService extends AbstractFileService<Speak> {
    public Boolean writeToFile(List<Speak> content, String path) {
        File file = new File(path);
        if (!isFile(file)) {
            return false;
        }
        PrintWriter pw = null;
        StringBuilder line = null;
        try {
            pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file),"UTF-8"));
            for (int i=0,n= content.size();i<n;i++) {
                line = new StringBuilder();
                line.append(new DateTime(content.get(i).getSpokeTime()).toString("yyyy-MM-dd HH:mm:ss"));
                line.append(content.get(i).getNickname()).append('(').append(content.get(i).getJobNumber()).append(')');
                pw.println(line);
                pw.println(content.get(i).getContent());
            }
            pw.flush();

        } catch (FileNotFoundException e) {
            log.error("cannot find the file:"+e.getMessage());
            return false;
        } catch (UnsupportedEncodingException e) {
            log.error("encoding error:"+e.getMessage());
            return false;
        }finally {
            pw.close();
        }
        return true;
    }
}
