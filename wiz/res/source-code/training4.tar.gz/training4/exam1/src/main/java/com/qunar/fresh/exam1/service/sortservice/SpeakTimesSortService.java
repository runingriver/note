package com.qunar.fresh.exam1.service.sortservice;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * 发言次数，根据工号排序，排序规则
 */
public class SpeakTimesSortService implements ISortService<Map.Entry<String, Integer>>{
    public void sort(List<Map.Entry<String, Integer>> list) {
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return Long.valueOf(o1.getKey()).compareTo(Long.valueOf(o2.getKey()));
            }
        });
    }
}
