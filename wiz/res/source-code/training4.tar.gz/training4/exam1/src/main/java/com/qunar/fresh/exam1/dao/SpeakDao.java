package com.qunar.fresh.exam1.dao;


import com.qunar.fresh.exam1.entity.Speak;
import com.qunar.fresh.exam1.service.contentservice.DateExtract;
import com.qunar.fresh.exam1.service.contentservice.JobNumberExtract;
import com.qunar.fresh.exam1.service.contentservice.NicknameExtract;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SpeakDao {
    private static final Logger log = LoggerFactory.getLogger(SpeakDao.class);

    private static final String TITLE_PATTERN_REGEX =
            "^\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s.*\\([0-9]{8,12}\\)$";

    public Boolean processChatLog() {
        return true;
    }

    /**
     * 获取项目根目录路径+filename
     */
    public String getPath(String filename) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(System.getProperty("user.dir"));
        stringBuilder.append("/exam1/src/main/resources/");
        stringBuilder.append(filename);
        return stringBuilder.toString();
    }

    /**
     * 获取输出filename到项目根目录的路径
     */
    public String getOutputPath(String filename) {
        return System.getProperty("user.dir")+ '/' + filename;
        //下面这个是安装包的根目录
        //return SpeakDao.class.getResource("/").getPath() + filename;
    }

    /**
     * 将内容打包成Speak对象
     */
    public List<Speak> objectPacking(List<String> content) {
        List<Speak> speaks = new ArrayList<Speak>();
        Speak speaker = null;
        Date dateTime = null;
        String nickname = null;
        String numberString = null;

        Pattern pattern = Pattern.compile(TITLE_PATTERN_REGEX);
        Matcher matcher;
        int flag = -1; //标示内容，如果内容有多行，就需要重复添加
        for (int i = 0, n = content.size(); i < n; i++) {
            matcher = pattern.matcher(content.get(i));
            if (matcher.matches()) {
                speaker = new Speak();
                flag++;
                //发言时间
                dateTime = new DateExtract().getInfo(content.get(i));
                speaker.setSpokeTime(dateTime);

                //昵称
                nickname = new NicknameExtract().getInfo(content.get(i));
                speaker.setNickname(nickname);

                //工号
                numberString = new JobNumberExtract().getInfo(content.get(i));
                speaker.setJobNumber(numberString);
                speaks.add(speaker);
            } else {
                speaks.get(flag).setContent(content.get(i));
            }
        }
        return speaks;
    }

    /**
     * 获取发言时间和次数
     */
    public HashMap<String, Integer> getSpeakTimes(List<Speak> speaks) {
        HashMap<String, Integer> speakTimes = new HashMap<String, Integer>();
        String key = null;
        Integer value;
        for (int i = 0, n = speaks.size(); i < n; i++) {
            key = speaks.get(i).getJobNumber();
            if (speakTimes.containsKey(key)) {
                speakTimes.put(key, speakTimes.get(key) + 1);
            } else {
                speakTimes.put(key, 1);
            }
        }
        return speakTimes;
    }

}
