package com.qunar.fresh.exam1.service.contentservice;

/**
 * 内容提取接口
 * 现在需要从一行字符串中提取，时间，昵称，编号
 * 以后可能需要在对话内容中提取其他信息
 * 作为可变部分，加接口
 */
public interface IContentExtractService<T> {
    public T getInfo(String line);

}
