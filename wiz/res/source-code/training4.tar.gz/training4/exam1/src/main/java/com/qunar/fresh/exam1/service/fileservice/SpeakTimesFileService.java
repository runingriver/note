package com.qunar.fresh.exam1.service.fileservice;

import java.io.*;
import java.util.List;
import java.util.Map;

/**
 * 将对话的次数，按格式要求输出到文件
 */
public class SpeakTimesFileService extends AbstractFileService<Map.Entry<String, Integer>> {

    public Boolean writeToFile(List<Map.Entry<String, Integer>> list, String path) {
        File file = new File(path);
        if (!isFile(file)) {
            return false;
        }
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file),"UTF-8"));
            for (int i=0,n= list.size();i<n;i++) {
                pw.println(list.get(i).getKey() + ':' + list.get(i).getValue().toString());
            }
            pw.flush();
            pw.close();
        } catch (FileNotFoundException e) {
            log.error("cannot find the file:"+e.getMessage());
            return false;
        } catch (UnsupportedEncodingException e) {
            log.error("encoding error:"+e.getMessage());
            return false;
        }
        return true;
    }
}
