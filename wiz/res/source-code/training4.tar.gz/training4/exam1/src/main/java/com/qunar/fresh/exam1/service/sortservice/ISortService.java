package com.qunar.fresh.exam1.service.sortservice;

import java.util.List;

/**
 * 排序接口
 * 根据题目，多处需要按照特定需求排序，提取出来
 */
public interface ISortService<T> {
    void sort(List<T> list);
}
