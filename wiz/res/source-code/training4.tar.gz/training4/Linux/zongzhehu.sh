#!/bin/bash.sh

curl -d "username=zongzhe.hu&password=123" l-marmot3.wap.cn6.qunar.com:8080/user/register
curl -c /tmp/qunar-cookies -d "name=zongzhe.hu&password=123" l-marmot3.wap.cn6.qunar.com:8080/user/login
curl -b /tmp/qunar-cookies -F "file=@/tmp/zongzhehu.sh" l-marmot3.wap.cn6.qunar.com:8080/user/homework
