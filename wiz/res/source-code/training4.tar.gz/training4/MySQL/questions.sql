#建立数据库
DROP DATABASE IF EXISTS qunar_books_db;
CREATE DATABASE qunar_books_db;
ALTER DATABASE qunar_books_db
DEFAULT CHARACTER SET utf8mb4;
SHOW DATABASES;

#建立表
#图书表
USE qunar_books_db;
DROP TABLE IF EXISTS book_info;
CREATE TABLE book_info (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT 'id',
  book_id    INT UNSIGNED    NOT NULL
  COMMENT '图书id',
  author_id  INT UNSIGNED    NOT NULL
  COMMENT '图书作者id',
  book_name  VARCHAR(20)     NOT NULL
  COMMENT '图书名',
  book_pages INT UNSIGNED    NOT NULL
  COMMENT '图书的页数',
  book_press VARCHAR(50)     NOT NULL
  COMMENT '图书出版社',
  PRIMARY KEY (id)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '图书表';

#奖项表
DROP TABLE IF EXISTS awards;
CREATE TABLE awards (
  id        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT 'id',
  book_id   INT UNSIGNED    NOT NULL
  COMMENT '图书id',
  author_id INT UNSIGNED    NOT NULL
  COMMENT '图书作者id',
  cup_type  TINYINT         NOT NULL
  COMMENT '奖励类型：金奖-1，银奖-2，铜奖-3',
  cup_time  DATETIME        NOT NULL DEFAULT '0000-00-00 00:00:00'
  COMMENT '奖励时间',
  PRIMARY KEY (id)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '奖项表';

#作者表
DROP TABLE IF EXISTS authors;
CREATE TABLE authors (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT 'id',
  author_id      INT UNSIGNED    NOT NULL
  COMMENT '作者id',
  author_name    VARCHAR(20)     NOT NULL
  COMMENT '作者姓名',
  author_content VARCHAR(255)    NOT NULL
  COMMENT '作者简介',
  PRIMARY KEY (id)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COMMENT = '作者';

SHOW TABLES FROM qunar_books_db;
#END------------------------------------------------------------------------

#设计索引，写出创建索引的语句
#针对下面语句设计索引
ALTER TABLE awards
  ADD INDEX idx_authorid(author_id);
ALTER TABLE awards
  ADD INDEX idx_cuptype_bookid(cup_type, book_id);

ALTER TABLE authors
  ADD UNIQUE INDEX uniq_authorname_authorid(author_name, author_id);
ALTER TABLE authors
  ADD UNIQUE INDEX uniq_id_name(author_id, author_name);

#END------------------------------------------------------------------------
#测试用例
INSERT INTO authors (author_id, author_name, author_content) VALUES
  (1, 'AAA', 'Aqwe'), (2, 'BBB', 'Bqwe'),
  (3, 'CCC', 'Cqwe'), (4, 'BBB', 'Basd'),
  (5, '王1', 'Aqwe'), (6, '王2', 'Bqwe');

INSERT INTO awards (book_id, author_id, cup_type, cup_time) VALUES
  (1, 2, 1, '2016-07-28 10:12:12'),
  (2, 3, 2, '2016-07-28 11:12:12'),
  (3, 4, 3, '2016-07-28 14:12:12'),
  (4, 1, 1, '2016-07-28 14:12:12'),
  (5, 2, 2, '2016-07-28 10:12:12'),
  (6, 3, 1, '2016-07-28 11:12:12');

INSERT INTO book_info (book_id, author_id, book_name, book_pages, book_press) VALUES
  (1, 2, '图书1', 2001, '清华大小出版社'),
  (2, 3, '图书2', 2004, '清华大小出版社'),
  (3, 4, '图书3', 2002, '清华大小出版社'),
  (4, 1, '图书4', 2006, '清华大小出版社');
#END------------------------------------------------------------------------

#三、完成以下SQL
#1. 查询姓王的作者有多少
USE qunar_books_db;
SELECT COUNT(*)
FROM authors
WHERE author_name LIKE '王%';

#2. 查询获奖作者总人数
SELECT SQL_CALC_FOUND_ROWS author_id
FROM awards
GROUP BY author_id;
SELECT FOUND_ROWS() AS pageCount;

#3. 查询同时获得过金奖、银奖的作者姓名
EXPLAIN SELECT t1.author_name
        FROM authors t1
          JOIN awards t2 ON t1.author_id = t2.author_id
        WHERE t2.cup_type = 1 AND t2.author_id IN (SELECT author_id
                                                   FROM awards
                                                   WHERE cup_type = 2);

#4. 查询获得过金奖的图书有多少本，银奖的有多少本
#EXPLAIN SELECT pageCount(DISTINCT book_id) FROM awards WHERE cup_type=1;
#EXPLAIN SELECT pageCount(DISTINCT book_id) FROM awards WHERE cup_type=2;
EXPLAIN SELECT pageCount(DISTINCT book_id) AS 'awards_count'
        FROM awards
        WHERE cup_type IN (1, 2)
        GROUP BY cup_type;

#5. 查询最近一年内获过奖的作者姓名
EXPLAIN SELECT t1.author_name
        FROM authors t1
          JOIN awards t2
            ON t1.author_id = t2.author_id AND cup_time >= DATE_SUB(now(), INTERVAL 1 YEAR)
        GROUP BY t1.author_name;
#END-------------------------------------------------------------------------------------------------
/*
四、
1. 如何查看表的结构信息？
答：show create table tb_name\G;

2. 联合索引中的字段顺序应该如何设计？
答：联合索引具有最左优先原则，所以；利用explain，日志等手段分析，字段使用频率并根据where语句中字段使用频率来决定顺序！

3. int(10)和varchar(10)两个字段的(10)有什么区别？
答：int(10)中10没有具体意义不会影响int的大小，varchar(10)表示字段长度最长为10（如果是utf8mb4编码，(10*4-1)/4=9个中文字符），
并占用1个字节来记录可变长度的varchar字段的长度。

4. 以下查询如何创建索引能够实现覆盖索引优化？（请给出具体SQL）
select invalid_time_flag from pushtoken_android_62
where uid = 'AC54E24E-FB73-3981-C4BC-CED8D69407F8'
and pid = '10010'
select pageCount(*) from pushtoken_android_62
where uid = 'AC54E24E-FB73-3981-C4BC-CED8D69407F8'
and pid = '10010'
答：ALTERT TABLE pushtoken_android_62 ADD INDEX 'idx_pid_uid_ivadtime'('pid','uid','invalid_time_flag');

*/