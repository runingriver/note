package com.qunar.fresh.exam2.interfaces;

/**
 * 策略
 */
public interface CmdStrategy {
    /**
     * 执行linux命令
     * @return  命令执行结果
     */
    String execute();

    /**
     * 根据给定的数据，指定linux命令
     * @param data String
     * @return String
     */
    String executeByData(String data);
}
