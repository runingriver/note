package com.qunar.fresh.exam2.command;

import com.google.common.base.*;
import com.google.common.collect.Lists;
import com.qunar.fresh.exam2.input.FileInput;
import com.qunar.fresh.exam2.interfaces.CmdStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * WC命令处理暂时只支持一个参数，多个文件的操作
 */
public class WC implements CmdStrategy {
    public static final Logger log = LoggerFactory.getLogger(CmdStrategy.class);
    private final String cmdParameter;         //参数只有一个
    private final List<String> fileNameList;       //支持同时处理多个文件
    private final boolean isValided;

    /**
     * 枚举合法参数
     */
    private static enum ParameterType {
        c, l, w, help, bytes, chars, lines, words
    }

    private WC(String cmdParameter, List<String> fileNameList, boolean isValided) {
        this.cmdParameter = cmdParameter;
        this.fileNameList = fileNameList;
        this.isValided = isValided;
    }

    /**
     * 使用命令实例化CAT，并进行参数检查
     */
    public static WC newInstance(String cmdLine) {
        if (Strings.isNullOrEmpty(cmdLine)) {
            return new WC(null, null, false);
        }

        return checkForCmdLine(cmdLine);
    }

    /**
     * 解析并检查所有参数的合法性
     */
    public static WC checkForCmdLine(String cmdLine) {
        List<String> cmdLists = Splitter.on(CharMatcher.WHITESPACE)
                .omitEmptyStrings()
                .trimResults()
                .splitToList(cmdLine);

        if (!cmdLists.get(0).toLowerCase().equals("wc")) {
            return new WC(null, null, false);
        }
        String parameter = null;
        List<String> fileName = Lists.newArrayList();
        boolean isValidFile = false;
        boolean isValidParameter = false;
        String tmpString = null;
        for (int i = 1, n = cmdLists.size(); i < n; i++) {
            tmpString = cmdLists.get(i);

            //解析参数
            //参数支持形式：-l;-lm;--l;
            if (tmpString.startsWith("-")) {
                tmpString = CharMatcher.is('-').removeFrom(tmpString);
                parameter = tmpString;
            } else {
                /** 以"/"开头我们认为是绝对路径，否则就是相对路径 */
                if (!tmpString.startsWith("/")) {
                    tmpString = FileInput.getUserHomeFilePath(tmpString);
                }
                fileName.add(tmpString);
            }
        }
        //参数检查
        isValidParameter = checkParameter(parameter);
        isValidFile = FileInput.checkIsFile(fileName);

        if (!isValidParameter) {
            log.info("cat: invalid option -- {}", parameter);
            log.info("Try 'cat --help' for more information.");

        }
        return new WC(parameter, fileName, isValidFile && isValidParameter);
    }

    /**
     * 检查Options参数的合法性
     */
    public static boolean checkParameter(String parm) {
        //没有参数返回true
        if (Strings.isNullOrEmpty(parm)) {
            return true;
        }
        try {
            ParameterType.valueOf(String.valueOf(parm));
        } catch (IllegalArgumentException e) {
            log.info("cat: invalid option -- {}", parm);
            log.info("Try 'cat --help' for more information.");
            return false;
        }
        return true;
    }

    public String execute() {
        if (!isValided) {
            return null;
        }
        List<String> allContent = Lists.newArrayList();
        //支持多个文件的操作
        for (String s : fileNameList) {
            List<String> content = FileInput.readAllLineFromFile(s);
            if (content == null) {
                return null;
            }
            String processResult = processParameter(content);
            allContent.add(processResult);
        }

        return Joiner.on(System.getProperty("line.separator")).join(allContent);
    }

    public String executeByData(String data) {
        if (!isValided) {
            return null;
        }
        List<String> content = Splitter.on(System.getProperty("line.separator")).splitToList(data);
        String processResult = processParameter(content);
        return processResult;
    }

    /**
     * 根据参数执行相应操作
     */
    private String processParameter(List<String> content) {
        if (Strings.isNullOrEmpty(cmdParameter)) {
            return processNon(content);
        }
        if (cmdParameter.equals("l")) {
            return String.valueOf(processL(content));
        }

        return "sorry,function in building...";
    }


    /**
     * -l参数的处理
     */
    private int processL(List<String> content) {
        return content.size();
    }

    /**
     * 没有任何参数时输出行数，字节数，字符数
     */
    private String processNon(List<String> content) {
        return "sorry,function in building...";
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).
                add("cmdParameter", cmdParameter)
                .add("fileName", fileNameList)
                .add("isValided",isValided)
                .toString();
    }

    /**下面可以实现，其他参数*/
    //.....
}
