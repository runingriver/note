package com.qunar.fresh.exam2.input;

import com.google.common.base.Charsets;
import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.io.Files;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * linux命令用到文件读取的相关操作
 */
public class FileInput {
    public static final Logger log = LoggerFactory.getLogger(FileInput.class);
    private FileInput() {
    }

    /**
     * 获取系统用户目录，并拼装到给定的字符串上
     * @param filePath String 给定的字符串
     * @return String
     */
    public static String getUserHomeFilePath(String filePath) {
        if (Strings.isNullOrEmpty(filePath)) {
            return null;
        }
        File file = new File(filePath);
        //如果没有找不到该文件，就在该文件前面加上根目录
        StringBuilder sb = new StringBuilder();
        String homePath = System.getProperties().getProperty("user.home");
        if (!file.exists()) {
            //log.debug(File.listRoots()[0].toString());
            if (filePath.startsWith("~/")) {
                sb.append(homePath).append(filePath.substring(1));
            }else {
                sb.append(homePath).append('/').append(filePath);
            }

        }
        return sb.toString();
    }

    /**
     * 检查指定路径的文件是否正确
     * @param fileName String
     * @return boolean
     */
    public static boolean checkIsFile(String fileName) {
        if (Strings.isNullOrEmpty(fileName)) {
            return false;
        }
        File file = new File(fileName);
        if (file.exists() && file.canRead() && file.isFile()) {
            return true;
        }
        log.info("{}: No such file or directory.", fileName);
        return false;
    }

    /**
     * 检查给定集合中的路径是否都正确
     * @param fileList List<String>
     * @return boolean
     */
    public static boolean checkIsFile(List<String> fileList) {
        boolean isAllRightFile = true;
        for (String s : fileList) {
            if (isAllRightFile = checkIsFile(s)) {
                continue;
            }
            log.info("{}: No such file or directory.",s);
        }

        return isAllRightFile;
    }

    /**
     * 从给定的文件中读取所有行到List<String>中
     * @param filePath  String
     * @return List<String>
     */
    public static List<String> readAllLineFromFile(String filePath) {
        Preconditions.checkNotNull(filePath);
        List<String> content = null;
        try {
            content = Files.readLines(new File(filePath), Charsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
        return content;
    }
}
