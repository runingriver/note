package com.qunar.fresh.exam2.command;

import com.qunar.fresh.exam2.interfaces.CmdStrategy;

/**
 * for extense the help
 * 待扩展
 */
public class CmdHelp implements CmdStrategy {

    public CmdHelp(String cmdLine) {

    }

    public String execute() {
        return null;
    }

    public String executeByData(String data) {
        return null;
    }

}
