package com.qunar.fresh.exam2.output;


import com.google.common.base.Joiner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * 输出器，将结果输出到命令行
 */
public class Outputer {
    public static final Logger log = LoggerFactory.getLogger(Outputer.class);
    private final String outString;

    private Outputer(String output) {
        this.outString = checkNotNull(output);
    }

    /**
     * 获取一个Output实例
     * @param output
     * @return
     */
    public static Outputer output(String output) {
        return new Outputer(output);
    }

    /**
     * 获取一个将List<String>作为数据源，输出到控制台的实例
     * @param outList List<String>
     * @return Outputer
     */
    public static Outputer output(List<String> outList) {
        String newLine = System.getProperty("line.separator");
        String output = Joiner.on(newLine).join(outList.iterator());
        return new Outputer(output);
    }

    /**
     * 将实例内容，输出到控制台
     * @return boolean
     */
    public boolean outToConsole() {
        if (log.isInfoEnabled()) {
            log.info(outString);
            return true;
        }
        return false;
    }
}
