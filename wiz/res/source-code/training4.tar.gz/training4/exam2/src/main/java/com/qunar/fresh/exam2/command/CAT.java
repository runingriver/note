package com.qunar.fresh.exam2.command;

import com.google.common.base.*;
import com.qunar.fresh.exam2.input.FileInput;
import com.qunar.fresh.exam2.interfaces.CmdStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Cat命令实现
 */
public class CAT implements CmdStrategy {
    public static final Logger log = LoggerFactory.getLogger(CAT.class);
    private final String cmdParameter;
    private final String fileName;
    private final boolean isValided;

    private static enum ParameterType {
        A, b, e, E, n, s, t, T, u, number, numbernonblank, squeezeblank, shownonprinting
    }

    private CAT(String cmdParameter, String fileName, boolean isValided) {
        this.cmdParameter = cmdParameter;
        this.fileName = fileName;
        this.isValided = isValided;
    }

    /**
     * 使用命令实例化CAT，并进行参数检查
     */
    public static CAT newInstance(String cmdLine) {
        if (Strings.isNullOrEmpty(cmdLine)) {
            return new CAT(null, null, false);
        }

        return checkForCmdLine(cmdLine);
    }

    /**
     * 解析并检查所有参数的合法性
     */
    public static CAT checkForCmdLine(String cmdLine) {
        List<String> cmdLists = Splitter.on(CharMatcher.WHITESPACE)
                .omitEmptyStrings()
                .trimResults()
                .splitToList(cmdLine);

        if (!cmdLists.get(0).toLowerCase().equals("cat")) {
            return new CAT(null, null, false);
        }
        String parameter = null;
        String fileName = null;
        boolean isValidFile = false;
        boolean isValidParameter = false;
        String tmpString = null;
        //用循环以便，参数顺序，多条参数
        for (int i = 1, n = cmdLists.size(); i < n; i++) {
            tmpString = cmdLists.get(i);
            if (tmpString.contains("-")) {
                tmpString = CharMatcher.is('-').removeFrom(tmpString);
                parameter = tmpString;
            } else {
                /**以/开头我们认为是绝对路径，否则就是相对路径*/
                if (!tmpString.startsWith("/")) {
                    tmpString = FileInput.getUserHomeFilePath(tmpString);
                }
                fileName = tmpString;
            }
        }

        //参数检查
        isValidParameter = checkParameter(parameter);
        isValidFile = FileInput.checkIsFile(tmpString);

        return new CAT(parameter, fileName, isValidFile && isValidParameter);
    }

    /**
     * 检查Options参数的合法性
     */
    public static boolean checkParameter(String parm) {
        //没有参数返回true
        if (Strings.isNullOrEmpty(parm)) {
            return true;
        }
        for (int i = 0, n = parm.length(); i < n; i++) {
            try {
                ParameterType.valueOf(String.valueOf(parm.charAt(i)));
            } catch (IllegalArgumentException e) {
                log.info("cat: invalid option -- {}", parm);
                log.info("Try 'cat --help' for more information.");
                return false;
            }
        }
        return true;
    }

    public String execute() {
        if (!isValided) {
            return null;
        }
        List<String> content = FileInput.readAllLineFromFile(fileName);
        if (content == null) {
            return null;
        }
        return Joiner.on(System.getProperty("line.separator")).join(content);
    }

    /**
     * 不需要实现，返回null
     */
    public String executeByData(String data) {
        return null;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).
                add("cmdParameter", cmdParameter)
                .add("fileName", fileName)
                .add("isValided",isValided)
                .toString();
    }

}
