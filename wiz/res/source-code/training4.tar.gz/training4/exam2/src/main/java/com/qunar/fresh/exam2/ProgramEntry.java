package com.qunar.fresh.exam2;

import com.qunar.fresh.exam2.mainentry.CmdProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 适配器模式处理命令分派，策略模式处理命令处理
 */
public class ProgramEntry {
    public static final Logger log = LoggerFactory.getLogger(ProgramEntry.class);
    public static void main(String[] args) {
        CmdProcessor.executeCommand();
    }
}
