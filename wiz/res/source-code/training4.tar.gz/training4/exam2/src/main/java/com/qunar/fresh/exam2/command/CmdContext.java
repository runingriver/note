package com.qunar.fresh.exam2.command;

import com.google.common.base.CharMatcher;
import com.google.common.base.Optional;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.qunar.fresh.exam2.interfaces.CmdStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * 策略context：初步检测与转发
 */
public class CmdContext {
    public static final Logger log = LoggerFactory.getLogger(CmdContext.class);
    private final List<CmdStrategy> cmdStrategyList;
    private final int cmdNumber;

    private static enum Command{
        GREP,CAT,WC
    }

    public CmdContext(List<CmdStrategy> strategies) {
        this.cmdStrategyList = strategies;
        cmdNumber = strategies.size();
    }

    /**
     * 将命令解析出来，并建立CmdContext的实例
     */
    public static CmdContext command(String line) {
        if (Strings.isNullOrEmpty(line)) {
            return null;
        }
        if (line.toLowerCase().trim().equals("exit")) {
            System.exit(0);  //0-ok
        }

        //不转换大小写
        List<String> cmdLists = Splitter.on('|')
                .omitEmptyStrings()
                .trimResults()
                .splitToList(line);

        //检测参数是否实现
        if (!checkForCommand(cmdLists)) {
            return null;
        }

        //装配命令
        List<CmdStrategy> cmdStrategies = Lists.newArrayList();
        CmdStrategy cmdType = null;
        for (String cmd : cmdLists) {
            log.debug("cmd:{}; cmdList count:{}",cmd,cmdLists.size());
            cmdType = CommandType.getStrategy(cmd);
            cmdStrategies.add(cmdType);
        }

        return new CmdContext(cmdStrategies);
    }

    private static boolean checkForCommand(List<String> cmdTypeList) {
        boolean isValidCommand = true;
        for (String s : cmdTypeList) {
            try {
                Command.valueOf(Splitter.on(CharMatcher.WHITESPACE)
                        .trimResults()
                        .omitEmptyStrings()
                        .splitToList(s)
                        .get(0).toUpperCase());
            } catch (IllegalArgumentException e) {
                log.info("Command '{}': not found.", s);
                isValidCommand = false;
            }
        }
        return isValidCommand;
    }

    /**
     * 执行命令，返回命令执行结果
     * @return Optional<String>
     */
    public Optional<String> executeCommand() throws Exception {
        //一条命令的执行
        Optional<String> optional = Optional.absent();
        if (1 == cmdNumber) {
            try {
                log.debug(cmdStrategyList.get(0).toString());
                optional = Optional.of(cmdStrategyList.get(0).execute());
            } catch (Exception e) {
                //do nothing...
            }

        } else if (cmdNumber > 1) {
            String tmpResult = null;
            boolean started = false;
            for (CmdStrategy cmd : cmdStrategyList) {
                log.debug(cmd.toString());
                if (Strings.isNullOrEmpty(tmpResult)) {
                    //如果前面命令返回null，就失败！
                    if (started) {
                        break;
                    }

                    tmpResult = cmd.execute();
                    started = true;
                } else {
                    tmpResult = cmd.executeByData(tmpResult);
                }
                optional = Optional.of(tmpResult);
            }
        }

        return optional;
    }

    /**
     * 命令类型选择
     */
    private static enum CommandType {
        CAT {
            CmdStrategy getInstance(String cmdLine) {
                return com.qunar.fresh.exam2.command.CAT.newInstance(cmdLine);
            }
        },
        GREP {
            CmdStrategy getInstance(String cmdLine) {
                return com.qunar.fresh.exam2.command.GREP.newInstance(cmdLine);
            }
        },
        WC {
            CmdStrategy getInstance(String cmdLine) {
                return com.qunar.fresh.exam2.command.WC.newInstance(cmdLine);
            }
        };

        abstract CmdStrategy getInstance(String cmdLine);

        public static CmdStrategy getStrategy(String cmdLine) {
            String cmdLowerCase = cmdLine.toLowerCase();
            if (cmdLowerCase.startsWith("cat")) {
                return CAT.getInstance(cmdLine);
            }
            if (cmdLowerCase.startsWith("grep")) {
                return GREP.getInstance(cmdLine);
            }
            if (cmdLowerCase.startsWith("wc")) {
                return WC.getInstance(cmdLine);
            }
            return new CmdHelp(cmdLine);
        }
    }

}
