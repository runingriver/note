package com.qunar.fresh.exam2.mainentry;

import com.google.common.base.Optional;
import com.google.common.base.Strings;
import com.qunar.fresh.exam2.command.CmdContext;
import com.qunar.fresh.exam2.output.Outputer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Scanner;

/**
 * 命令获取，执行，输出---不变类
 */
public class CmdProcessor{
    public static final Logger log = LoggerFactory.getLogger(CmdProcessor.class);

    /**
     * 命令入口函数，包含了这个命令过程
     */
    public static void executeCommand() {
        Scanner scanner = new Scanner(System.in,"utf-8");
        while (true) {
            log.info("input command~$");
            String line = scanner.nextLine();
            if (Strings.isNullOrEmpty(line.trim())) {
                continue;
            }
            Optional<String> optional = Optional.absent();
            try {
                //执行命令
                CmdContext context = CmdContext.command(line);
                optional = context.executeCommand();
            } catch (Exception e) {
                continue;
            }

            //输出命令
            if (!optional.isPresent()) {
                continue;
            }
            Outputer.output(optional.get()).outToConsole();
        }
    }
}
