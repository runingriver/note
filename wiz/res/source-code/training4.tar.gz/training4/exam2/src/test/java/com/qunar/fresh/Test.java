package com.qunar.fresh;

import com.google.common.base.Optional;
import com.qunar.fresh.exam2.command.CmdContext;
import com.qunar.fresh.exam2.output.Outputer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Test {
    public static final Logger log = LoggerFactory.getLogger(Test.class);

    public static void testCommand(String cmd) {
        Optional<String> optional = Optional.absent();
        try {
            //执行命令
            CmdContext context = CmdContext.command(cmd);
            optional = context.executeCommand();
        } catch (Exception e) {
            log.debug("wrong.",e);
        }
        try {
            Outputer.output(optional.get()).outToConsole();
        } catch (Exception e) {

        }
    }

    @org.junit.Test
    public void testCat() throws Exception  {
        testCommand("cat t1.txt");
        testCommand("Cat /home/zongzhehu/Documents/log.txt");
        testCommand("cat ~/Documents/log.txt");
        testCommand("CAT ~/Documents/log.txt");

        testCommand("cat ~/Documents/log.txt | grep GET");

    }

    @org.junit.Test
    public void testGrep() throws Exception  {
        testCommand("grep t1.txt");
        testCommand("Grep /home/zongzhehu/Documents/log.txt");
        testCommand("GREP GET ~/Documents/log.txt");
        testCommand("GREP \"GET\" ~/Documents/log.txt");
    }

    @org.junit.Test
    public void testWc() throws Exception  {
        testCommand("wc t1.txt");   // No such file or directory.
        testCommand("wc /home/zongzhehu/Documents/log.txt"); //sorry,function in building...
        testCommand("WC -l ~/Documents/log.txt");
        testCommand("WC -l ~/Documents/log.txt ~/Documents/content.txt");

    }

    @org.junit.Test
    public void testAll() throws Exception  {
        //模拟测试
        testCommand("cat ~/Documents/log.txt | grep GET  | wc -l ");
        testCommand("cat ~/Documents/log.txt   | wc -l | grep 1 ");
    }


}
