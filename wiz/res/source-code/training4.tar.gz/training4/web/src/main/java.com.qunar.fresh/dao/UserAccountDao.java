package dao;

import model.UserAcountInfo;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * 用户账号操作接口
 */
public interface UserAccountDao {

    /**
     * 通过账号，查询用户
     */
    UserAcountInfo queryById(String userId) throws SQLException ;

    /**
     * 通过用户名，查询用户
     */
    UserAcountInfo queryByUserName(String userName) throws SQLException ;


    /**
     * 查询所有活跃用户数据显示
     * 这里参数n是将来实现查询前N个数据
     */
    List<UserAcountInfo> queryAllUser(int n)throws SQLException;

    /**
     * 将一个新用户写入数据库
     */
    int save(UserAcountInfo userAcountInfo) throws SQLException ;

    /**
     * 更新数据
     */
    int update(UserAcountInfo userAcountInfo) throws SQLException;

    /**
     * 根据用户账号，更新用户名密码
     */
    int updateUserNameAndPassword(String userid, String username, String password) throws SQLException;

    /**
     * 更新用户
     */
    int update(UserAcountInfo userAcountInfo, Connection connection) throws SQLException;

    /**
     * 删除用户，将status设为0，表示非活跃用户
     */
    int deleteUserByUserId(String userid)throws SQLException;
}
