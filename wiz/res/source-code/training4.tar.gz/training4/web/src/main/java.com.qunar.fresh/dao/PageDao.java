package dao;

import model.PageInfo;

import java.sql.SQLException;
import java.util.List;

public interface PageDao {
    List<PageInfo> queryByUserName(String userName) throws SQLException;

    List<PageInfo> queryByPageName(String pageName) throws SQLException;

    List<PageInfo> queryAll() throws SQLException;

    PageInfo queryByPageAndUser(String userName, String pageName)throws SQLException;

    int savePage(PageInfo pageInfo) throws SQLException;

}
