package controller;

import com.google.common.base.Strings;
import dao.UserAccountDao;
import dao.impl.UserAccountDaoImpl;
import model.UserAcountInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;


@WebServlet(name = "RegisterServlet", urlPatterns = "/register")
public class RegisterServlet extends HttpServlet {
    public static final Logger log = LoggerFactory.getLogger(RegisterServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        HttpSession session = req.getSession(true);

        //检查用户注册信息，并写入数据库
        String userName = setRegister(req, resp);

        //设置cookie和session，允许重复的用户注册
        Cookie userCookie = new Cookie("logined", userName);
        userCookie.setMaxAge(60*60*24);
        resp.addCookie(userCookie);
        session.setAttribute("userName", userName);

        req.getRequestDispatcher("/pages/succeed.jsp").forward(req, resp);
    }

    private String setRegister(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取用户注册信息
        UserAcountInfo userAcountInfo = new UserAcountInfo();
        String userId = req.getParameter("userId");
        String userName = req.getParameter("userName");
        String userPassword = req.getParameter("userPassword");

        //参数检查,重复注册和注册格式逻辑不判断！
        if (Strings.isNullOrEmpty(userId)
                && Strings.isNullOrEmpty(userName)
                && Strings.isNullOrEmpty(userPassword)) {
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        }
        userAcountInfo.setUserId(userId);
        userAcountInfo.setUserName(userName);
        userAcountInfo.setUserPassword(userPassword);
        Double money = Double.valueOf(req.getParameter("money"));
        userAcountInfo.setMoney(money == null ? 0.00 : money);
        userAcountInfo.setUpdateTime(new Date());

        //默认用户角色和状态
        userAcountInfo.setRole(1);
        userAcountInfo.setStatus(1);

        //写入数据库
        UserAccountDao userDao = new UserAccountDaoImpl();
        try {
            userDao.save(userAcountInfo);
        } catch (SQLException e) {
            log.error("insert a new user in database exception", e);
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        }
        return userName;
    }
}
