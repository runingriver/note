package controller;

import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import service.PageService;
import service.impl.PageServiceImpl;
import util.Common;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * 统计页面访问的监听器
 */
@WebListener
public class ViewsCountListener implements ServletRequestListener {
    public static final Logger log = LoggerFactory.getLogger(ViewsCountListener.class);

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        log.debug("request destroyed in the listener",sre.getServletContext().getServerInfo());
        return;
    }

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        log.debug("request init in the listener",sre.getServletContext().getServerInfo());
        HttpServletRequest req = (HttpServletRequest) sre.getServletRequest();
        String requestPage = req.getRequestURI();

        //访问,cookie,如果用户登陆，加入session会话中,
        Cookie[] cookies = req.getCookies();
        HttpSession session = req.getSession(true);
        String cookieValue = Common.isContained(cookies, "logined");
        if (!Strings.isNullOrEmpty(cookieValue) && session.getAttribute("userName") == null) {
            session.setAttribute("userName",cookieValue);
        }

        if (Strings.isNullOrEmpty(cookieValue)) {
            cookieValue = "游客";
        }

        //写入数据库
        PageService pageService = new PageServiceImpl();
        pageService.setPage(cookieValue,requestPage);

    }
}
