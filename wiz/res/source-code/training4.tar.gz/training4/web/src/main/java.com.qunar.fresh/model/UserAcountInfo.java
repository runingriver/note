package model;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;

import java.util.Date;

/**
 * 对应数据库的user_account表
 */
public class UserAcountInfo{
    private String userId;
    private String userName;
    private String userPassword;
    private double money;
    private Date updateTime;
    private int role;
    private int status;

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

/*   看看要不要用建造者模式
        public static class Builder{
        private Integer userId;
        private String userName;
        private String userPassword;
        private double money;
        private Date updateTime;
        private int role;
        private int status;

    }*/



    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof UserAcountInfo))
            return false;

        UserAcountInfo user = (UserAcountInfo) o;

        if (userId != user.userId)
            return false;
        if (userName != null ? !userName.equals(user.userName) : user.userName != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(userId, userName, money, updateTime, role, status);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).add("user_id",userId)
                .add("user_name",userName)
                .add("money",money)
                .add("update time",updateTime)
                .add("role",role)
                .add("status",status).toString();
    }
}
