package service.impl;


import dao.PageDao;
import dao.impl.PageDaoImpl;
import model.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import service.PageService;

import java.sql.SQLException;

public class PageServiceImpl implements PageService{
    public static final Logger log = LoggerFactory.getLogger(PageServiceImpl.class);

    @Override
    public boolean setPage(String userName, String userPage) {
        PageInfo info = null;
        PageDao pageDao = new PageDaoImpl();
        try {
            info = pageDao.queryByPageAndUser(userName,userPage);
            if (info != null) {
                int count = info.getPageCount() + 1;
                info.setPageCount(count);
                pageDao.savePage(info);
            }

            info = new PageInfo();
            info.setPageName(userPage);
            info.setUserName(userName);
            info.setPageCount(1);
            pageDao.savePage(info);
        } catch (SQLException e) {
            log.error("query error", e);
            return false;
        }

        return true;
    }
}
