package controller;

import com.google.common.base.Strings;
import dao.UserAccountDao;
import dao.impl.UserAccountDaoImpl;
import model.UserAcountInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "LoginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    public static final Logger log = LoggerFactory.getLogger(LoginServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        HttpSession session = req.getSession(true);

        UserAcountInfo user = checkLogin(req, resp);
        //设置cookie和session
        Cookie userCookie = new Cookie("logined", user.getUserName());
        userCookie.setMaxAge(60 * 60 * 24);
        resp.addCookie(userCookie);
        session.setAttribute("userName", user.getUserName());

        req.getRequestDispatcher("/pages/succeed.jsp").forward(req, resp);
    }

    private UserAcountInfo checkLogin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userNameOrId = req.getParameter("userNameOrId");
        String password = req.getParameter("userPassword");
        UserAccountDao userDao = new UserAccountDaoImpl();
        UserAcountInfo user = null;
        try {
            user = userDao.queryById(userNameOrId);
            if (user == null) {
                user = userDao.queryByUserName(userNameOrId);
            }
            if (user == null) {
                req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
            }
        } catch (SQLException e) {
            log.error("login failed.", e);
        }

        if (!Strings.isNullOrEmpty(user.getUserPassword()) && !password.equals(user.getUserPassword())) {
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        } else {
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        }
        return user;
    }
}
