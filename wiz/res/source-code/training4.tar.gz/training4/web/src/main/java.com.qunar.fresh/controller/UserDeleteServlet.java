package controller;

import dao.UserAccountDao;
import dao.impl.UserAccountDaoImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "UserDeleteServlet",urlPatterns = "/userdelete")
public class UserDeleteServlet extends HttpServlet {
    public static final Logger log = LoggerFactory.getLogger(UserDeleteServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        //检查用户是否登陆
        HttpSession session = req.getSession(true);
        if (null == session.getAttribute("userName")) {
            req.getRequestDispatcher("/pages/login.jsp").forward(req, resp);
        }

        //删除用户
        UserAccountDao userDao = new UserAccountDaoImpl();
        String queryString = req.getQueryString();
        String userId = queryString.substring(queryString.indexOf('=') + 1);
        int result = -1;
        try {
            result = userDao.deleteUserByUserId(userId);
        } catch (SQLException e) {
            log.error("query queryById exception.", e);
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        }
        if (result < 1) {
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        }
        req.getRequestDispatcher("/users").forward(req, resp);
    }
}
