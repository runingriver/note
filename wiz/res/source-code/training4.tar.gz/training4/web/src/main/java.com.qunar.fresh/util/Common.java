package util;


import javax.servlet.http.Cookie;

public class Common {
    public static String isContained(Cookie[] cookies,String name) {
        String cookieName = null;
        String cookievalue = null;

        if (cookies!= null && cookies.length > 0) {
            for (Cookie c : cookies) {
                cookieName = c.getName();
                if (cookieName.equals(name)) {
                    cookievalue = c.getValue();
                    return cookievalue;
                }
            }
        }
        return cookievalue;
    }
}
