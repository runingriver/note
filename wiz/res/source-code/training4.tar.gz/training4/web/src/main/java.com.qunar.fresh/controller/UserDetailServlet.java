package controller;

import dao.UserAccountDao;
import dao.impl.UserAccountDaoImpl;
import model.UserAcountInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "UserDetailServlet", urlPatterns = "/userdetail")
public class UserDetailServlet extends HttpServlet {
    public static final Logger log = LoggerFactory.getLogger(UserManagerServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        //检查用户是否登陆
        HttpSession session = req.getSession();
        if (session.getAttribute("userName") == null) {
            req.getRequestDispatcher("/pages/login.jsp").forward(req, resp);
        }

        //获取用信息
        UserAccountDao userDao = new UserAccountDaoImpl();
        UserAcountInfo user = null;
        String queryString = req.getQueryString();
        String userId = queryString.substring(queryString.indexOf('=') + 1);
        try {
            user = userDao.queryById(userId);
        } catch (SQLException e) {
            log.error("query queryById exception.", e);
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
        }
        req.setAttribute("user", user);
        req.getRequestDispatcher("/pages/userdetail.jsp").forward(req, resp);
    }
}
