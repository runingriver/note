package dao.impl;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import dao.UserAccountDao;
import model.UserAcountInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import util.DBUtil;

import java.sql.*;
import java.util.List;

/**
 * 用户账号相关操作实现
 */
public class UserAccountDaoImpl implements UserAccountDao {
    public static final Logger log = LoggerFactory.getLogger(UserAccountDaoImpl.class);

    public UserAcountInfo queryById(String userId) throws SQLException {
        if (Strings.isNullOrEmpty(userId)) {
            log.info("user name is null, in the queryById.");
            return null;
        }
        String sql = "SELECT user_id,user_name,user_password,money,update_time,role,status FROM user_account where user_id =?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try{
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,userId);
            resultSet = preparedStatement.executeQuery();
        }finally {
            DBUtil.closeConnection(connection,null,resultSet);
        }

        return getQueryResult(resultSet);
    }

    private UserAcountInfo getQueryResult(ResultSet resultSet) throws SQLException {
        UserAcountInfo userAcountInfo = null;
        while (resultSet.next()) {
            userAcountInfo = new UserAcountInfo();
            userAcountInfo.setUserId(resultSet.getString("user_id"));
            userAcountInfo.setUserName(resultSet.getString("user_name"));
            userAcountInfo.setUserPassword(resultSet.getString("user_password"));
            userAcountInfo.setMoney(resultSet.getDouble("money"));
            userAcountInfo.setUpdateTime(resultSet.getTime("update_time"));
            userAcountInfo.setRole(resultSet.getInt("role"));
            userAcountInfo.setStatus(resultSet.getInt("status"));
        }
        return userAcountInfo;
    }

    public UserAcountInfo queryByUserName(String userName) throws SQLException {
        if (Strings.isNullOrEmpty(userName)) {
            log.info("user name is null, in the queryByUserName.");
            return null;
        }
        String sql = "SELECT user_id,user_name,user_password,money,update_time,role,status FROM user_account WHERE user_name =?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,userName);
            resultSet = preparedStatement.executeQuery();
        }finally {
            DBUtil.closeConnection(connection,preparedStatement,resultSet);
        }

        return getQueryResult(resultSet);
    }

    public List<UserAcountInfo> queryAllUser(int n) throws SQLException{
        if (n<1) {
            log.info("the parameter of n is error, in the queryAllUser.");
            return null;
        }
        String sql = "SELECT user_id,user_name,money,update_time FROM user_account WHERE status > 0";
        Connection connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            /*preparedStatement.setInt(1,n);*/
            resultSet = preparedStatement.executeQuery();
        }finally {
            DBUtil.closeConnection(connection,preparedStatement,resultSet);
        }

        return getQueryList(resultSet);
    }

    private List<UserAcountInfo> getQueryList(ResultSet resultSet) throws SQLException  {
        List<UserAcountInfo> userList = Lists.newArrayList();
        UserAcountInfo userAcountInfo = null;
        while (resultSet.next()) {
            userAcountInfo = new UserAcountInfo();
            userAcountInfo.setUserId(resultSet.getString("user_id"));
            userAcountInfo.setUserName(resultSet.getString("user_name"));
            userAcountInfo.setMoney(resultSet.getDouble("money"));
            userAcountInfo.setUpdateTime(resultSet.getTime("update_time"));
            userList.add(userAcountInfo);
        }
        return userList;
    }


    public int save(UserAcountInfo userAcountInfo) throws SQLException {
        if (userAcountInfo == null) {
            return 0;
        }
        String sql = "INSERT INTO user_account(user_id,user_name,user_password,money,update_time,role,status) " +
                "Values(?,?,?,?,?,?,?)";
        Connection connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        int result = -1;
        try {
            preparedStatement = connection.prepareStatement(sql);
            //index start with 1
            preparedStatement.setString(1,userAcountInfo.getUserId());
            preparedStatement.setString(2,userAcountInfo.getUserName());
            preparedStatement.setString(3,userAcountInfo.getUserPassword());
            preparedStatement.setDouble(4,userAcountInfo.getMoney());
            preparedStatement.setTimestamp(5,new Timestamp(userAcountInfo.getUpdateTime().getTime()));
            preparedStatement.setInt(6,userAcountInfo.getRole());
            preparedStatement.setInt(7,userAcountInfo.getStatus());

            result = preparedStatement.executeUpdate();
        }finally {
            DBUtil.closeConnection(connection,preparedStatement);
        }

        return result;
    }


    public int update(UserAcountInfo userAcountInfo, Connection connection) throws SQLException {
        if (userAcountInfo == null) {
            return 0;
        }
        String sql = "UPDATE user_account set " +
                "user_name = ?, user_password = ?,money=?,update_time = ?,role = ?,status=? WHERE user_id=?";
        connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        int result = -1;
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,userAcountInfo.getUserName());
            preparedStatement.setString(2,userAcountInfo.getUserPassword());
            preparedStatement.setDouble(3,userAcountInfo.getMoney());
            preparedStatement.setTimestamp(4,new Timestamp(userAcountInfo.getUpdateTime().getTime()));
            preparedStatement.setInt(5,userAcountInfo.getRole());
            preparedStatement.setInt(6,userAcountInfo.getStatus());
            preparedStatement.setString(7,userAcountInfo.getUserId());

            result = preparedStatement.executeUpdate();
        }finally {
            DBUtil.closeConnection(connection,preparedStatement);
        }
        return result;
    }

    public int update(UserAcountInfo userAcountInfo) throws SQLException {
        Connection connection = DBUtil.getConnection();
        return update(userAcountInfo, connection);
    }

    public int updateUserNameAndPassword(String userId,String username,String password) throws SQLException {
        if (Strings.isNullOrEmpty(username)
                || Strings.isNullOrEmpty(password)
                ||Strings.isNullOrEmpty(userId) ) {
            return 0;
        }
        Connection connection = DBUtil.getConnection();
        String sql = "UPDATE user_account set user_name = ?, user_password = ? WHERE user_id=?";
        connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        int result = -1;
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,password);
            preparedStatement.setString(3,userId);
            result = preparedStatement.executeUpdate();
        }finally {
            DBUtil.closeConnection(connection,preparedStatement);
        }
        return result;
    }

    @Override
    public int deleteUserByUserId(String userid) throws SQLException {
        if (Strings.isNullOrEmpty(userid)) {
            return 0;
        }
        Connection connection = DBUtil.getConnection();
        String sql = "UPDATE user_account set status = 0 WHERE user_id=?";
        connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        int result = -1;
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,userid);
            result = preparedStatement.executeUpdate();
        }finally {
            DBUtil.closeConnection(connection,preparedStatement);
        }
        return result;
    }
}
