package service;

/**
 * Created by zongzhehu on 16-8-3.
 */
public interface UserAccountService {
    boolean transfer(String sourceID, String targetId, double money);
}
