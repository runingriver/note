package model;


import com.google.common.base.MoreObjects;

public class PageInfo {
    private String pageName;
    private String userName;
    private int pageCount;

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).add("page_name",pageName)
                .add("user_name",userName)
                .add("pageCount", pageCount).toString();
    }
}
