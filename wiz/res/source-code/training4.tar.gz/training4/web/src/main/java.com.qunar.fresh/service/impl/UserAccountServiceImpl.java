package service.impl;

import com.google.common.primitives.Doubles;
import dao.UserAccountDao;
import dao.impl.UserAccountDaoImpl;
import model.UserAcountInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import service.UserAccountService;
import util.DBUtil;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Created by zongzhehu on 16-8-3.
 */
public class UserAccountServiceImpl implements UserAccountService {
    public static final Logger log = LoggerFactory.getLogger(UserAccountServiceImpl.class);

    public boolean transfer(String sourceID, String targetId, double money) {
        //1.查询A的余额；2.A余额_100;3.B查余额;4B余额+100
        UserAccountDao dao = new UserAccountDaoImpl();
        Connection connection = DBUtil.getConnection();
        try {
            connection.setAutoCommit(false);
        } catch (SQLException e) {
            log.error("set auto commit exception",e);
        }

        try {
            UserAcountInfo userAcountInfoSource = dao.queryById(sourceID);
            //钱不够
            if (Doubles.compare(userAcountInfoSource.getMoney(), money) < 0) {
                return false;
            }
            userAcountInfoSource.setMoney(userAcountInfoSource.getMoney()-money);
            int updateCount = dao.update(userAcountInfoSource,connection);
            if (0 == updateCount) {
                log.error("transfor money fails.");
                return false;
            }
            UserAcountInfo userAcountInfoTarget = dao.queryById(targetId);

            userAcountInfoTarget.setMoney(userAcountInfoTarget.getMoney() + money);
            int updateCountTarget = dao.update(userAcountInfoTarget,connection);
            connection.commit();
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException e1) {
                log.error("rollback exception.");
            }
            log.error("query exception.",e);
            return false;
        }finally {
            DBUtil.closeConnection(connection);
        }
        return true;
    }
}
