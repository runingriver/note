package controller;

import com.google.common.base.Strings;
import dao.UserAccountDao;
import dao.impl.UserAccountDaoImpl;
import model.UserAcountInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "UserModifyServlet",urlPatterns = "/usermodify")
public class UserModifyServlet extends HttpServlet{
    public static final Logger log = LoggerFactory.getLogger(UserModifyServlet.class);
    private static UserAcountInfo user;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        UserAccountDao userDao = new UserAccountDaoImpl();
        user = null;
        String queryString = req.getQueryString();
        String userId = queryString.substring(queryString.indexOf('=') + 1);
        try {
            user = userDao.queryById(userId);
        } catch (SQLException e) {
            log.error("query queryById exception.", e);
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
        }
        req.setAttribute("user", user);
        req.getRequestDispatcher("/pages/usermodify.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");

        //检查用户是否登陆
        HttpSession session = req.getSession();
        if (null == session.getAttribute("userName")) {
            req.getRequestDispatcher("/pages/login.jsp").forward(req, resp);
        }

        //检查修改，并写入数据库
        setModify(req, resp);

        req.getRequestDispatcher("/pages/succeed.jsp").forward(req, resp);
    }

    private void setModify(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        //写入修改到数据库
        if (user == null) {
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        }
        UserAccountDao userDao = new UserAccountDaoImpl();

        //首先检查旧密码是否输入正确
        try {
            UserAcountInfo olduser = userDao.queryById(req.getParameter("userId"));
            String sourcePwd = olduser.getUserPassword();
            String oldPwd = req.getParameter("oldPassword").trim();
            if (olduser == null || !sourcePwd.equals(oldPwd)) {
                req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
            }
        } catch (SQLException e) {
            log.error("query topN exception.",e);
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
        }

        //正确！写入数据库
        String userId = req.getParameter("userId");
        String userName = req.getParameter("userName");
        String userPassword = req.getParameter("userPassword");
        //参数检查
        if (Strings.isNullOrEmpty(userId)
                && Strings.isNullOrEmpty(userName)
                && Strings.isNullOrEmpty(userPassword)) {
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        }

        try {
            userDao.updateUserNameAndPassword(userId,userName, userPassword);
        } catch (SQLException e) {
            log.error("update user in database exception", e);
            req.getRequestDispatcher("/pages/failed.jsp").forward(req, resp);
        }
    }
}
