#建立数据库
DROP DATABASE IF EXISTS web_test;
CREATE DATABASE web_test;
ALTER DATABASE web_test DEFAULT CHARACTER SET utf8mb4;
SHOW DATABASES ;

#建立用户表
USE web_test;
DROP TABLE IF EXISTS user_account;
CREATE TABLE user_account(
  id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
  user_id VARCHAR(20) NOT NULL DEFAULT '' COMMENT '用户id',
  user_name VARCHAR(20) NOT NULL DEFAULT '' COMMENT '用户名',
  user_password VARCHAR(30) NOT NULL DEFAULT '' COMMENT '用户密码',
  money DECIMAL(11,2) NOT NULL DEFAULT 0.00 COMMENT '钱',
  update_time DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '更新时间',
  role TINYINT NOT NULL DEFAULT 1 COMMENT '用户角色:1普通，2管理员，3超级管理员',
  status TINYINT NOT NULL DEFAULT 1 COMMENT '用户状态：1.活跃，2.已删除',
  PRIMARY KEY (id)
)ENGINE = InnoDB DEFAULT CHARSET =utf8mb4 COMMENT '用户表';

#向用户表中插入初始数据
INSERT INTO user_account(user_id, user_name, user_password, money, update_time, role, status) VALUES
  ('111002','hzz',123,34.34,'2016-08-03 10:12:12',3,1),
  ('111003','abc',123,34.34,'2016-08-03 10:12:12',2,1),
  ('111004','def',123,34.34,'2016-08-03 10:12:12',1,1),
  ('111005','ghi',123,34.34,'2016-08-03 10:12:12',1,1);

  DROP TABLE IF EXISTS pages;
  CREATE TABLE pages (
  id int(11) NOT NULL AUTO_INCREMENT,
  page_name varchar(50) NOT NULL DEFAULT '',
  user_name varchar(20) NOT NULL DEFAULT '',
  pageCount int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

