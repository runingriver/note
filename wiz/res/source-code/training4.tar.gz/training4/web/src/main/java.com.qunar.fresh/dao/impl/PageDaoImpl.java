package dao.impl;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import dao.PageDao;
import model.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class PageDaoImpl implements PageDao {
    public static final Logger log = LoggerFactory.getLogger(PageDaoImpl.class);

    @Override
    public List<PageInfo> queryByUserName(String userName) throws SQLException {
        if (Strings.isNullOrEmpty(userName)) {
            log.info("user name is null, in the queryByUserName.");
            return null;
        }
        String sql = "SELECT page_name,user_name,page_count FROM pages WHERE user_name =?";
        return queryByName(sql, userName);
    }

    @Override
    public List<PageInfo> queryByPageName(String pageName) throws SQLException {
        if (Strings.isNullOrEmpty(pageName)) {
            log.info("user name is null, in the queryByUserName.");
            return null;
        }
        String sql = "SELECT page_name,user_name,page_count FROM pages WHERE page_name =?";
        return queryByName(sql, pageName);
    }

    private List<PageInfo> queryByName(String sql,String name)  throws SQLException{
        Connection connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            if (!Strings.isNullOrEmpty(name)) {
                preparedStatement.setString(1,name);
            }
            resultSet = preparedStatement.executeQuery();
            if (resultSet == null) {
                return null;
            }
        }finally {
            DBUtil.closeConnection(connection,preparedStatement,resultSet);
        }

        List<PageInfo> pageList = Lists.newArrayList();
        PageInfo pageInfo = null;
        while (resultSet.next()) {
            pageInfo = new PageInfo();
            pageInfo.setPageName(resultSet.getString("page_name"));
            pageInfo.setUserName(resultSet.getString("user_name"));
            pageInfo.setPageCount(resultSet.getInt("page_count"));
            pageList.add(pageInfo);
        }
        return pageList;
    }

    @Override
    public List<PageInfo> queryAll() throws SQLException {
        String sql = "SELECT page_name,user_name,page_count FROM pages";
        return queryByName(sql, null);
    }

    @Override
    public PageInfo queryByPageAndUser(String userName, String pageName) throws SQLException {
        if (Strings.isNullOrEmpty(pageName)&&Strings.isNullOrEmpty(pageName)) {
            log.info("pageName or pageName is null, in the queryByPageAndUser.");
            return null;
        }
        String sql = "SELECT page_name,user_name,page_count FROM pages WHERE page_name =? AND user_name = ?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,pageName);
            preparedStatement.setString(2,userName);
            resultSet = preparedStatement.executeQuery();
            if (resultSet == null) {
                return null;
            }
        }finally {
            DBUtil.closeConnection(connection,preparedStatement,resultSet);
        }

        PageInfo pageInfo = null;
        while (resultSet.next()) {
            pageInfo = new PageInfo();
            pageInfo.setPageName(resultSet.getString("page_name"));
            pageInfo.setUserName(resultSet.getString("user_name"));
            pageInfo.setPageCount(resultSet.getInt("page_count"));
        }
        return pageInfo;
    }

    @Override
    public int savePage(PageInfo pageInfo) throws SQLException {
        if (pageInfo == null) {
            return 0;
        }
        String sql = "INSERT INTO pages(page_name,user_name,page_count) Values(?,?,?)";
        Connection connection = DBUtil.getConnection();
        PreparedStatement preparedStatement = null;
        int result = -1;
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,pageInfo.getPageName());
            preparedStatement.setString(2,pageInfo.getUserName());
            preparedStatement.setInt(3,pageInfo.getPageCount());
            result = preparedStatement.executeUpdate();
        }finally {
            DBUtil.closeConnection(connection,preparedStatement);
        }
        return result;
    }
}
