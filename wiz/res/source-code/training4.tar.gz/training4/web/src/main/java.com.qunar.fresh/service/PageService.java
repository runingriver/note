package service;


public interface PageService {
    boolean setPage(String userName, String userPage);
}
