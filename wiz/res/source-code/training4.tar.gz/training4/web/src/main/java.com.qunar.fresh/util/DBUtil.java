package util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;

/**
 * Created by zongzhehu on 16-8-2.
 */
public class DBUtil {
    public static final Logger log = LoggerFactory.getLogger(DBUtil.class);
    private static String DRIVER_NAME;
    private static String URL;
    private static String USER_NAME;
    private static String PASSWORD;

    private static Properties properties = new Properties();

    static {
        try {
            properties.load(DBUtil.class.getResourceAsStream("/jdbc.properties"));
        } catch (IOException e) {
            log.error("load the jdbc.properties exception.", e);
            System.exit(1);
        }
        DRIVER_NAME = properties.getProperty("jdbc.driver");
        URL = properties.getProperty("jdbc.url");
        USER_NAME = properties.getProperty("jdbc.username");
        PASSWORD = properties.getProperty("jdbc.password");

        try {
            Class.forName(DRIVER_NAME);
        } catch (ClassNotFoundException e) {
            log.error("load mysql jdbc driver exception", e);
            System.exit(1);
        }
    }

    public static Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
        } catch (SQLException e) {
            log.error("create database connection exception.", e);
            System.exit(1);
        }
        return con;
    }




    /**
     * 关闭连接，顺序
     */
    public static void closeConnection(Connection connection, Statement statement, ResultSet resultSet) {
        try {
            if (resultSet != null && resultSet.isClosed()) {
                resultSet.close();
            }
        } catch (SQLException e) {
            log.error("close resultSet error.", e);
        }

        try {
            if (statement != null && statement.isClosed()) {
                statement.close();
            }
        } catch (SQLException e) {
            log.error("close statement error.", e);
        }

        try {
            if (connection != null && connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            log.error("close connection error.", e);
        }
    }

    public static void closeConnection(Connection connection) {
        closeConnection(connection,null,null);
    }

    public static void closeConnection(Connection connection, Statement statement) {
        closeConnection(connection,statement,null);
    }

}
