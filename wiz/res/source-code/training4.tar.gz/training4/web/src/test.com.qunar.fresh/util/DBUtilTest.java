package util;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;

import static org.junit.Assert.*;

/**
 * Created by zongzhehu on 16-8-2.
 */
public class DBUtilTest {
    public static final Logger log = LoggerFactory.getLogger(DBUtilTest.class);
    @Test
    public void getConnection() throws Exception {
        Connection connection = DBUtil.getConnection();
        log.info(connection.toString());
    }

    @Test
    public void testDouble() {
        Double money = null;
        double m = money==null ? 0.00 : money;
        log.debug("{}",m);
    }


}