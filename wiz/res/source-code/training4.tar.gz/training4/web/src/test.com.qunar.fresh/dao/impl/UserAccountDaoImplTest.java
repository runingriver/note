package dao.impl;

import model.UserAcountInfo;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

import static org.junit.Assert.*;

/**
 * 测试
 */
public class UserAccountDaoImplTest {
    @Test
    public void update() throws Exception {
        UserAccountDaoImpl userAccountDao = new UserAccountDaoImpl();
        UserAcountInfo userAcountInfo = new UserAcountInfo();

        userAcountInfo.setUserId("111006");
        userAcountInfo.setUserName("KLM-NNN");
        userAcountInfo.setUserPassword("123");
        userAcountInfo.setMoney(333.44D);
        userAcountInfo.setUpdateTime(new Date());

        int saveCount = userAccountDao.update(userAcountInfo);

        log.debug(String.valueOf(saveCount));
    }

    public static final Logger log = LoggerFactory.getLogger(UserAccountDaoImplTest.class);

    @Test
    public void save() throws Exception {
        UserAccountDaoImpl userAccountDao = new UserAccountDaoImpl();
        UserAcountInfo userAcountInfo = new UserAcountInfo();

        userAcountInfo.setUserId("111006");
        userAcountInfo.setUserName("KLM");
        userAcountInfo.setMoney(222.33D);
        userAcountInfo.setUpdateTime(new Date());

        int saveCount = userAccountDao.save(userAcountInfo);

        log.debug(String.valueOf(saveCount));
    }



    @Test
    public void queryByUserName() throws Exception {
        UserAccountDaoImpl userAccountDao = new UserAccountDaoImpl();
        UserAcountInfo userAcountInfo = userAccountDao.queryByUserName("hzz");
        log.debug(userAcountInfo.toString());
    }


    @Test
    public void queryById() throws Exception {
        UserAccountDaoImpl userAccountDao = new UserAccountDaoImpl();
        UserAcountInfo userAcountInfo = userAccountDao.queryById("111002");
        log.debug(userAcountInfo.toString());
    }

}