package service.impl;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import service.UserAccountService;

import static org.junit.Assert.*;

/**
 * Created by zongzhehu on 16-8-3.
 */
public class UserAccountServiceImplTest {
    @Test
    public void transfer() throws Exception {
        UserAccountServiceImpl userAccountService = new UserAccountServiceImpl();
        boolean transfer = userAccountService.transfer("111003", "111002", 30.00d);
        log.debug("successed:{}",transfer);
    }

    public static final Logger log = LoggerFactory.getLogger(UserAccountServiceImplTest.class);
}