package com.qunar.fresh.study;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by zongzhehu on 16-7-15.
 */
public class PersonDao {
    public static final Logger log = LoggerFactory.getLogger(PersonDao.class);
    public void checkNickname(List<String> nicks, String nickname) {
        if (!nicks.contains(nickname)) {
            nicks.add(nickname);
        }
        log.info("metod running over!");
    }
}
