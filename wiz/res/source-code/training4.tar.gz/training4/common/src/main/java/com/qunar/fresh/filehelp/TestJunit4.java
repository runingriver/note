package com.qunar.fresh.filehelp;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestJunit4 {
    public final static Logger log = LoggerFactory.getLogger(TestJunit4.class);

    public static String hello(Integer i, String s) {
        for (int j =0;j<i;j++) {
            s+=i;
        }
        return s;
    }

    public int count(int a) {
        int s =10;
        for (int i = 10;i<a;i++) {
            s+=i;
        }
        return s;
    }


}
