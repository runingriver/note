package com.qunar.fresh.filehelp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.rmi.runtime.Log;

import java.util.List;

/**
 * Created by zongzhehu on 16-7-14.
 */
public class NumberHandler {
    public static final Logger log = LoggerFactory.getLogger(NumberHandler.class);

    //10+12
    public int countMoney(int a) {
        TestJunit4 t = new TestJunit4();

        int b = t.count(a);
        //do.....

        int sum = b;

        return sum;
    }
}
