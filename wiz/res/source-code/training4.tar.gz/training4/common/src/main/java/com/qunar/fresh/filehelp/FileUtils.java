package com.qunar.fresh.filehelp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 文件操作，通用类
 */
public class FileUtils {
    /*private static final Logger log = LoggerFactory.getLogger(FileUtils.class);


    public static Boolean writeToFile(List<String> content, String path) {
        File file = new File(path);
        if (!isFile(file)) {
            return false;
        }
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(file);
            for (int i=0,n= content.size();i<n;i++) {
                pw.println(content.get(i));
            }
            pw.flush();
            pw.close();
        } catch (FileNotFoundException e) {
            log.info("cannot find the file:"+e.getMessage());
            return false;
        }
        return true;
    }

    *//**
     * 将文件按行的方式读取到集合中
     *//*
    public static List<String> readFormFile(String path) throws IOException {
        File file = new File(path);
        if (!isFile(file)) {
            throw new IOException("file path error");
        }
        BufferedReader in = null;
        String buffer = null;
        List<String> content = new ArrayList<String>();
        try {
            in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            //遍历文件，获取相应信息
            while ((buffer = in.readLine()) != null) {
                content.add(buffer);
            }
        } catch (FileNotFoundException e) {
            log.info("file not found:" + e.getMessage());
        } catch (IOException e) {
            log.info("file read error:" + e.getMessage());
        } finally {
            try {if (in != null) in.close();}
                catch (IOException e) {log.warn("BufferedReader close failed");}
        }
        return content;
    }

    *//**
     *  检查给定文件是否是文件，如果不存在就创建一个
     *//*
    private static Boolean isFile(File file) {
        if (file.isDirectory()) {
            return false;
        }
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                log.info("cannot create a new file");
                return false;
            }
        }
        return true;
    }
*/
}
