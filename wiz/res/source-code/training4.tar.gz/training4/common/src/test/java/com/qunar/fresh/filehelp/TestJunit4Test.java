package com.qunar.fresh.filehelp; 

import org.junit.Assert;
import org.junit.Test;
import org.junit.Before; 
import org.junit.After; 

public class TestJunit4Test { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 


@Test
public void testHello() throws Exception {
    String rst = "a";
    int i=5;
    Assert.assertEquals("a55555",TestJunit4.hello(i,rst));
} 


@Test
public void testCount() throws Exception {
    TestJunit4 t = new TestJunit4();
    t.count(15);
} 


} 
