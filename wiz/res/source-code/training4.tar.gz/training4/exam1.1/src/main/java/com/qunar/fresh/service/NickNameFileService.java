package com.qunar.fresh.service;

import com.qunar.fresh.exam1.service.fileservice.AbstractFileService;

import java.io.*;
import java.util.List;
import java.util.Map;

/**
 * 将昵称按需求输出到文件
 * 这看做是一个新的文件操作需求
 */
public class NickNameFileService extends AbstractFileService<Map.Entry<String, List<String>>> {

    public Boolean writeToFile(List<Map.Entry<String, List<String>>> content, String path) {
        File file = new File(path);
        if (!isFile(file)) {
            return false;
        }
        PrintWriter pw = null;
        StringBuilder formatString = null;
        StringBuilder nickString = null;
        try {
            pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file),"UTF-8"));
            for (int i=0,n= content.size();i<n;i++) {
                nickString = new StringBuilder();
                nickString.append(content.get(i).getValue().get(0));
                for (int j =1,m = content.get(i).getValue().size();j<m;j++) {
                    nickString.append(',').append(content.get(i).getValue().get(j));
                }
                formatString = new StringBuilder();
                formatString.append(content.get(i).getKey()).append(':').append(nickString);
                pw.println(formatString.toString());
            }
            pw.flush();
        } catch (FileNotFoundException e) {
            log.error("cannot find the file:"+e.getMessage());
            return false;
        } catch (UnsupportedEncodingException e) {
            log.error("encoding error:"+e.getMessage());
            return false;
        }finally {
            if (pw != null) {
                pw.close();
            }
        }
        return true;
    }
}
