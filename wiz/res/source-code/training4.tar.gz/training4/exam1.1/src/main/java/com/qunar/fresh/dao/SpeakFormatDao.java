package com.qunar.fresh.dao;

import com.qunar.fresh.exam1.dao.SpeakDao;
import com.qunar.fresh.exam1.entity.Speak;
import com.qunar.fresh.exam1.main.Exam1Entry;
import com.qunar.fresh.exam1.service.fileservice.SpeakFileService;
import com.qunar.fresh.exam1.service.sortservice.SpeakSortService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * 格式化输出，重用exam1中的service方法,SpeakDao类的多个方法
 * 组合模式，重用SpeakDao，及其相关方法。
 */
public class SpeakFormatDao {
    private static final Logger log = LoggerFactory.getLogger(SpeakFormatDao.class);
    private SpeakDao speakDao;  //组合

    public SpeakFormatDao() {
        speakDao = new SpeakDao();
    }

    /**
     * 根据要求的格式输出，聊天记录
     */
    public List<Speak> getSpeaks() {
        String path = speakDao.getPath(Exam1Entry.READ_FILE_CHAT);

        //获取到所有的聊天内容
        List<String> content = new SpeakFileService().readFormFile(path);
        //将内容读取成对象
        List<Speak> speaks = speakDao.objectPacking(content);
        //对象排序
        new SpeakSortService().sort(speaks);

        return speaks;
    }


    public String getOutputPath(String filename) {
        return speakDao.getOutputPath(filename);
    }

    public List<Speak> formatNickname(List<Speak> speaks) {
        //用一个HashMap记住最后使用的昵称,key-工号，value-昵称
        HashMap<String, String> lastUsedNickname = new HashMap<String, String>();
        String key = null;
        for (int i=speaks.size()-1;i>=0;i--) {
            key = speaks.get(i).getJobNumber();
            if (lastUsedNickname.containsKey(key)) {
                speaks.get(i).setNickname(lastUsedNickname.get(key));
            } else {
                lastUsedNickname.put(key, speaks.get(i).getNickname());
            }
        }
        return speaks;
    }

    /**
     * 获取使用过的昵称
     * @param speaks 已按时间顺序排好
     */
    public HashMap<String, List<String>> getUsedNickname(List<Speak> speaks) {
        //用一个HashMap记住最后使用的昵称,key-工号，value-昵称
        HashMap<String, List<String>> nicknameMap = new HashMap<String, List<String>>();
        String key = null;
        String nickname = null;
        for (int i=0,n=speaks.size();i<n;i++) {
            key = speaks.get(i).getJobNumber();
            nickname =speaks.get(i).getNickname();
            if (nicknameMap.containsKey(key)) {
                //检查该工号下是否有该nick，没有加到list中
                if (!nicknameMap.get(key).contains(nickname)) {
                    nicknameMap.get(key).add(nickname);
                }
            } else {
                List<String> nickList = new ArrayList<String>();
                nickList.add(nickname);
                nicknameMap.put(key, nickList);
            }
        }
        return nicknameMap;
    }
}
