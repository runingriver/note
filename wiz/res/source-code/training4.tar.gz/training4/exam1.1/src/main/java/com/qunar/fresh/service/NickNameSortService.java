package com.qunar.fresh.service;

import com.qunar.fresh.exam1.service.sortservice.ISortService;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * 对昵称排序，根据工号排
 */
public class NickNameSortService implements ISortService<Map.Entry<String, List<String>>> {
    public void sort(List list) {
        Collections.sort(list, new Comparator<Map.Entry<String, List<String>>>() {
            public int compare(Map.Entry<String, List<String>> o1, Map.Entry<String, List<String>> o2) {
                return Long.valueOf(o1.getKey()).compareTo(Long.valueOf(o2.getKey()));
            }
        });
    }
}
