package com.qunar.fresh.main;


import com.qunar.fresh.dao.SpeakFormatDao;
import com.qunar.fresh.exam1.entity.Speak;
import com.qunar.fresh.exam1.main.Exam1Entry;
import com.qunar.fresh.exam1.service.fileservice.SpeakFileService;
import com.qunar.fresh.service.NickNameFileService;
import com.qunar.fresh.service.NickNameSortService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 具体需求逻辑
 */
public class Exam11Entry {
    public static final Logger log = LoggerFactory.getLogger(Exam1Entry.class);
    private static final String OUTPUT_FILE_CHAT_FORMAT = "chat_format_sorted.txt";
    private static final String READ_FILE_CHAT = "chat.txt";
    private static final String OUTPUT_FILE_NICKNAME = "nickname.txt";

    public static void main(String[] args) {
        SpeakFormatDao speakFormatDao = new SpeakFormatDao();


        List<Speak> speaks = speakFormatDao.getSpeaks();

        //2. 昵称输出(看做新需求）,先处理，因为后面会修改speaks集合中的NickName
        HashMap<String, List<String>> nicks = speakFormatDao.getUsedNickname(speaks);
        List<Map.Entry<String, List<String>>> list = new ArrayList<Map.Entry<String, List<String>>>(nicks.entrySet());

        //排序
        new NickNameSortService().sort(list);

        //输出到文件nickname.txt
        if (!new NickNameFileService().writeToFile(list, speakFormatDao.getOutputPath(OUTPUT_FILE_NICKNAME))) {
            log.error("output count.txt failed.");
        }


        //修改已排序中的内容
        List<Speak> formatSpeaks = speakFormatDao.formatNickname(speaks);

        //1.输出到文件chat_sorted.txt
        if (!new SpeakFileService().writeToFile(formatSpeaks, speakFormatDao.getOutputPath(OUTPUT_FILE_CHAT_FORMAT))) {
            log.info("output char_format_soted.txt failed.");
        }
        log.info("finished exam1.1");
    }
}
