/**
 * $Id$
 * <p>
 * Copyright (c) 2012 Qunar.com. All Rights Reserved.
 */
package controller;

import com.google.common.collect.Maps;
import common.JsonFormattedOutput;
import model.Requests;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

public class RequestServlet extends HttpServlet {
	private static final Logger LOGGER = LoggerFactory.getLogger(RequestServlet.class);


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		//获取并设置请求参数
		Requests requestsInfo =getRequestInfo(request, response);
		//设置cookie
		Cookie cookie = new Cookie("hzzCookie", "hello world cookie.");
		cookie.setMaxAge(60*60*24);
		response.addCookie(cookie);
		//输出解析结果
		response.getWriter().write(JsonFormattedOutput.parseToJson(requestsInfo));
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	private static Requests getRequestInfo(HttpServletRequest request, HttpServletResponse response) {
		//获取并设置参数
		Requests requestsInfo = new Requests();
		requestsInfo.setProtocal(request.getProtocol());
		requestsInfo.setPort(request.getServerPort());
		requestsInfo.setHost(request.getRemoteHost());
		requestsInfo.setUrl(request.getRequestURL().toString());
		requestsInfo.setStatus(0);
		requestsInfo.setVersion(1);
		requestsInfo.setMessage("");
		//设置cookie
		Map<String, String> cookieMap = null;
		Cookie[] cookies = request.getCookies();
		if (cookies != null && cookies.length > 0) {
			cookieMap = Maps.newHashMap();
			for (Cookie c : cookies) {
				cookieMap.put(c.getName(), c.getValue());
			}
		}
		requestsInfo.setCookies(cookieMap);

		//设置请求参数
		Map<String, String[]> requParamMap = request.getParameterMap();
		requestsInfo.setRequestParam(requParamMap);

		return requestsInfo;
	}


}
