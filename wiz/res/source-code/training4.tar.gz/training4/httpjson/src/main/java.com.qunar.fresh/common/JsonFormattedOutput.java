package common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import model.Requests;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * json格式输出数据
 */
public class JsonFormattedOutput {
    public static final Logger LOG = LoggerFactory.getLogger(JsonFormattedOutput.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public static String parseToJson(Requests requests) {
        String result = null;
        try {
            result = MAPPER.writeValueAsString(requests);
        } catch (JsonProcessingException e) {
            LOG.error("wrong:",e);
        }
        return result;
    }
}
