package model;

import java.util.Map;

/**
 * 请求内容po
 */
public class Requests {
    private String protocal;
    private String host;
    private int port;
    private Map<String, String> cookies;
    private Map<String, String[]> requestParam;
    private String url;
    private int status;
    private int version;
    private String message;

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getProtocal() {
        return protocal;
    }

    public void setProtocal(String protocal) {
        this.protocal = protocal;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public Map<String, String> getCookies() {
        return cookies;
    }

    public void setCookies(Map<String, String> cookies) {
        this.cookies = cookies;
    }

    public Map<String, String[]> getRequestParam() {
        return requestParam;
    }

    public void setRequestParam(Map<String, String[]> requestParam) {
        this.requestParam = requestParam;
    }
}
