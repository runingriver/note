package com.qunar.fresh.question2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.HashMap;

public class PropertiesParser {
    private static final Logger log = LoggerFactory.getLogger(PropertiesParser.class);

    private HashMap<String, String> propertyMap = new HashMap<String, String>();

    public void ParserToMap(String path) throws IOException {
        File file = new File(path);
        checkPath(file);
        getPropertyContent(file);
    }

    private void checkPath(File file) throws IOException {
        if (!file.exists() || file.isDirectory()) {
            throw new IOException("please check you file path.");
        }
    }

    private void getPropertyContent(File file) {
        FileInputStream fileInputStream = null;
        InputStreamReader reader = null;
        BufferedReader in = null;
        try {
            fileInputStream = new FileInputStream(file);
            reader = new InputStreamReader(fileInputStream);
            in = new BufferedReader(reader);
            //遍历文件，获取相应信息
            readFile(in);
        } catch (FileNotFoundException e) {
            log.info("file not found:" + e.getMessage());
        } catch (IOException e) {
            log.info("check please:" + e.getMessage());
        } finally {
            try {
                if (fileInputStream != null) fileInputStream.close();
            } catch (IOException e) {
                log.warn("FileInputStream close failed");
            }
            try {
                if (reader != null) reader.close();
            } catch (IOException e) {
                log.warn("InputStreamReader close failed");
            }
            try {
                if (in != null) in.close();
            } catch (IOException e) {
                log.warn("BufferedReader close failed");
            }
        }
    }

    private void readFile(BufferedReader in) throws IOException {
        String buffer,key,value;
        while ((buffer = in.readLine()) != null) {
            key = buffer.substring(0, buffer.indexOf("="));
            //log.debug(key);
            value = buffer.substring(buffer.indexOf("=")+1);
            //log.debug(value);
            propertyMap.put(key, value);
        }
    }

    public HashMap<String, String> getPropertyMap() {
        return propertyMap;
    }

}
