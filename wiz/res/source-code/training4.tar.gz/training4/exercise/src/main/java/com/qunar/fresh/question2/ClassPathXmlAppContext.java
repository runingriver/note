package com.qunar.fresh.question2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;


public class ClassPathXmlAppContext implements AppContext {
    private static final Logger log = LoggerFactory.getLogger(ClassPathXmlAppContext.class);
    private String classXmlPath;
    private String classPropertyPath;

    public ClassPathXmlAppContext(String xmlPath, String propertyPath) {
        init(xmlPath, propertyPath);
    }

    private void init(String xmlPath, String propertyPath) {
        File file1 = new File(xmlPath);
        if (!file1.exists()) {
            //这里应该遍历工程目录，寻找；如果只是一个文件名，也应该遍历工程目录寻找，暂不实现
            log.info(xmlPath + "not found.");
        }
        //propertyPath的检查同xmlPath，暂不实现
        this.classXmlPath = xmlPath;
        this.classPropertyPath = propertyPath;
    }

    public Object getBean() {
        PropertiesParser propertiesParser = new PropertiesParser();
        XmlParser xmlParser = new XmlParser();
        Object o;
        try {
            propertiesParser.ParserToMap(classPropertyPath);
            xmlParser.injectToXml(classXmlPath, propertiesParser.getPropertyMap());
            o = xmlParser.readObjectFromXml();
        } catch (IOException e) {
            log.info("check your input path");
            return null;
        }
        return o;
    }

}

