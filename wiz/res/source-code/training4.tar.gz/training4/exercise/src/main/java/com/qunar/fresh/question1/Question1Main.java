package com.qunar.fresh.question1;

import java.io.IOException;

/**
 * 结果测试
 */
public class Question1Main {
    public static void main(String[] args) throws IOException {
        String path = System.getProperty("user.dir");
        System.out.println(path);
        CharCounter.charStatistics(path);

    }
}
