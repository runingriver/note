package com.qunar.fresh.question2;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.IntrospectionException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by zongzhehu on 16-7-11.
 */
public class XmlParser {
    private static final Logger log = LoggerFactory.getLogger(XmlParser.class);
    private String xmlPath;
    private String className;

    public void injectToXml(String path, HashMap<String, String> propertyMap) throws IOException {
        File file = new File(path);
        checkPath(file);
        this.xmlPath = path;
        DOM4JInjectValueToXml(file, propertyMap);
    }

    private void checkPath(File file) throws IOException {
        if (!file.exists() || file.isDirectory()
               /* || file.toString().toLowerCase().endsWith(".xml")*/) {
            throw new IOException("please check you file path.");
        }
    }

    private void DOM4JInjectValueToXml(File file, HashMap<String, String> propertyMap) {
        //1.创建SAXReader对象
        SAXReader reader = new SAXReader();
        try {
            //2.通过reader对象的read方法加载books.xml文件,获取docuemnt对象。
            Document document = reader.read(file);
            //3.通过document对象获取根节点
            Element rootElement = document.getRootElement();
            log.debug(rootElement.getName());
            if (!rootElement.getName().equals("object")) {
                log.info("check you xml file");
                return;
            }
            //4.通过element对象的elementIterator方法获取迭代器
            Iterator iter = rootElement.elementIterator();
            //5.遍历，解析
            while (iter.hasNext()) {
                //6.获取节点
                Element property = (Element) iter.next();
                log.debug(property.getName());
                Attribute nameAttr = property.attribute("name");
                //Map中包含该K—V
                log.debug(nameAttr.getStringValue());
                if (propertyMap.containsKey(nameAttr.getStringValue())) {
                    Element value = property.element("value");
                    log.debug(value.getStringValue());
                    //设置节点值
                    value.setText(propertyMap.get(nameAttr.getStringValue()));
                    log.debug(value.getStringValue());
                }
            }   /*节点遍历完成*/

            //修改写入到文件,后面修改，直接在内存中传递修改的对象
            try {
                //另存为name-instance.xml
                String fileString = file.toString();
                String saveFileString = fileString.substring(0, fileString.lastIndexOf(".")) + "-instance.xml";
                XMLWriter writer = new XMLWriter(new FileWriter(new File(saveFileString)));
                writer.write(document);
                writer.close();
            } catch (Exception ex) {
                log.info("wirte to xml failed.");
            }
        } catch (DocumentException e) {
            log.info("DOM4J open error:" + e.getMessage());
        }
    }

    public Object readObjectFromXml() {
        String saveFileString = xmlPath.substring(0, xmlPath.lastIndexOf(".")) + "-instance.xml";
        Object obj = null;
        //1.创建SAXReader对象
        SAXReader reader = new SAXReader();
        try {
            //2.通过reader对象的read方法加载books.xml文件,获取docuemnt对象。
            Document document = reader.read(new File(saveFileString));
            //3.通过document对象获取根节点
            Element rootElement = document.getRootElement();
            if (!rootElement.getName().equals("object")) {
                log.info("check you xml file");
                return null;
            }
            className = rootElement.attributeValue("class");
            //反射，通过名称获取Class对象
            Class bean = Class.forName(className);
            //获取Class的信息
            java.beans.BeanInfo info = java.beans.Introspector.getBeanInfo(bean);
            //获取属性描述
            java.beans.PropertyDescriptor pd[] = info.getPropertyDescriptors();
            //设置值，使用Method
            Method methodSet = null;

            obj = bean.newInstance();

            log.debug(rootElement.attributeValue("class"));
            //4.通过element对象的elementIterator方法获取迭代器
            Iterator iter = rootElement.elementIterator();
            //5.属性注入
            while (iter.hasNext()) {
                //6.获取节点
                Element property = (Element) iter.next();
                log.debug(property.getName());
                Attribute nameAttr = property.attribute("name");
                //Map中包含该K—V
                String fieldName = nameAttr.getStringValue();
                Element value = property.element("value");
                String fieldValue = value.getStringValue();
                for (int k = 0; k < pd.length; k++) {
                    if (pd[k].getName().equalsIgnoreCase(fieldName)) {
                        methodSet = pd[k].getWriteMethod();
                        Class fieldType =pd[k].getPropertyType();
                        String typeName = fieldType.getName();
                        if (typeName.endsWith("int") || typeName.endsWith("Integer")) {
                            int i = Integer.parseInt(fieldValue);
                            methodSet.invoke(obj, i);
                        } else if (typeName.endsWith("Date")) {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                            Date date = sdf.parse(fieldValue);
                            methodSet.invoke(obj, date);
                        } else if (typeName.endsWith("String")){
                            methodSet.invoke(obj, fieldValue);
                        } else if (typeName.toLowerCase().endsWith("long")) {
                            Long l = Long.parseLong(fieldValue);
                            methodSet.invoke(obj, l);
                        }else if (typeName.toLowerCase().endsWith("double")) {
                            Double d = Double.parseDouble(fieldValue);
                            methodSet.invoke(obj, d);
                        } else if (typeName.endsWith("bool") || typeName.endsWith("Boolean")) {
                            Boolean b = Boolean.parseBoolean(fieldValue);
                            methodSet.invoke(obj, b);
                        }
                        //String valueString = new String(fieldValue);
                        //injectValue(fieldType,methodSet,obj,valueString);
                    }
                }

            }

        } catch (DocumentException e) {
            log.info("DOM4J open error:" + e.getMessage());
        } catch (ClassNotFoundException e) {
            log.info("can not find the class");
        } catch (InstantiationException e) {
            log.info("new instance failed." + e.getMessage());
        } catch (IllegalAccessException e) {
            log.info("new instance failed." + e.getMessage());
        } catch (IntrospectionException e) {
            log.info(e.getMessage());
        } catch (InvocationTargetException e) {
            log.info(e.getMessage());
        } catch (ParseException e) {
            log.info(e.getMessage());
        }
        return obj;
    }

}

