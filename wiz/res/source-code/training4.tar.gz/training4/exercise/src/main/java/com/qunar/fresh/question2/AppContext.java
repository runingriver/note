package com.qunar.fresh.question2;

//定义获取bean的接口
public interface AppContext {
    public abstract Object getBean();
}
