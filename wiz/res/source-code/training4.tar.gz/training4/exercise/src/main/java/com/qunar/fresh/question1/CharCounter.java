package com.qunar.fresh.question1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;

/**
 * 1)查找一个目录下，所有文件中数字、字母(大小写不区分)、汉字、空格的个数、行数。
 * 2)将结果数据写入到文件中。
 */
public class CharCounter {
    private static final Logger log = LoggerFactory.getLogger(CharCounter.class);

    public static void charStatistics(String path) throws IOException {
        File file = new File(path);
        checkPath(file);
        //获取所有文件
        List<File> allFiles = getAllFiles(file);
        //读取所有文件,并写入hashmap中
        HashMap<String, Integer> charStatistic = getAllFilesContent(allFiles);
        //将结果按照要求写入到文件中
        String outPath = CharCounter.class.getResource("/").getPath()+"result.txt";
        boolean isSuccess = wirteToFileByformat(charStatistic,outPath);
        if (!isSuccess) {
            log.info("wirte to file failed.");
        }
    }

    private static void checkPath(File file) throws IOException {
        if (!file.exists() || !file.isDirectory()) {
            throw new IOException("the path error, please check your filepath");
        }
    }

    /**
     * 遍历目录下所有的文件
     *
     * @param file 指定的目录
     * @return 返回文件数组
     */
    private static List<File> getAllFiles(File file) {
        List<File> allFiles = new ArrayList<File>();
        List<File> subDir = new ArrayList<File>();
        scanDir(file, allFiles, subDir);
        //遍历目录下面的目录，subDir的元素动态增长
        File tmpFile;
        for (int i = 0; i < subDir.size(); i++) {
            tmpFile = subDir.get(i);
            scanDir(tmpFile, allFiles, subDir);
        }
        return allFiles;
    }

    /**
     * 扫描目录下的文件，并添加到集合中
     *
     * @param file     文件路径
     * @param allFiles 扫描的文件是文件，添加到该集合中
     * @param subDir   扫描的文件时dir，添加到该集合中
     */
    private static void scanDir(File file, List<File> allFiles, List<File> subDir) {
        File[] tmpfiles = file.listFiles();
        for (File f : tmpfiles) {
            if (f.isDirectory()) {
                subDir.add(f);
                log.debug("dir:" + f.toString());
            } else {
                allFiles.add(f);
                log.debug("file:" + f.toString());
            }
        }
    }

    private static HashMap<String, Integer> getAllFilesContent(List<File> allFiles) {
        //一共有41种类型字符，初始化大小41
        HashMap<String, Integer> charStatistic = new HashMap<String, Integer>(41);
        //初始化HashMap
        initCharStatisticMap(charStatistic);
        //遍历每一个文件，获取每一个文件中的内容
        for (File f : allFiles) {
            getFileContent(f, charStatistic);
        }
        return charStatistic;
    }

    private static void initCharStatisticMap(HashMap<String, Integer> charStatistic) {
        charStatistic.put("数字", 0);
        charStatistic.put("字母", 0);
        charStatistic.put("汉字", 0);
        charStatistic.put("空格", 0);
        charStatistic.put("行数", 0);
        String tmpString;
        for (int i=0;i<10;i++) {
            tmpString = "数字" + i;
            charStatistic.put(tmpString, 0);
        }
        for (int i=65;i<91;i++) {
            tmpString = "字母" + (char)i;
            charStatistic.put(tmpString, 0);
        }
    }

    private static boolean getFileContent(File file, HashMap<String, Integer> charStatistic) {
        FileInputStream fileInputStream = null;
        InputStreamReader reader = null;
        BufferedReader in = null;
        try {
            fileInputStream = new FileInputStream(file);
            reader = new InputStreamReader(fileInputStream);
            in = new BufferedReader(reader);
            //遍历文件，获取相应信息
            statisticFileContent(in,charStatistic);
        } catch (FileNotFoundException e) {
            log.info("file not found:" + e.getMessage());
            return false;
        } catch (IOException e) {
            log.info("check please:" + e.getMessage());
            return false;
        } finally {
            try {
                if (fileInputStream != null) fileInputStream.close();
            } catch (IOException e) {
                log.warn("FileInputStream close failed");
            }
            try {
                if (reader != null) reader.close();
            } catch (IOException e) {
                log.warn("InputStreamReader close failed");
            }
            try {
                if (in != null) in.close();
            } catch (IOException e) {
                log.warn("BufferedReader close failed");
            }
        }
        return true;
    }

    private static void statisticFileContent(BufferedReader in, HashMap<String, Integer> charStatistic) throws IOException {
        String buffer;
        while ((buffer = in.readLine()) != null) {
            charStatistic.put("行数", charStatistic.get("行数") + 1);
            scanStringLine(buffer,charStatistic);
        }
    }

    private static void scanStringLine(String line, HashMap<String, Integer> charStatistic) {
        //遍历每一个字符
        char[] chars = line.toCharArray();
        char c;
        char upCase;
        for (int i=0,n = chars.length;i<n;i++) {
            c= chars[i];
            if (CharUtil.isChinese(c)) {                //判断汉字
                if (!CharUtil.isChinesePunctuation(c)) {
                    charStatistic.put("汉字", charStatistic.get("汉字") + 1);
                }
            } else if (CharUtil.isFigure(c)) {
                charStatistic.put("数字", charStatistic.get("数字") + 1);
                charStatistic.put("数字"+c, charStatistic.get("数字"+c) + 1);
            } else if (CharUtil.isLetter(c)) {
                charStatistic.put("字母", charStatistic.get("字母") + 1);
                //对应字母+1
                if (Character.isLowerCase(c)) {
                    upCase = (char) ((int) c - 32);
                    charStatistic.put("字母" + upCase, charStatistic.get("字母" + upCase) + 1);
                } else {
                    charStatistic.put("字母"+ c, charStatistic.get("字母"+c) + 1);
                }
            } else if (CharUtil.isBlankspace(c)) {
                charStatistic.put("空格", charStatistic.get("空格") + 1);
            }

        }
    }

    private static boolean  wirteToFile(HashMap < String, Integer > charStatistic,String path) throws IOException {
        File file = new File(path);

        if (charStatistic == null || file.isDirectory()) {
            return false;
        }

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                log.warn("fatal:create file failed.");
                throw e;
            }
        }

        PrintWriter printWriter = new PrintWriter(file);

        //遍历HashMap
        String key = null;
        Integer value = null;
        Iterator iterator = charStatistic.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            key = (String) entry.getKey();
            value = (Integer) entry.getValue();
            StringBuilder rst=new StringBuilder();
            rst.append(key).append(":").append(value);
            //处理单位
            if (key.equals("行数")) {
                rst.append("行");
            } else {
                rst.append("个");
            }
            printWriter.println(rst.toString());
        }
        printWriter.flush();
        printWriter.close();
        return true;
    }

    private static boolean  wirteToFileByformat(HashMap < String, Integer > charStatistic,String path) throws IOException {
        File file = new File(path);

        if (charStatistic == null || file.isDirectory()) {
            return false;
        }

        if (!file.exists()) {
                file.createNewFile();
        }
        PrintWriter printWriter = null;
        try {
            printWriter = new PrintWriter(file);
            printWriter.println("数字："  + charStatistic.get("数字") + "个");
            printWriter.println("字母："  + charStatistic.get("字母") + "个");
            printWriter.println("汉字："  + charStatistic.get("汉字") + "个");
            printWriter.println("空格："  + charStatistic.get("空格") + "个");
            printWriter.println("行数："  + charStatistic.get("行数") + "行");
            String tmpString;
            for (int i=0;i<10;i++) {
                tmpString = "数字" + i;
                printWriter.println(tmpString+":"  + charStatistic.get(tmpString) + "个");
            }
            for (int i=65;i<91;i++) {
                tmpString = "字母" + (char)i;
                printWriter.println(tmpString+":"  + charStatistic.get(tmpString) + "个");
            }

            printWriter.flush();
        } catch (FileNotFoundException e) {
            log.error("file not found in printWriter.");
        }finally {
            if (printWriter != null) {
                printWriter.close();
            }
        }



        return true;
    }
}
