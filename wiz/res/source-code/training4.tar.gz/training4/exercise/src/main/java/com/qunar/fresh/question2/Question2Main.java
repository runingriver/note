package com.qunar.fresh.question2;

import java.text.SimpleDateFormat;

public class Question2Main {
    public static void main(String[] args) throws Exception {

        String xmlPath = "./exercise/src/main/resources/object.xml";
        String propertyPath = "./exercise/src/main/resources/object.properties";

        ClassPathXmlAppContext cpa =new ClassPathXmlAppContext(xmlPath,propertyPath);
        Student student = (Student) cpa.getBean();
        System.out.println("name:" + student.getName());
        System.out.println("age:" + student.getAge());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String d = sdf.format(student.getBirth());
        System.out.println("data:" + d);


    }
}
