---
title: About Me
date: 2016/06/26 21:12:22
toc: false
list_number: false
---

## Open Source project
gscheduler： A task scheduling system based on guava,depends on spring.
seckill: A high concurrent solution,study from http://www.imooc.com/
helper: Finishing and accumulation of some of the commonly used tools.
MapWinGIS: A GIS desktop project refact by C#,in my graduate period

## Contact
github: https://github.com/runingriver
email: huzongzhe@126.com

## About Me
A programer,locate Beijing,Strive for the ideal.
seek geeks spirit, love coding art！